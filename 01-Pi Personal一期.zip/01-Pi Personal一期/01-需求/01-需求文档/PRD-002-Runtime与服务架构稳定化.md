---
type: PRD
status: 草稿
version: v1.0
depends_on: 基准事实-v1.2; PRD-001-v1.0; AnalysisReport-001-v1.0
owner: 缘一
created: 2026-08-20
updated: 2026-08-20
---

# PRD-002：Runtime 与服务架构稳定化

## 背景与目标

PRD-001 已完成 Pi Personal 一期核心能力建设：Personal Runtime、统一 Session、Pi Web Gateway 接入和微信私聊能力已经进入真实代码。

真实使用后暴露出的主要问题已经从“缺能力”转变为“运行边界没有完全收口”：

- Web 在 Gateway 模式下仍残留部分 Agent Runtime Ownership；
- Personal Runtime 与 Web 虽已拆成两个进程，但生命周期仍存在人为联动和重复启动；
- 同 Session Prompt 串行与 Idle 回收存在正确性风险；
- 无项目 Session 的 Runtime 语义和 Web 体验尚未完全一致；
- Web → Gateway → Browser 的 Streaming 额外延迟尚未量化。

本轮目标不是继续增加 Personal Agent 功能，而是：

> **把第一轮已经做出来的 Pi Personal 一期能力收口成一个可以长期常驻、稳定运行、低感知延迟、单一 Runtime Ownership 的生产基线。**

完成后，用户只感知一个 Yuanyi-Pi 产品；Personal Runtime 可以独立长期运行，Web 可以随时启动和关闭而不影响微信、AgentSession 和后续后台能力。

## 用户与场景

### 场景一：Web 长时间不开，微信仍持续在线

用户可以数天不打开 Pi Web。

期间 Personal Runtime 仍应：

- 持续运行；
- 保持微信 Channel；
- 接收和回复私聊；
- 支持主动发送；
- 继续已有 Session。

### 场景二：用户随时打开或关闭 Web

用户打开 Pi Web 时只需直接使用，不需要先判断 Gateway 是否启动。

关闭或重启 Pi Web：

- 不得关闭 Personal Runtime；
- 不得断开微信；
- 不得销毁正在运行的 AgentSession；
- 不得影响后台中的 Agent Run。

### 场景三：同一 Session 被多个入口连续访问

Web 和微信可以访问同一 Session。

普通 Prompt 必须按照明确的串行规则处理，不允许因为两个入口同时操作造成 Session 并发写冲突。

### 场景四：长时间 Agent 任务

Agent 任务运行时间超过默认 Idle 阈值时，只要仍处于真实运行 / Streaming 状态，就不得被空闲回收。

### 场景五：无项目会话

用户不选择本地项目目录也可以在 Web 中直接新建 Session。

该 Session：

- 产品语义上属于“无项目”；
- Runtime 可以使用 neutralCwd；
- Web 不得把 neutralCwd 展示成真实项目。

### 场景六：Web 对话保持即时响应

加入 Personal Gateway 后，Web 中模型首字和流式输出不能出现明显额外卡顿。

延迟问题必须能够拆分为：

- Web/BFF → Gateway；
- 模型真实 TTFT；
- Gateway Event → Browser。

## 功能需求

### FR-201 Personal Runtime 独立生命周期

Personal Runtime 必须成为独立于 Pi Web 的长期后台服务。

要求：

- Web 不负责随自身启动 / 退出启停 Runtime；
- Web 数天未运行时 Runtime 仍可保持工作；
- Runtime 崩溃后具备自动恢复能力；
- 同一生产环境只能存在一个有效 Personal Runtime 实例。

### FR-202 唯一 Runtime Ownership

Gateway 模式下，一个 Session 只能存在一个活跃 Agent Runtime Owner。

要求：

- AgentSession 只能由 Personal Runtime 持有；
- Web 不得因 Auto-name、State、Context、Running、Project Trust 等辅助功能重新创建第二套 AgentSession；
- Session 的运行态修改必须与 Personal Runtime 中真实状态一致；
- 允许 Web 直接读取不改变 Runtime 的持久化只读数据，但不得绕过 Gateway 改变活状态。

### FR-203 同 Session 普通 Prompt 串行

同一 Session 的普通 Prompt 必须进入统一串行控制。

要求：

- Web 与微信同时提交普通 Prompt 时不得并发写 Session；
- `steer / follow_up / abort` 保持 Pi 原生语义；
- 串行机制必须位于 Runtime Manager，不由各 Channel 自己实现。

### FR-204 安全 Idle 回收

Runtime 只能在真实空闲时被回收。

要求：

- 正在 Streaming / Running 的 Runtime 不得因时间阈值被 dispose；
- Idle 判断必须使用真实 Agent 状态；
- 回收只释放内存 Runtime，不删除持久 Session；
- 下次访问可以使用同一 Session ID 恢复。

### FR-205 无项目 Session Web 闭环

Web 必须完整支持无项目 Session：

- 不选择目录即可新建；
- 无项目 Session 独立展示；
- `neutralCwd` 只作为 Runtime 实现，不作为项目展示；
- 绑定真实目录的 Session 继续按真实本地目录组织。

### FR-206 Runtime 状态可观测

系统必须能确定 Personal Runtime 的真实状态，至少包括：

- 服务是否运行；
- Gateway 是否可访问；
- 微信 Channel 是否连接；
- 当前产品版本；
- 关键运行错误。

用户不应再通过手工查端口和 PID 才能判断系统是否正常。

### FR-207 Web 与 Runtime 独立重启

Pi Web 和 Personal Runtime 必须拥有独立的重启边界。

- Web 重启不影响 Runtime；
- Runtime 重启后持久 Session 可以恢复；
- Runtime 重启过程中 Web 应明确表现为 Runtime 暂不可用，而不是静默卡死。

## 非功能需求

### NFR-201 Web 响应性能

同机本地环境必须记录：

```text
T0 = Browser 发出 Prompt
T1 = Gateway 收到 Prompt
T2 = Gateway 收到 Pi 第一条模型输出 Event
T3 = Browser 收到第一条输出 Event
```

目标：

- `T1 - T0` P95 ≤ 50 ms；
- `T3 - T2` P95 ≤ 50 ms；
- Streaming 不出现明显批量吐字或周期性积压。

如果性能不达标，优先优化 BFF / SSE 转发，不直接取消双进程。

### NFR-202 可用性

- Personal Runtime 长期常驻；
- Web 可以按需启动；
- Runtime 异常不应表现为 Web 长时间无反馈；
- 服务重启后 Session 数据不丢失。

### NFR-203 数据一致性

- 同 Session 不得存在双 Runtime Owner；
- 运行状态、Session 文件、Personal Metadata 不得因 Web / Gateway 两条写路径产生冲突。

### NFR-204 回归要求

本轮稳定化不得破坏已完成的一期能力：

- Web 对话；
- Streaming；
- 模型选择；
- 本地目录；
- 微信私聊；
- 微信主动发送；
- Web / 微信统一 Session；
- Pi Package / Extension 基础能力。

### NFR-205 单一产品体验

用户只感知 Yuanyi-Pi，不需要理解：

- 8770 / 30141；
- 两个 PID；
- Gateway 先启动还是 Web 先启动；
- 哪个脚本负责哪个服务。

## 范围边界

### 本轮必须完成

- Runtime Ownership 全量收口；
- Prompt 串行修复；
- Idle 回收修复；
- 无项目 Session Web 闭环；
- Personal Runtime 独立常驻；
- 单实例与 Health；
- Web 不再控制 Runtime 生命周期；
- TTFT / Streaming 性能指标；
- 全量回归与稳定化验收。

### 本轮明确不做

- Memory；
- Scheduler 产品化；
- Desktop 正式开发；
- Subagent 产品化；
- Capability Router 平台化；
- 新 IM Channel；
- 通用插件平台；
- 因“架构更漂亮”而大规模重写现有 Gateway / Web。

### 延后事项

自有 `pi/` 正式成为 `pi-web` / `personal-runtime` 的运行依赖：

- 本轮记录并保持可追踪；
- 在首次发布自有 Pi Core 修改之前必须解决；
- 当前不为了形式统一强制切换稳定的官方 0.84.2 依赖。

## 验收标准

### AC-201 Runtime 独立常驻

1. 停止 Pi Web；
2. Personal Runtime 保持运行；
3. 微信仍能接收并回复消息；
4. 至少完成一次长期运行验证；
5. 重新启动 Web 后可继续原 Session。

### AC-202 Web 重启不影响 Agent

1. 在 Runtime 中启动一个仍在执行的 Agent Run；
2. 重启 Pi Web；
3. Runtime 不重启；
4. Agent Run 不因 Web 重启被取消；
5. Web 恢复后可继续查看同一 Session。

### AC-203 唯一 Runtime Owner

通过代码审计与运行验证确认：

- Gateway 模式下 Web 不再通过 `startRpcSession()` 创建活跃 Session Runtime；
- 同一 Session 不出现 Web / Gateway 两套 AgentSession；
- Session 删除 / State / Context / Running 等操作不会造成 Runtime 与持久状态分裂。

### AC-204 Prompt 串行

对同一 Session 从 Web 和微信同时提交普通 Prompt：

- 不发生并发写错误；
- 执行顺序可解释；
- Session 历史保持一致。

### AC-205 长任务不被 Idle 回收

使用测试阈值或真实长任务验证：

- Runtime 在 `isStreaming=true` 时不会被回收；
- 任务结束并真实空闲超过阈值后才可 dispose；
- 恢复后 Session ID 不变。

### AC-206 无项目 Web 体验

- 不选择目录即可新建；
- Session 正常运行；
- 列表展示为无项目；
- neutralCwd 不作为项目目录展示。

### AC-207 性能

在本地连续采样不少于 30 次普通 Web 对话：

- Web/BFF → Gateway P95 ≤ 50 ms；
- Gateway Event → Browser P95 ≤ 50 ms；
- 无明显批量吐字；
- 未发现由 BFF 转发导致的持续卡顿。

### AC-208 服务单实例

- 系统级服务已运行时再次执行启动操作不会拉起第二个 Runtime；
- 不再出现因重复启动导致的 `EADDRINUSE`；
- 状态查询能明确返回当前服务状态。

### AC-209 一期能力回归

PRD-001 已完成的 Web、微信、Session、模型、本地目录和基础 Extension 能力全部通过回归。

以上验收全部通过后，本轮 002 稳定化设计才可视为完成。
