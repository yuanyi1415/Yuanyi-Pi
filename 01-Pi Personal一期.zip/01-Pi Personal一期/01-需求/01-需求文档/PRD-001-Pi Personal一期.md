---
type: PRD
status: 草稿
version: v1.0
depends_on: 基准事实-v1.1
owner: 缘一
created: 2026-08-20
updated: 2026-08-20
---

# PRD-001：Pi Personal 一期

## 背景与目标

Pi 已具备成熟的 Agent Runtime、模型、Tool / Extension、Session、Streaming、上下文压缩与缓存等底层能力，Pi Web 也已经具备较成熟的 Web 使用体验。但当前产品形态仍以单一客户端直接使用 AgentSession 为主，不适合作为一个可长期扩展到 Web、IM、Desktop 等入口的个人 Agent 产品。

Pi Personal 一期的目标不是重新实现 Agent Engine，也不是一次性补齐 Memory、Scheduler、Subagent 等所有 Personal Agent 能力，而是先完成一个最小但完整的产品闭环：

> **让用户通过 Web 和个人微信私聊访问同一套 Personal Agent Session，并能在不同入口之间持续同一个会话；同时保留 Pi 原有的本地项目目录语义和 Session 级模型选择能力。**

一期完成后，应证明 Yuanyi-Pi 已从“Pi + Pi Web 的组合”演进为具备统一 Session、多入口和独立 Personal Runtime 边界的 Personal Agent 基础产品。

## 用户与场景

### 目标用户

一期首先服务项目负责人本人，目标体验按真实长期使用验证；产品设计同时避免形成只能服务单一用户习惯的硬编码，为后续 C 端用户使用保留通用边界。

### 场景一：Web 日常对话

用户打开 Web 后可以直接新建会话：

- 可以不选择本地项目目录，形成无项目会话；
- 可以选择一个真实本地目录，使会话围绕该目录工作；
- 可以选择或切换当前 Session 使用的 Model Preset / Model；
- 可以继续已有 Session。

### 场景二：Web 与微信连续使用

用户在 Web 中开始一个 Session 后，可以通过微信继续该 Session；反过来，微信中创建的 Session 也可以在 Web 中看到并继续。

用户不需要为 Web 和微信维护两套不同的会话历史。

### 场景三：微信作为低摩擦入口

用户可以通过个人微信私聊：

- 发起新的 Agent 会话；
- 继续指定的已有 Session；
- 接收 Agent 文本回复。

微信只是访问统一 Personal Agent 的一个入口，不形成独立的“微信 Agent”。

### 场景四：主动微信消息

Personal Agent 可以主动向用户指定的微信联系人发送文本消息，为后续提醒、后台任务和通知能力保留正式消息出口。

### 场景五：不同会话使用不同计算资源

用户可以让不同 Session 使用不同 Model Preset / Model / Credential，以适配不同任务和 Token 成本需求，而不需要把整个 Agent 强制拆分成 Work / Personal 两套环境。

## 功能需求

### FR-001 统一 Session

系统必须以统一 Session 作为 Web、微信及未来其它客户端共同访问的会话对象。

要求：

- Web 和微信不得各自维护互不相通的 Agent 会话；
- 同一个 Session 在不同入口继续时，应保持已有对话上下文；
- Session 关闭客户端后仍可恢复；
- 不要求 Session 归属于 Work / Personal Profile。

### FR-002 Web 会话列表

Web 必须继续提供统一的历史会话列表，并基于真实本地目录组织会话。

展示规则：

1. 无项目会话分区位于项目目录分区之上；
2. 绑定相同本地目录的 Session 按目录分组；
3. 微信创建的 Session 也进入同一会话列表；
4. 优先复用 Pi Web 现有能力，只对不符合目标体验的 UI / 交互进行调整。

### FR-003 新建 Web 会话

用户通过 Web 新建 Session 时：

- 可以不选择项目目录；
- 可以选择已有真实本地目录；
- 应尽量沿用 Pi Web 现有目录选择能力；
- 如现有能力支持，应允许在新建流程中方便地创建真实本地目录；
- 不得强制用户先建立虚拟 Project / Workspace。

### FR-004 本地项目上下文

当 Session 绑定真实本地目录时，应继续使用 Pi 原生的项目上下文能力，包括该目录下可被 Pi 正常发现和使用的项目文件、指令和资源。

系统不得为了会话分组另外创建一套虚拟项目本体取代本地目录。

### FR-005 Session 级模型选择

用户必须可以针对 Session 选择或切换 Model Preset / Model。

要求：

- 不同 Session 可以使用不同模型；
- Session 恢复后应保持其当前模型状态；
- 模型选择不依赖 Work / Personal Profile；
- 应尽量复用 Pi 已有模型和 Provider 能力，不重复建设模型调用体系。

### FR-006 微信私聊接收与回复

一期微信只支持个人微信私聊文本。

必须支持：

- 接收私聊文本消息；
- 将消息交给对应 Personal Session 处理；
- 将 Agent 文本结果回复到微信私聊。

一期不要求群聊、图片、文件、语音或其它富媒体能力。

### FR-007 微信创建 Session

当用户通过微信发起新的 Agent 对话时，系统必须能够创建新的统一 Session。

该 Session：

- 可以在 Web 会话列表中出现；
- 可以在 Web 中继续；
- 不因为来源是微信而形成独立的会话类型。

### FR-008 微信继续已有 Session

系统必须提供一种明确、可验证的方式，让用户在微信中选择或指定一个已有 Session 并继续对话。

具体交互方式在后续产品设计中确定，但必须满足：

- 可以定位到指定 Session；
- 继续后使用该 Session 的已有上下文；
- 不产生一个内容相似但实际独立的新 Session。

### FR-009 Agent 主动微信消息

系统必须支持 Personal Agent 主动向指定微信联系人发送文本消息。

一期仅要求建立可靠的主动文本发送能力，不要求完整 Scheduler 或后台任务产品。

### FR-010 Runtime 与客户端解耦

一期完成后，Web 不得继续作为 AgentSession 的唯一 Runtime Owner。

Web 和微信都必须通过统一 Personal Runtime 使用 Session，使未来 Desktop 接入时不需要重新推翻 Session 和 Runtime 的核心边界。

### FR-011 Pi Package / Extension 兼容

一期改造不得无必要地破坏 Pi 已有 Package / Extension 能力。

Agent 侧能力仍应能够继续使用 Pi 已有 Tool、Skill、Extension 等生态能力；一期不建设新的通用插件市场或 Personal Plugin Manager。

## 非功能需求

### NFR-001 现有体验连续性

一期改造过程中，现有 Pi / Pi Web 的主要聊天能力不应出现明显退化，包括：

- 基础对话；
- Streaming；
- 模型使用；
- 本地项目上下文；
- 已有 Session 的读取与继续。

### NFR-002 Session 数据完整性

跨 Web / 微信继续 Session 时，不得出现：

- 上下文串线；
- Session 错配；
- 已有 Session 被覆盖；
- 因切换入口导致历史记录丢失。

### NFR-003 可恢复性

Personal Runtime 进程或客户端重启后，已持久化 Session 应能够重新恢复并继续使用。

### NFR-004 Channel 解耦

微信具体接入实现的变化不应要求修改 Session 本体或 Pi Agent Runtime 核心逻辑。

### NFR-005 可演进性

一期形成的 Session / Runtime / Channel 边界必须允许下一期 Desktop 作为新客户端接入，而不要求再次重构核心会话模型。

### NFR-006 C 端使用优先

Web 和微信是一期主要产品入口。不得为了兼容 CLI / TUI 的使用习惯而增加不必要的 C 端操作负担。

### NFR-007 上游可控

Yuanyi-Pi 可以按项目需要修改 Pi Core，但官方 Pi 的变化不得未经评估自动改变产品行为；Pi-Web 后续产品演进以 Yuanyi-Pi 自身需求为准。

## 范围边界

### 一期必须完成

- 统一 Personal Session；
- Personal Runtime 与 Web 解耦；
- Web 接入统一 Session；
- 微信私聊文本接收；
- 微信文本回复；
- 微信主动文本发送；
- 微信创建 Session；
- 微信继续指定已有 Session；
- Web 查看并继续微信 Session；
- Web 会话列表按无项目 / 真实本地目录组织；
- Session 级 Model Preset / Model；
- Desktop 后续接入的核心边界兼容；
- Pi Package / Extension 基础兼容。

### 一期明确不做

- Work / Personal Profile Runtime；
- 虚拟 Project / Workspace；
- Desktop 正式客户端；
- 微信群聊；
- 图片、文件、语音、富媒体；
- 完整 Long-term Memory；
- 完整 Scheduler / Background Task 产品；
- 完整 Capability Router；
- Subagent 产品化；
- Task DAG / Planning；
- 多 IM Channel；
- 通用 Personal Plugin Manager；
- 插件市场和复杂插件治理。

### 不在 PRD 中冻结的内容

以下属于后续设计 / 技术阶段，不在本 PRD 直接决定：

- Personal Gateway 的具体框架；
- Gateway 采用 HTTP、WebSocket、SSE 或其它具体协议组合；
- Session Metadata 具体数据库；
- 微信具体 Transport / 协议实现；
- Model Preset 最终数据结构；
- Personal Runtime 在代码仓库中的最终目录；
- Runtime 并发、锁、进程与回收具体实现；
- 后续 Memory / Scheduler Backend；
- AgentHarness / PiServer 的未来迁移时间。

## 验收标准

### AC-001 Web → 微信

1. 在 Web 创建 Session A 并完成至少一轮对话；
2. 在微信中明确继续 Session A；
3. Agent 能基于 Session A 已有上下文回答；
4. Web 再次打开 Session A 时可看到连续历史。

通过信号：全程只存在同一个 Session A，不产生上下文断裂或重复 Session。

### AC-002 微信 → Web

1. 在微信发起新的 Session B；
2. 完成至少一轮对话；
3. 打开 Web；
4. Web 会话列表可看到 Session B；
5. 在 Web 继续 Session B，Agent 能使用微信阶段的上下文。

### AC-003 无项目会话

1. Web 新建 Session 时不选择本地项目目录；
2. Session 正常运行；
3. 会话出现在“无项目会话”分区；
4. “无项目会话”分区位于项目目录分区之前。

### AC-004 本地目录会话

1. Web 新建 Session 时选择一个真实本地目录；
2. Session 出现在该目录分组；
3. Pi 可以正常使用该目录的项目上下文；
4. 系统没有额外创建虚拟 Project 作为替代。

### AC-005 Session 级模型

1. 创建两个不同 Session；
2. 分别选择不同 Model Preset / Model；
3. 两个 Session 分别使用所选模型；
4. 重启客户端或恢复 Session 后模型状态保持一致。

### AC-006 微信主动发送

1. 选择一个有效微信联系人；
2. 由系统主动触发一条文本消息；
3. 对方微信能够收到正确文本；
4. 该能力不依赖用户先发送一条新消息触发。

### AC-007 Runtime Ownership

1. Web 不直接作为唯一 AgentSession Owner；
2. Web 与微信均能访问统一 Personal Runtime；
3. 关闭 Web 客户端后，不影响已经持久化的微信 Session 后续恢复；
4. 下一期新增 Desktop 时无需重新定义 Session 本体。

### AC-008 现有 Pi 核心能力回归

完成 Gateway / Session 改造后验证：

- 基础聊天正常；
- Streaming 正常；
- 本地目录上下文正常；
- 模型选择正常；
- 已有 Session 可读取和继续；
- Pi Package / Extension 的基础使用未因一期改造被无理由破坏。

以上八项全部通过，且不存在阻断日常使用的 P0 问题，才可判定一期需求验收通过。
