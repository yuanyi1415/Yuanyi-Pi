---
type: ADR
status: 已确认
version: v1.0
depends_on: 基准事实-v1.1; POC411; 负责人确认 2026-08-20
owner: 缘一
created: 2026-08-20
updated: 2026-08-20
---

# ADR-001：微信 Transport 选型 —— 微信官方 ilinkai 接口

## 状态

**已确认**（项目负责人 缘一 2026-08-20 确认）。构成关键决策（Transport 选型直接影响 S4 实现与账号风险），按 WBS POC412 生成。

## 背景

一期需要实现个人微信私聊文本的接收、回复与主动发送，作为统一 Personal Session 的 Channel（FR-006~009）。

候选评估基于以下环境约束与实测：

| 方案 | 结论 | 依据 |
|---|---|---|
| 微信官方 **ilinkai** 接口（`ilinkai.weixin.qq.com`） | **选定** | 官方能力、HTTP 长轮询、无封号风险；nanobot（MIT）已完整实现并验证 |
| AX 辅助功能 UI 自动化 | 排除 | 实测：macOS 微信 4.1.8 屏蔽辅助功能内容树（窗口仅 3 个按钮，消息/输入框不可读） |
| OCR 截图黑盒 | 排除 | 依赖窗口常驻可见、秒级延迟、坐标脆弱，不适合正式 Transport |
| wechaty + 社区 puppet | 排除 | web 协议已被微信官方关闭；macOS 4.x 无可靠 puppet；hook 类有封号风险 |
| 企业微信 / 公众号 API | 排除 | 不符合"个人微信私聊"需求（基准事实） |

## 决策

**WeChatTransport 采用微信官方 ilinkai 接口**（base_url=`https://ilinkai.weixin.qq.com`），机制全面照抄 nanobot `nanobot/channels/weixin/`（MIT License，保留版权声明），以 TypeScript 移植到 `personal-runtime/src/channel/wechat/`。

核心机制：

- **登录**：个人微信扫码（`ilink/bot/get_bot_qrcode` + `get_qrcode_status` 轮询）→ `bot_token`；支持验证码 / 过期刷新 / 绑定重定向；token 持久化到 `account.json`
- **接收**：HTTP 长轮询 `ilink/bot/getupdates`（35s，`get_updates_buf` 游标续传），`message_type=2` 跳过自己的消息，`message_id` 去重
- **发送**：`ilink/bot/sendmessage`，`context_token`（60s 过期前经 `getconfig` 主动刷新）+ 每上下文发送配额（默认 8），超限 defer（最多 3 条，等待用户新消息重发）
- **样式与返回格式**：出站 markdown 清理（`< >` 转全角、去 `~~`/h5/h6/图片链接）、1800 字符拆分（平衡代码块）；入站 item_list 解析（文本 / `[引用: ...]` / `[image]` / `[voice]` / `[file: 名称]` / `[video]` 占位格式）
- **重连**：长轮询超时正常续；连续 3 次失败退避 30s；token 失效（errcode -14）热替换或触发重新扫码
- **在线状态**：`ilink/bot/msg/notifystart/stop`

## 验证结论（POC411）

2026-08-20 真实微信验证全部通过：

1. ✅ 扫码登录 + token 持久化（`~/.pi-dev/.yuanyi-pi/wechat/account.json`）
2. ✅ 接收私聊文本（手机发送 "PoC测试123" 被长轮询收到，含 im id 与内容）
3. ✅ 回复私聊文本（自动 echo 回复成功）
4. ✅ 主动发送文本（`wechat-send` 脚本，无入站触发，直接调用 `send` 成功）
5. ✅ 掉线/重连基础（保存 token 复用恢复连接）
6. ✅ License（nanobot MIT 可参考/复用）与账号风险（官方接口，非逆向/非 hook）

## 后果

- 一期微信实现以本 ADR 为 Transport 依据，后续 `WeChatChannelAdapter`（DEV412）对接 Channel Contract（C-4）
- 遵守 iLink 的 `context_token` 配额与刷新机制，避免触发接口限制
- `bot_token` 可能失效（-14），需提供重新扫码入口（一期提供 CLI 登录命令）
- 微信侧可能调整接口行为：所有 Pi 调用收敛在 Transport 内，变更影响面可控
