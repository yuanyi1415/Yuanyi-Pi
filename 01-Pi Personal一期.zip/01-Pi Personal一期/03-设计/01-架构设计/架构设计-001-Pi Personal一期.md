---
type: 架构设计
status: 草稿
version: v1.0
depends_on: 基准事实-v1.1; PRD-001-v1.0
owner: 缘一
created: 2026-08-20
updated: 2026-08-20
---

# 架构设计-001：Pi Personal 一期

## 1. 约束

### 1.1 产品约束

- 一期正式入口只有 Web + 个人微信私聊。
- Desktop 只保留兼容边界，不正式交付。
- CLI / TUI 不作为主要 C 端入口。
- Session 是一级运行对象，不建立 Work / Personal Profile Runtime。
- “项目”使用真实本地目录语义，不建立虚拟 Project / Workspace。
- 一期不建设完整 Memory、Scheduler、Capability Router、Subagent 产品体系和通用插件平台。

### 1.2 技术约束

- 一期以 Pi 当前成熟的 `AgentSession` 主链路为基础。
- Pi 与 Pi-Web 统一由 Yuanyi-Pi 单仓管理、统一版本、统一验证和发布。
- Pi upstream 只作为对照与选择性能力来源。
- Pi-Web 后续由 Yuanyi-Pi 自主产品化，不建立独立 upstream 跟踪线。
- 产品语义原生定义；Transport / Backend / Adapter 等具体实现保持可替换。
- Agent 侧能力优先继续兼容 Pi Package / Extension 生态。

### 1.3 现状约束

当前 Pi Web 的关键运行事实：

- `pi-web/lib/rpc-manager.ts` 直接创建并持有 Pi `AgentSession`；
- 活动 Session Runtime 保存在 Web Server 进程的全局 Registry；
- Runtime 当前存在约 10 分钟空闲回收逻辑；
- `pi-web/app/api/agent/new/route.ts` 直接调用 `startRpcSession()`；
- Pi Web 当前会话列表同时合并持久化 Session 和运行中 Session；
- Pi Web 新建 Agent 当前要求传入 `cwd`；
- Pi Web 当前依赖 Pi 0.84.2 的已发布 Package。

一期改造必须尽量保持现有 Web 使用体验，不以“重写 Web”为代价完成 Runtime 解耦。

## 2. 上下文

```text
                         ┌─────────────────┐
                         │   LLM Provider  │
                         └────────▲────────┘
                                  │
┌──────────┐             ┌────────┴────────┐
│  Browser │────────────▶│     Pi Web      │
└──────────┘             └────────┬────────┘
                                  │ HTTP / SSE
                                  ▼
                         ┌─────────────────┐
                         │ Personal Runtime│
                         │    / Gateway    │
                         └───────┬─────────┘
                                 │
                  ┌──────────────┼──────────────┐
                  │              │              │
                  ▼              ▼              ▼
           ┌────────────┐ ┌────────────┐ ┌────────────┐
           │ Pi Engine  │ │ Local FS   │ │ WeChat     │
           │AgentSession│ │ / Sessions │ │ Transport  │
           └────────────┘ └────────────┘ └──────▲─────┘
                                                │
                                                ▼
                                           ┌────────┐
                                           │ 微信用户 │
                                           └────────┘
```

核心边界：**Personal Runtime 是唯一长期运行中心**。Web、微信和未来 Desktop 都只是客户端或 Channel，不拥有独立 Agent Runtime。

## 3. 解决方案策略

### 3.1 独立 Personal Runtime

Yuanyi-Pi 新增独立代码域：

```text
Yuanyi-Pi/
├── pi/
├── pi-web/
└── personal-runtime/
```

`personal-runtime` 负责 Personal Gateway、Session Router、Runtime Manager、PiRuntimeAdapter、Channel Runtime、微信 Channel Adapter、Session Metadata 和模型选择适配。

### 3.2 迁移而不是重写 Pi Web Runtime 逻辑

一期优先把 Pi Web 当前成熟的 Session Runtime 包装逻辑从 Web 进程中抽离：

```text
pi-web/lib/rpc-manager.ts
          ↓
Personal Runtime
```

保留并复用已有能力语义：Session 创建 / 恢复、Prompt、Streaming Event、Abort、Steer / Follow-up、Model、Thinking Level、Tool、Compaction 和 Runtime 生命周期。

当前基于 `globalThis` 的 Session Registry 改为 Runtime Manager 的显式实例状态。

### 3.3 Web 保留 BFF，Runtime 下沉

```text
Browser
  ↓
Pi Web API / BFF
  ↓
Personal Gateway
  ↓
Runtime Manager
  ↓
PiRuntimeAdapter
  ↓
AgentSession
```

一期不要求浏览器直接调用 Gateway，以最大程度保持现有 Pi Web 前端接口和同源访问方式。未来 Desktop 可直接使用 Gateway。

### 3.4 Session 单一身份

一期以 **Pi Session ID** 作为统一 Session 主身份，避免维护 Personal Session ID + Pi Session ID 双主键。

Personal Runtime 只保存 Pi Session 没有的产品元数据，例如：

- 用户是否显式绑定项目目录；
- Session 来源 Channel；
- 微信联系人当前活动 Session；
- 可选 Model Preset 引用。

### 3.5 “无项目”与 Pi `cwd` 解耦

```text
无项目：
projectDirectory = null
runtimeCwd       = 安全默认运行目录

有项目：
projectDirectory = 用户本地真实目录
runtimeCwd       = projectDirectory
```

这样既兼容 Pi 当前需要 `cwd` 的运行机制，又不会把默认运行目录错误展示成项目。

### 3.6 Channel 原生、Transport 可替换

```text
Channel Runtime
├── Identity
├── Session Mapping
├── Message Contract
├── Reply
└── Proactive Send
        ↓
WeChatChannelAdapter
        ↓
WeChatTransport
```

一期不建设通用插件系统。

### 3.7 Pi Package 原生兼容

Tool、Skill、Extension、MCP、Subagent 等 Agent 侧能力继续由 Pi Engine / Pi Package 生态承载，Personal Runtime 不重新包装一套 Agent Plugin 体系。

## 4. 构建块视图

```text
Yuanyi-Pi
│
├── pi/                  # Agent Engine
├── pi-web/              # Web Product / BFF
└── personal-runtime/
    ├── gateway/         # HTTP / SSE 入口
    ├── session/         # Session Router / Service
    ├── runtime/         # Runtime Manager / Lock
    ├── pi-adapter/      # PiRuntimeAdapter
    ├── channel/         # Channel Runtime / WeChat
    ├── model/           # Session Model Selection
    └── metadata/        # Personal Metadata
```

### Personal Gateway

负责 Web Session Command、Streaming Event、Channel Runtime 的统一 Agent 调用入口和 Session 查询；不实现 Agent Loop。

### Session Router

负责创建 / 定位 Session，把 Web / 微信请求路由到统一 Session，并维护 Channel 与 Session 的绑定关系；不复制 Pi Session 历史。

### Runtime Manager

负责 `sessionId -> active AgentSession`、单 Session 并发保护、Runtime 创建 / 恢复 / 空闲回收 / 销毁。

### PiRuntimeAdapter

屏蔽 Pi SDK 具体 API，封装 Session 创建 / 恢复、Prompt / Event / Abort、Model / Thinking / Tool 等能力。

### Channel Runtime

负责 Channel 身份、入站消息、Session 选择与绑定、回复和主动发送。一期只实现微信。

### Metadata Store

只保存 Personal 产品元数据，不复制 Pi 对话正文。

## 5. 运行时视图

### 5.1 Web 新建 Session

```text
Browser → Pi Web → Personal Gateway → Session Router
→ Runtime Manager → PiRuntimeAdapter → AgentSession
```

### 5.2 Web 继续 Session

```text
sessionId
  ↓
Runtime 已存在 → 直接复用
Runtime 不存在 → 从 Pi Session 恢复
  ↓
Prompt / Streaming
```

### 5.3 微信首次对话

```text
WeChatTransport
→ WeChatChannelAdapter
→ 无活动 Session
→ 创建无项目 Session
→ AgentSession
→ 回复微信
```

### 5.4 微信继续已有 Session

微信联系人维护 `activeSessionId`。用户明确选择已有 Session 后，后续普通消息继续该 Session。

具体文本交互在实现前做最小产品确认，不改变底层 Contract。

### 5.5 主动微信消息

```text
Personal Runtime
→ Channel Runtime.send()
→ WeChatChannelAdapter
→ WeChatTransport
→ 指定联系人
```

### 5.6 Session 级模型切换

```text
Web → set_model → Gateway → Runtime Manager
→ PiRuntimeAdapter → AgentSession.setModel()
```

## 6. 部署视图

一期按本地单用户 Personal Agent 设计：

```text
本地设备
├── Pi Web Process
├── Personal Runtime Process
│   └── WeChat Transport / Adapter
├── Pi Session / Agent Data
├── Yuanyi Personal Metadata
└── 用户本地项目目录
        │
        ▼
   Remote LLM Provider
```

开发 / 生产代码治理：

- `Yuanyi-Pi-dev`：开发验证；
- `Yuanyi-Pi-prod`：稳定运行；
- Pi + Pi-Web + Personal Runtime 使用同一产品 Git 版本发布；
- `pi-upstream` 只用于官方 Pi 对照。

## 7. 架构决策

### AD-001 Personal Runtime 独立于 Pi Web

原因：微信、未来 Desktop、主动消息和后台能力不能依赖 Web Server 生命周期。

代价：增加一个长期运行进程和进程间通信。

### AD-002 一期不重写 Pi Agent Runtime

优先迁移 / 复用 Pi Web 当前已验证的 Session Runtime 语义，降低功能回归和一期复杂度。

### AD-003 Pi Session ID 作为一期统一 Session ID

避免双主键和历史迁移。未来只有出现明确跨 Engine Session 需求时再引入独立 Personal Session ID。

### AD-004 Web 保留 BFF

最大程度保持 Pi Web 当前前端接口和同源访问方式，同时把 Runtime Ownership 下沉。

### AD-005 真实项目目录与 Runtime CWD 分离

Pi 需要 `cwd`，但“无项目”是用户产品语义，不能直接等价为无运行目录。

### AD-006 产品语义原生、实现可替换

Channel / Session / Runtime 为原生能力；微信 Transport 等外部实现保持可替换。

### AD-007 Pi Package 保持原生能力面

Personal Runtime 不重新建设一套 Agent Plugin API。

## 8. 质量需求

- **会话一致性**：同一 Session 经 Web / 微信继续时不得串线、复制或丢失上下文。
- **可恢复**：Personal Runtime 重启后持久 Session 可按需恢复。
- **Web 回归最小化**：现有对话、Streaming、模型、本地项目上下文和 Session 继续能力不得明显退化。
- **Channel 可替换**：更换微信 Transport 不修改 Session / Pi Runtime 核心。
- **上游可控**：Pi upstream 大改不得自动进入 Yuanyi-Pi 生产运行。
- **下一期可演进**：Desktop 只增加 Client，不重构 Session / Runtime 核心边界。

## 9. 风险

### R-001 微信接入稳定性

个人微信具体 Transport 可能存在登录、协议或账号风险。策略：Transport 独立、先 PoC、可替换。

### R-002 同 Session 多入口并发

Web 与微信可能同时发消息。策略：Runtime Manager 必须提供单 Session 串行化 / 状态保护。

### R-003 Pi Web 功能回归

`rpc-manager.ts` 当前承载较多 Runtime、Widget、Tool 和 Event 逻辑。策略：以现有测试为回归基线，优先保持 Command / Event 语义。

### R-004 Pi upstream API 变化

策略：所有 Pi 调用收敛到 PiRuntimeAdapter，上游选择性同步。

### R-005 元数据与 Pi Session 不一致

策略：Pi Session 是对话事实源；Personal Metadata 只保存补充字段，加载时以 Pi Session 是否真实存在为准。

### R-006 一期范围膨胀

策略：只实现 PRD 已冻结闭环，Memory、Scheduler、Desktop、Subagent 等不进入一期。
