---
type: 架构设计
status: 草稿
version: v1.0
depends_on: 基准事实-v1.2; PRD-002-v1.0; AnalysisReport-001-v1.0
owner: 缘一
created: 2026-08-20
updated: 2026-08-20
---

# 架构设计-002：Runtime 与服务生命周期收口

## 约束

### 已有系统事实

第一轮已存在并投入真实运行的主要构件：

```text
pi-web
personal-runtime
  ├── Personal Gateway
  ├── Session Router
  ├── Runtime Manager
  ├── PiRuntimeAdapter
  └── WeChat Channel
pi
pi-permission-system
```

本轮不是重新设计一期主架构，而是修正已经暴露的运行边界问题。

### 产品约束

- 微信必须在 Web 数天不启动时仍保持在线；
- 用户只感知一个 Yuanyi-Pi；
- Web 可高频重启、升级，不得扩大到 Runtime 故障域；
- Session 仍是一级对象；
- 不新增 Profile / 虚拟 Project；
- 不在本轮增加 Memory、Scheduler、Desktop 等新产品范围。

### 技术约束

- Web 与 Personal Runtime 保持独立进程；
- Agent Runtime 继续基于 `AgentSession`；
- Web 继续保留 BFF，当前不要求 Browser 直连 Gateway；
- 现有 Session 数据和 Pi 运行数据格式不做大迁移；
- 优先小范围收口，不重写已经验证可用的 Channel 和 Gateway 主链。

## 上下文

当前主要矛盾不是“Gateway 要不要存在”，而是：

```text
逻辑上：
Web → Gateway → Runtime

现实中：
Web → Gateway → Runtime
  └────────────→ 部分 rpc-manager Runtime
```

同时生命周期还是：

```text
Web / 手工脚本
      ↓
谁先启动都可能成为 Gateway 启动者
      ↓
Personal Runtime
```

导致：

- Runtime Ownership 没有完全唯一；
- Gateway 没有唯一生命周期 Owner；
- 两进程基础设施细节泄漏给用户；
- 长任务和多入口并发缺少最终正确性收口。

## 解决方案策略

### 1. 保留双进程，重构生命周期关系

目标关系：

```text
              System Supervisor
                     │
                     ▼
              Personal Runtime
              长期后台核心服务
                     │
        ┌────────────┼────────────┐
        │            │            │
   AgentSession    WeChat      Future
     Runtime       Channel    Background
        ▲
        │ HTTP / SSE
        │
      Pi Web
   按需启动 / 重启
        ▲
        │
      Browser
```

固定规则：

- Personal Runtime 不依赖 Pi Web 生命周期；
- Pi Web 不拥有 Runtime 启停权；
- Runtime 只有系统级 Supervisor 一个生命周期 Owner；
- Web 只负责连接、展示和 BFF。

### 2. Runtime Ownership 完全收敛到 Personal Runtime

Gateway 模式下：

```text
Personal Runtime
= 唯一可创建 / 恢复 / 持有 AgentSession 的进程
```

Pi Web 分成两类能力：

#### 允许保留在 Web

- UI；
- BFF；
- 纯只读文件展示；
- 不改变 Agent Runtime 的页面级逻辑。

#### 必须通过 Gateway

- Session Runtime 创建 / 恢复；
- Prompt / Abort / Steer / Follow-up；
- Running 状态；
- 与 Runtime 有关的 State / Context；
- 会导致 AgentSession 启动的 Auto-name；
- Session 删除前的 Runtime 协调；
- Project Trust 中与活跃 Runtime 有关的判断 / 处置。

### 3. Runtime Manager 成为并发和生命周期单一控制点

Runtime Manager 统一负责：

- `sessionId -> active Runtime`；
- Session 启动锁；
- 普通 Prompt 串行；
- 真实运行状态；
- Idle 回收；
- dispose / shutdown。

Channel、Gateway Route 和 Web 都不能各自实现另一套 Session 并发策略。

### 4. 真实 Agent 状态驱动 Idle

空闲判断采用：

```text
时间条件
+
PiRuntimeAdapter.getState()
```

只有满足：

```text
超过 idleTimeout
AND isStreaming = false
AND isIdle = true
```

才允许回收。

运行事件同时刷新活动时间，防止长时间 Tool / Thinking 阶段被误判为无活动。

### 5. 产品目录语义与 Runtime 目录语义分离到底

正式保持：

```text
projectDirectory
= 用户看到的真实项目语义

runtimeCwd
= Pi 实际执行目录
```

Web 的 Session DTO 和 UI 只用 `projectDirectory` 决定项目分组。

`runtimeCwd` 不用于项目分类。

### 6. Command Plane 与 Event Plane 分离

保持：

```text
Command:
Browser → Pi Web BFF → Gateway HTTP

Event:
AgentSession → Gateway SSE → Pi Web BFF → Browser
```

本轮不因为性能担忧直接取消 BFF。

Web BFF 必须尽量保持“薄代理”：

- 不缓存整轮回答；
- 不人为批量聚合 delta；
- 只做当前前端兼容所需的 Envelope 解包和 Event 映射。

### 7. 内部双进程，外部单产品

运行架构允许两个进程，但产品管理面只暴露：

```text
Yuanyi-Pi
├── Runtime 状态
├── Web 状态
├── WeChat 状态
├── 版本
└── 日志入口
```

用户不需要自己判断端口和 PID。

## 构建块视图

### Personal Runtime

继续包含：

```text
personal-runtime/
├── server/
├── session/
├── runtime/
├── pi/
├── channel/
├── metadata/
└── config/
```

本轮新增或强化的职责：

- Health；
- 单实例运行约束；
- Runtime 状态事实源；
- Running Session 状态；
- 运行事件时间戳；
- 可供 Web 查询的服务状态。

### Pi Web

本轮职责收敛为：

```text
UI
+
BFF
+
Stateless Compatibility Adapter
```

Web 不再拥有长期 Agent Runtime Registry。

### System Supervisor

新增部署级构件：

```text
System Supervisor
→ Personal Runtime
```

职责：

- 开机拉起；
- 单实例；
- 崩溃恢复；
- 标准日志；
- 进程生命周期。

具体 macOS 实现由技术设计冻结。

## 运行时视图

### Web 启动

```text
Pi Web start
    ↓
检查 Gateway Health
    ├─ healthy → 正常进入
    └─ unhealthy → 明确提示 Runtime 不可用

禁止：
Pi Web 自动创建第二个 Gateway
```

### Web Prompt

```text
Browser
  ↓
Pi Web BFF
  ↓
Gateway
  ↓
RuntimeManager
  ↓
普通 prompt → 串行队列
  ↓
PiRuntimeAdapter
  ↓
AgentSession
```

### Web 重启

```text
Pi Web stop / restart
       X
       │
Personal Runtime
       │
  AgentSession / WeChat
       │
     继续运行
```

### Runtime Idle

```text
scan
 ↓
超时？
 ↓ yes
getState()
 ├─ streaming / !idle → 保留
 └─ !streaming + idle → dispose
```

### Runtime 重启

```text
Supervisor 拉起新 Runtime 进程
        ↓
加载 Metadata / Channel State
        ↓
Session 不预热
        ↓
下一次访问时按 sessionId 恢复
```

## 部署视图

生产：

```text
macOS
├── System Supervisor
│   └── Personal Runtime :8770
│       └── WeChat 24h
│
├── Pi Web :30141
│   └── 按需启动
│
├── ~/.pi/agent
│   └── Pi 生产数据
│
└── ~/.yuanyi-pi
    └── Personal Metadata / Channel State / Logs
```

开发：

```text
Yuanyi-Pi-dev
+
独立 dev agentDir / dataDir / ports
```

开发不得与生产 Runtime 抢同一端口、数据目录或服务标识。

## 架构决策

### AD-201 双进程保留

Web 与 Personal Runtime 继续保持独立 OS Process。

原因：生命周期、故障域和未来后台能力不同。

### AD-202 Runtime 只由系统 Supervisor 托管

Web 不再启停 Runtime。

原因：避免重复启动、端口冲突和 Web 生命周期传染。

### AD-203 Web 保留 BFF

本轮不让 Browser 直连 Gateway。

原因：保持现有 Pi Web 协议和同源体验，先通过性能指标判断是否真的需要进一步变化。

### AD-204 Personal Runtime 是活状态事实源

所有 AgentSession 活状态和改变活状态的操作必须归 Personal Runtime。

### AD-205 性能问题以指标驱动

双进程不会因为“多一跳”就被否定。只有实测 BFF / SSE 额外延迟超过质量门槛，才进入下一次架构决策。

## 质量需求

### 一致性

- 一个 Session 一个 Runtime Owner；
- 无双写；
- Web / 微信并发行为可解释。

### 可用性

- Runtime 常驻；
- Web 可独立重启；
- 微信不依赖 Web。

### 性能

- Web/BFF → Gateway P95 ≤ 50 ms；
- Gateway Event → Browser P95 ≤ 50 ms；
- 无明显事件积压。

### 可维护性

- Pi SDK 调用继续收敛在 PiRuntimeAdapter；
- 生命周期管理不散落在多个脚本；
- Channel 不感知 Web。

## 风险

### R-201 Supervisor 配置错误

可能导致 Runtime 启动失败或循环重启。

策略：Health、日志和可回滚控制脚本。

### R-202 Web 残留 rpc-manager 路径遗漏

可能造成双 Runtime Owner。

策略：代码级全量扫描 + Gateway 模式运行测试。

### R-203 性能指标采集本身影响 Streaming

策略：只记录时间戳和轻量结构化数据，不在 token 热路径做重型日志。

### R-204 Runtime 重启时微信恢复不完整

策略：Channel State 与 Runtime 生命周期分别验证，进行长期在线测试。

### R-205 过度收口演变成大重写

策略：本轮只修真实问题，不借机重构所有旧 Web API。
