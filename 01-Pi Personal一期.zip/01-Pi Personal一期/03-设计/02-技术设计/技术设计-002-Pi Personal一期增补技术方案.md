---
type: 技术设计
status: 草稿
version: v1.0
depends_on: 基准事实-v1.1; PRD-001-v1.0; PRD-002-v1.0; ADR-001-v1.0
owner: 缘一
created: 2026-08-20
updated: 2026-08-20
---

# 技术设计-002：Pi Personal 一期增补技术方案

> 对应 PRD-002 三项增补需求（FR-101 / FR-102 / FR-103）。延续技术设计-001 的模块边界与"照抄 nanobot 机制"原则。

## 1. FR-101 微信"正在输入"（typing indicator）

### 机制（照抄 nanobot runtime.py）

```text
收到入站消息
  → getconfig {ilink_user_id, context_token} → typing_ticket
  → sendtyping {ilink_user_id, typing_ticket, status:1}   # 显示"正在输入"
  → keepalive：每 5s sendtyping(status:1)                 # 长任务持续
  → 回复发送完成后 sendtyping(status:2)                    # 取消
```

要点（照抄 nanobot 常量与缓存策略）：

- `TYPING_STATUS_TYPING=1` / `TYPING_STATUS_CANCEL=2`；
- `TYPING_KEEPALIVE_INTERVAL_S=5`：keepalive 间隔；
- typing_ticket 按联系人缓存，`TYPING_TICKET_TTL_S=24h` 内复用，获取失败指数退避（`CONFIG_CACHE_INITIAL_RETRY_S=2` → `CONFIG_CACHE_MAX_RETRY_S=1h`）；
- ticket 失效 / 获取失败时静默跳过（不阻塞回复）；
- 多条消息同时处理时，新的 typing 会先 stop 旧的再 start（`_start_typing` 先 `_stop_typing`）。

### 实现改动

| 文件 | 改动 |
|---|---|
| `personal-runtime/src/channel/wechat/transport.ts` | 新增 `startTyping(contactId)` / `stopTyping(contactId)`：ticket 缓存（Map）、keepalive timer、状态管理 |
| `personal-runtime/src/channel/wechat/adapter.ts` | 入站消息处理：`startTyping` → prompt → 回复完成后 `stopTyping` |

ilink.ts 已有 `getConfig` / `sendTyping`（照抄时已含），无需新增协议层。

## 2. FR-102 渠道管理界面

### 架构（延续"Web BFF → Personal Gateway"边界）

```text
pi-web ChannelsConfig（弹窗）
   ↓ fetch
pi-web BFF（app/api/personal/channels/...）
   ↓ HTTP 转发
Personal Gateway（/v1/channels/wechat/...）
   ↓
WechatConnectStore（扫码会话）+ WeChatTransport
```

### 2.1 Personal Runtime 新增

#### `connect-store.ts`（照抄 nanobot `connect.py`）

扫码连接会话管理（WebUI 驱动）：

```ts
class WechatConnectStore {
  start(force): { session_id, qr_url, status: "pending", interval_ms, expires_at_ms }
  poll(session_id, verify_code): { status: "pending|succeeded|failed|expired|...", bot_token?, ... }
  cancel(session_id)
}
```

- `start`：调 `ilink/bot/get_bot_qrcode`（带 local_token_list）→ 返回二维码；
- `poll`：调 `ilink/bot/get_qrcode_status`，处理 confirmed（commit token）/ expired（刷新 QR ≤3）/ need_verifycode / verify_code_blocked / binded_redirect / scaned_but_redirect；
- 会话 10 分钟过期清理；
- 成功后将 token 写入 account.json（复用 `WechatStateStore`），与 CLI 登录一致。

#### Gateway 渠道端点

| 端点 | 用途 |
|---|---|
| `GET /v1/channels/wechat` | 渠道状态：connected / running / account / auth_expired |
| `POST /v1/channels/wechat/connect` | 开始扫码（force 可选）→ `{session_id, qr_url, ...}` |
| `GET /v1/channels/wechat/connect?session_id=&action=poll[&verify_code=]` | 轮询扫码状态 |
| `POST /v1/channels/wechat/connect/cancel` | 取消 |

渠道状态来源：`WechatStateStore`（token 是否存在）+ transport 运行状态。

### 2.2 pi-web 新增

| 文件 | 说明 |
|---|---|
| `lib/personal-gateway.ts` | 加 `gatewayChannelStatus()` / `gatewayChannelConnectStart()` / `gatewayChannelConnectPoll()` / `gatewayChannelConnectCancel()` |
| `app/api/personal/channels/route.ts` | BFF：GET 渠道状态 |
| `app/api/personal/channels/wechat/connect/route.ts` | BFF：POST 开始 / GET 轮询 / POST cancel |
| `components/ChannelsConfig.tsx` | 渠道管理弹窗（仿 nanobot WeixinPanel）：微信 Logo（#07C160）、状态徽章（已连接/未连接/连接中/失效）、连接按钮、二维码展示 + 轮询状态（等待/已确认/过期/失败/需验证码）、验证码输入框、基础配置（授权联系人） |

视觉说明：pi-web 使用内联 style（非 Tailwind），仿照 nanobot 的**结构、状态流转、交互逻辑**，视觉适配 pi-web 现有风格。

### 2.3 一期渠道配置（7 项，全部有真实微信端效果）

| 配置 | 类型 | 微信端效果 | 映射 |
|---|---|---|---|
| 授权联系人 | 主设置 | 仅授权联系人的私聊进入 Agent | `transportConfig.allowFrom` |
| 处理中提示 | 主设置 | Agent 处理时微信显示"正在输入"与进度提示 | adapter typing（FR-101）+ sendProgress 行为 |
| 工具提示 | 主设置 | Agent 调用工具时微信收到合并提示（"正在读取文件…"） | adapter 订阅 Pi `tool_execution_start` → 合并缓冲发送（照抄 nanobot `_flush_tool_hints`，避配额 ~7msgs/5min） |
| 结构化进度 | 高级设置 | 工具开始/完成/失败的结构化状态消息 | adapter 订阅 tool 事件 → `tool_call_start/result` item（照抄 `_send_structured_progress`） |
| 结构化进度上限 | 高级设置 | 限制进度消息条数（默认 2） | adapter 计数 |
| 分块发送回复 | 高级设置 | 长回复生成中分段送达 | adapter 订阅 `message_update` 增量 → 照抄 `_flush_stream_block` |
| 最小分块字符数 | 高级设置 | 触发分块的最小字符数（默认 1200，范围 200-1800） | 同上 |
| 分块消息上限 | 高级设置 | 中途分块条数上限（默认 3，范围 1-4） | 同上 |

不暴露到 UI（代码层默认/系统管理）：baseUrl、cdnBaseUrl、stateDir、routeTag、token（扫码自动）、pollTimeout、streaming、sendProgress 独立开关（并入"处理中提示"）、contextMessageBudget（保留默认 8，不暴露）。

## 3. FR-103 左下角设置入口整合

### 现状

`pi-web/components/AppShell.tsx:932-975`：左下角三个按钮（模型 / 技能 / 插件），onClick 分别打开 `ModelsConfig` / `SkillsConfig` / `PluginsConfig` 弹窗。

### 改动（AppShell.tsx）

```text
左下角 [模型][技能][插件]          →    [⚙ 设置]
                                          ↓ 点击向上弹出
                              ┌──────────┬──────────┬──────────┬──────────┐
                              │ 模型      │ 技能      │ 插件      │ 渠道      │
                              └──────────┴──────────┴──────────┴──────────┘
```

- 保留原三个入口的 `onClick` / `disabled` 逻辑（技能、插件仍受 cwd 存在性约束）；
- 新增「渠道」入口 → `setChannelsConfigOpen(true)` → `ChannelsConfig` 弹窗；
- 下拉面板向上弹出，复用 pi-web `AnimatedDropdown`（SessionSidebar 已用）交互模式。

## 4. UI 视觉设计规范（FR-102 / FR-103）

> 依据 ui-ux-pro-max 设计库（Micro-interactions 风格 + AI 工具产品型），核心原则：**与 pi-web 现有视觉体系严格协调**（复用 CSS 变量，亮/暗双主题自动适配），微信品牌色仅作渠道识别，不引入独立配色。

### 4.1 设计基础

- **主题变量**：一律使用 pi-web 现有 `var(--bg / --bg-panel / --bg-hover / --bg-selected / --border / --text / --text-muted / --text-dim / --accent / --accent-hover)`，不新增硬编码色值；亮/暗主题自动生效；
- **语义状态色**：成功 `#22c55e`、失败 `#ef4444`、进行中蓝 `var(--accent)`（沿用现有语义）；
- **微信品牌色** `#07C160`：仅用于微信 Logo 圆角方块底色与“已连接”状态点，不放大面积使用；
- **圆角/阴影**：弹窗容器与现有 Modal 一致（12px 圆角、`var(--bg-panel)` 背景、`1px var(--border)` 边框）；下拉菜单沿用现有 `AnimatedDropdown`（8px 圆角、`boxShadow: 0 6px 20px rgba(0,0,0,0.10)`）；
- **图标**：全部 SVG（内联），不使用 emoji（预交付清单强制项）；
- **字体**：沿用 pi-web 现有字体栈（system/Inter），不引入新字体。

### 4.2 FR-103 左下角「设置」按钮

- **按钮**：齿轮 SVG（14px，`currentColor`）+ 标签「设置」，hover `var(--bg-hover)` 背景，150-200ms 过渡，`cursor: pointer`，可键盘聚焦（focus 可见）；
- **弹出菜单**（向上）：四入口，每项 = 14px 图标 + 标签，hover 高亮（150-200ms），间距 4-8px；
  - 模型（grid 图标）/ 技能（layer 图标）/ 插件（plug 图标）沿用现有图标；
  - 渠道（link/微信图标）新增；
  - 技能、插件保留 `disabled` 逻辑（无 cwd 时置灰 + `cursor: not-allowed`）；
- **交互**：点击展开/收起；展开时点击菜单外区域关闭；`aria-expanded` 标注状态。

### 4.3 FR-102 渠道面板（ChannelsConfig）

结构（从上到下）：

1. **头部**：标题「渠道」+ 关闭 ×（与 ModelsConfig 同款）；
2. **微信卡片**（12px 圆角、`var(--bg)` 背景、`1px var(--border)` 边框、12px padding）：
   - 左：微信 Logo（40px 圆角方块 `#07C160` + 白色微信气泡 SVG）；
   - 名称「微信」+ 描述「在微信中与 Personal Agent 对话」；
   - 右：状态徽章（6px 圆点 + 文案）：
     - 已连接：绿点 `#22c55e`「已连接」；
     - 连接中：accent 蓝 + 旋转 spinner「连接中…」；
     - 未连接：灰点「未连接」；
     - 失效：红点「已失效，请重新扫码」；
   - 连接/断开按钮（accent 实心按钮 / 描边按钮，hover 150-200ms）；
3. **连接流程**（未连接时，二维码区白色 `#fff` 背景居中显示 QR）：
   - 状态文案：等待扫码 / 已确认 / 已过期（附“刷新二维码”按钮）/ 失败（显示原因）/ 需验证码；
   - 需验证码：输入框（`h-32px`、数字键盘）+「验证」按钮；
   - 所有等待态显示 spinner（>300ms 操作必须有反馈）；
4. **基础配置**（折叠 `<details>` 仿 nanobot advanced）：授权联系人（文本框，逗号分隔，留空=全部）；
5. **保存反馈**：保存中 spinner → 成功「已保存」1.5s 后消失（仿 nanobot Saved settings）。

无障碍：状态徽章 + 文案双通道（不只靠颜色）；验证码输入有 label；所有按钮 aria-label；键盘可达。

## 5. 测试与验证
| 需求 | 验证 |
|---|---|
| FR-101 | 真实微信：发消息 → 微信显示"正在输入" → 回复到达后消失；长任务期间持续 |
| FR-102 | dev Web：设置 → 渠道 → 微信面板 → 扫码连接 → 状态流转正确 → 连接后微信可对话 |
| FR-103 | dev Web：左下角设置按钮 → 四个入口弹出 → 各入口行为与整合前一致 |

## 5. 风险与边界

- typing 是 best-effort（nanobot 同策略）：ticket 获取失败静默跳过，不影响回复；
- 渠道连接与 CLI 登录共用 account.json，任一路径登录后状态一致；
- 渠道界面仅微信，不建渠道插件市场（延续一期边界）；
- 本增补不改变 Session / Runtime / Gateway 核心契约。
