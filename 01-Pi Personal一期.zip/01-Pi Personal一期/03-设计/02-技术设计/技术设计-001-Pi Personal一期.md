---
type: 技术设计
status: 草稿
version: v1.0
depends_on: 基准事实-v1.1; PRD-001-v1.0; 架构设计-001-v1.0
owner: 缘一
created: 2026-08-20
updated: 2026-08-20
---

# 技术设计-001：Pi Personal 一期

## 1. 技术选型

### 1.1 运行语言

Personal Runtime 使用 **TypeScript + Node.js 22.19+**。

原因：Pi 与 Pi Web 均为 TypeScript / Node 技术栈，可直接复用 Pi SDK 类型与运行逻辑，降低多语言进程复杂度。

### 1.2 代码位置

```text
Yuanyi-Pi/
├── pi/
├── pi-web/
└── personal-runtime/
```

`personal-runtime` 是独立 Node Package / Service。

### 1.3 通信方式

一期采用：

- **HTTP JSON**：Session Query / Command；
- **SSE**：Agent Streaming Event。

Pi Web 保留现有 Next.js API 作为 BFF，由 BFF 转发到 Personal Runtime。

一期不引入 WebSocket。

### 1.4 Session 持久化

对话正文继续由 Pi 原生 Session Manager / JSONL 保存。

Personal Runtime 不复制消息正文，只保存产品补充元数据。

### 1.5 Personal Metadata

一期采用：

> `MetadataStore` 抽象 + 本地 JSON 文件实现。

原因：一期为单用户、单 Personal Runtime 进程，数据规模小；避免提前引入数据库依赖，同时保留未来替换 SQLite 的边界。

写入必须采用临时文件 + 原子替换，并保证单进程串行写。

### 1.6 微信

当前只冻结：

```text
WeChatChannelAdapter
        ↓
WeChatTransport
```

具体 Transport 必须先通过 PoC，再通过 ADR / 技术设计增补冻结。

### 1.7 Pi SDK

一期基于 Yuanyi-Pi 中成熟的 `AgentSession`、`createAgentSessionServices()`、`createAgentSessionFromServices()` 等机制。

所有 Pi API 调用收敛到 `PiRuntimeAdapter`。

## 2. 模块设计

### 2.1 `personal-runtime`

```text
personal-runtime/
├── src/
│   ├── server/
│   ├── session/
│   ├── runtime/
│   ├── pi/
│   ├── channel/
│   │   └── wechat/
│   ├── model/
│   ├── metadata/
│   └── config/
└── test/
```

### 2.2 Session Router

```ts
type SessionTarget =
  | { type: "existing"; sessionId: string }
  | { type: "new"; projectDirectory?: string | null; model?: ModelSelection };
```

职责：验证目标 Session、创建 / 读取 Personal Metadata、调用 Runtime Manager、返回统一 Session Descriptor。

### 2.3 Runtime Manager

```ts
Map<SessionId, RuntimeEntry>
```

```ts
interface RuntimeEntry {
  sessionId: string;
  runtime: PiRuntimeAdapter;
  lastActiveAt: number;
  state: "starting" | "ready" | "busy" | "disposing" | "error";
}
```

必须保证：

- 同一 `sessionId` 并发启动只产生一个 Runtime；
- 同一 Session 普通 Prompt 默认串行；
- 空闲回收只释放内存 Runtime，不删除持久 Session；
- Runtime 重建不改变 `sessionId`。

### 2.4 PiRuntimeAdapter

```ts
interface PiRuntimeAdapter {
  readonly sessionId: string;

  getState(): Promise<SessionRuntimeState>;
  prompt(message: string, options?: PromptOptions): Promise<PromptAck>;
  sendCommand(command: SessionCommand): Promise<unknown>;
  subscribe(listener: (event: GatewayEvent) => void): () => void;
  abort(): Promise<void>;
  setModel(model: ModelSelection): Promise<void>;
  setThinkingLevel(level: ThinkingLevel): Promise<void>;
  dispose(): Promise<void>;
}
```

一期允许内部复用 / 迁移 Pi Web 当前 `AgentSessionWrapper` 逻辑，但外部只能依赖 Adapter Contract。

### 2.5 Channel Runtime

```ts
interface ChannelAdapter {
  readonly channelType: string;
  start(): Promise<void>;
  stop(): Promise<void>;
  reply(target: ChannelAddress, message: OutboundMessage): Promise<void>;
  send(target: ChannelAddress, message: OutboundMessage): Promise<void>;
}
```

统一入站消息：

```ts
interface InboundChannelMessage {
  channelType: string;
  accountId: string;
  contactId: string;
  messageId: string;
  text: string;
  receivedAt: number;
}
```

### 2.6 WeChatChannelAdapter

职责：

- 只接受已授权私聊联系人；
- 把 Transport 消息映射为统一入站消息；
- 查找联系人 `activeSessionId`；
- 无活动 Session 时自动创建无项目 Session；
- 将普通消息发送到当前 Session；
- 负责回复和主动发送；
- 不直接 import Pi SDK。

### 2.7 Model Selection

一期不新建完整 Model Preset 管理中心。

```ts
interface ModelSelection {
  provider: string;
  modelId: string;
  presetId?: string;
}
```

规则：

- Session 的模型运行事实最终落到 Pi 当前 Model State；
- `presetId` 只作为可选产品引用；
- Credential 继续由 Pi Provider / Auth 机制解析；
- 同一厂商多套 Credential 优先使用已配置 Provider Alias，不把 Secret 写入 Session Metadata。

## 3. 接口设计

### 3.1 Gateway Contract

一期统一为三类：

```text
Session Query
Session Command
Session Event
```

### 3.2 Session Query

#### `GET /v1/sessions`

返回：

```text
Pi Persisted Sessions
+
Active Runtime State
+
Personal Metadata
```

#### `GET /v1/sessions/{sessionId}`

```ts
interface SessionDescriptor {
  sessionId: string;
  title?: string;
  projectDirectory: string | null;
  runtimeCwd: string;
  originChannel?: string;
  model?: ModelSelection;
  running: boolean;
  createdAt?: number;
  updatedAt?: number;
}
```

### 3.3 创建 Session

#### `POST /v1/sessions`

```json
{
  "projectDirectory": null,
  "model": {
    "provider": "provider-id",
    "modelId": "model-id"
  }
}
```

规则：

```text
projectDirectory = null
→ runtimeCwd = configuredNeutralCwd

projectDirectory != null
→ runtimeCwd = projectDirectory
```

### 3.4 Session Command

#### `POST /v1/sessions/{sessionId}/commands`

```ts
type SessionCommand =
  | { type: "prompt"; message: string }
  | { type: "abort" }
  | { type: "steer"; message: string }
  | { type: "follow_up"; message: string }
  | { type: "set_model"; model: ModelSelection }
  | { type: "set_thinking_level"; level: string }
  | { type: "set_tools"; toolNames: string[] }
  | { type: "compact" }
  | { type: "get_state" };
```

Gateway Contract 保留 Pi Web 当前核心操作能力，避免 Web 回归。

### 3.5 Streaming

#### `GET /v1/sessions/{sessionId}/events`

SSE Envelope：

```ts
interface GatewayEvent {
  sessionId: string;
  sequence: number;
  type: string;
  timestamp: number;
  payload: unknown;
}
```

一期 `payload` 允许与现有 Pi Web Runtime Event 高度兼容，先保证迁移完整性；后续再逐步收敛稳定公共事件。

### 3.6 微信 Session Binding

每个授权微信联系人维护：

```text
activeSessionId
```

行为：

- 无绑定 + 普通消息 → 自动创建无项目 Session 并绑定；
- 已绑定 + 普通消息 → 继续当前 Session；
- 用户触发“新会话” → 创建并切换；
- 用户触发“会话列表 / 切换会话” → 切换绑定。

具体文本命令 / 文案在实现前做最小产品确认，不改变底层 Contract。

### 3.7 主动发送

```ts
channelRuntime.send({
  channelType: "wechat",
  contactId,
  text,
  sessionId
});
```

主动发送默认不改变联系人的 `activeSessionId`。

## 4. 数据设计

### 4.1 Pi Session

Pi 原生 Session 继续作为**对话历史和 Agent 运行状态的事实源**。

不得复制消息正文到 Personal Metadata。

### 4.2 Personal Metadata

一期结构：

```json
{
  "version": 1,
  "sessions": {
    "<sessionId>": {
      "projectDirectory": null,
      "originChannel": "web",
      "modelPresetId": null
    }
  },
  "channelBindings": {
    "wechat": {
      "<accountId>:<contactId>": {
        "activeSessionId": "<sessionId>"
      }
    }
  }
}
```

### 4.3 无项目默认运行目录

配置 `neutralCwd`：

- 独立于真实用户项目目录；
- 不直接使用用户 Home 作为默认 cwd；
- 安全承载 Pi 无项目会话；
- Web 展示时仍归为“无项目”。

### 4.4 Session 数据合并规则

1. Pi Session 是否存在是第一真实性判断；
2. Pi Session 提供标题、历史和基础运行状态；
3. Personal Metadata 补充 `projectDirectory`、Channel Binding、Preset 引用；
4. Runtime Manager 补充 running / busy 等瞬时状态。

Metadata 存在但 Pi Session 不存在时标记为 orphan，不自动生成虚假 Session。

### 4.5 数据目录

建议：

```text
Pi 原生数据：
~/.pi/agent/

Pi Personal 数据：
~/.yuanyi-pi/
├── metadata.json
├── runtime/
└── logs/
```

实际路径允许配置，但不修改 Pi 原生 Session 格式。

## 5. 异常处理

### 5.1 Runtime 启动失败

可能原因：Pi Session 损坏、cwd 不存在、Provider 初始化失败、Package / Extension 加载失败。

处理：Runtime 状态进入 `error`，不覆盖 Pi Session；Gateway 返回结构化错误；后续请求允许重试。

### 5.2 同 Session 并发请求

默认单 Session 普通 Prompt 串行。

- steer / follow-up 按 Pi 既有语义处理；
- 第二个普通 Prompt 不直接并发写 Session；
- Runtime Manager 排队或明确拒绝，最终策略以 Pi 原生行为验证结果为准。

### 5.3 SSE 断线

- Runtime 不因 Web SSE 断线终止；
- Client 可重新订阅；
- 已落盘消息通过 Session History 补齐；
- 服务端不无限缓存历史 Event。

### 5.4 Personal Runtime 重启

- Active Runtime Map 清空；
- Pi Session 不受影响；
- Metadata 重新加载；
- 下一次请求按 `sessionId` 恢复 AgentSession；
- 微信 `activeSessionId` 只要目标 Session 存在就继续有效。

### 5.5 微信掉线

- 不删除 Session Binding；
- 不影响 Web 使用；
- Transport 恢复后继续原绑定；
- 连续失败进入 degraded 状态并记录日志。

### 5.6 微信未授权联系人

一期默认拒绝把未授权联系人消息送入 Agent Runtime。

联系人授权只需提供配置能力，不在一期建设复杂 UI。

### 5.7 微信 Transport 不稳定

正式实现前必须 PoC 验证：登录、接收、回复、主动发送、重连、长时间在线稳定性、License 和账号风险。

未通过 PoC 不进入正式开发。

### 5.8 Pi API 变化

所有变化只允许影响 `PiRuntimeAdapter`，Gateway / Channel 不直接依赖 Pi 内部类型。

### 5.9 Web 迁移回滚

开发阶段允许短期保留旧 `rpc-manager` Runtime 路径作为回退手段。

Gateway 路径完成回归后，再删除或禁用旧路径；不得在未验证前一次性切断现有稳定链路。
