---
type: 技术设计
status: 草稿
version: v1.0
depends_on: 基准事实-v1.2; PRD-002-v1.0; 架构设计-002-v1.0; ADR-002-v1.0
owner: 缘一
created: 2026-08-20
updated: 2026-08-20
---

# 技术设计-002：Runtime 稳定化技术方案

## 技术选型

### 1. 系统服务

生产 macOS 使用 **launchd** 托管 `personal-runtime`。

原因：

- 系统原生；
- 支持登录后自动启动；
- 支持崩溃重启；
- 可以统一 stdout / stderr；
- 不需要额外引入 PM2、Docker 或其它后台运行框架。

技术原则：

```text
launchd
= Personal Runtime 唯一进程 Owner

pi-web
= 不再 start / stop Runtime
```

### 2. Web / Gateway 通信

继续使用：

- HTTP JSON：Command / Query；
- SSE：Agent Event。

本轮不切 WebSocket，不让 Browser 直接连 Gateway。

### 3. 性能观测

使用轻量时间戳埋点，不引入独立 APM。

至少记录：

```text
browser_sent_at
gateway_received_at
gateway_first_model_event_at
browser_first_event_at
```

开发 / 性能测试环境输出结构化日志；生产默认只保留汇总或可控日志级别。

## 模块设计

### 1. Personal Runtime Health

新增 Gateway Health：

```text
GET /health
```

建议返回：

```json
{
  "status": "ok",
  "version": "...",
  "pid": 12345,
  "runtime": "ready",
  "wechat": {
    "enabled": true,
    "connected": true
  }
}
```

Health 不读取重型 Session 数据，也不触发 AgentSession 创建。

### 2. launchd 服务

新增生产服务描述，例如：

```text
~/Library/LaunchAgents/ai.yuanyi.pi.runtime.plist
```

配置：

- `RunAtLoad = true`
- `KeepAlive = true`
- WorkingDirectory 指向 `Yuanyi-Pi-prod/personal-runtime`
- 明确注入：
  - `YUANYI_PI_DATA_DIR`
  - `YUANYI_PI_AGENT_DIR`
  - `YUANYI_PI_WECHAT_ENABLED`
- stdout / stderr 独立日志文件

具体 Label 可以调整，但生产只允许一个固定 Label。

### 3. Runtime 管理脚本

现有 `personal-runtime.sh` 从“自行 nohup 拉进程”调整为**系统服务控制器**。

目标命令：

```bash
personal-runtime.sh start
personal-runtime.sh stop
personal-runtime.sh restart
personal-runtime.sh status
personal-runtime.sh log
```

内部：

- `start`：检查 launchd / Health，已运行则直接返回；
- `stop`：通过 launchctl 停服务；
- `restart`：系统级重启；
- `status`：同时检查 launchd 状态 + `/health`；
- 不直接 `nohup npm start`；
- 不通过端口碰撞来判断重复实例。

### 4. Pi Web 启动器

所有 Web 启动入口必须移除：

```text
Runtime 未启动 → Web 自动拉起 Runtime
Web 退出 → 自动停止 Runtime
```

Web 只做：

```text
启动
↓
GET Gateway /health
├── healthy → 正常使用
└── unhealthy → 明确 Runtime 不可用
```

Gateway 不可达时，Web 不应长时间静默等待。

### 5. Runtime Ownership 清场

对 `pi-web` 全量扫描：

```text
startRpcSession
getRpcSession
getRpcSessionInfos
getRunningRpcSessionIds
destroyRpcSessionsForCwd
hasBusyRpcSessionForCwd
```

分类处理。

#### 5.1 Agent 核心路由

以下 Gateway 模式必须只走 Personal Runtime：

- `/api/agent/new`
- `/api/agent/[id]`
- `/api/agent/[id]/events`

保留 legacy 路径只能作为显式开发回退，稳定发布时不得在生产启用。

#### 5.2 Running Session

现有：

```text
/api/agent/running
/api/agent/running/events
```

不再读取 Web `rpc-manager` Registry。

Gateway 增加或复用统一活跃 Session 状态：

```text
GET /v1/runtime/running
GET /v1/runtime/running/events
```

如果前端不再需要专门 SSE，也可以由 `/v1/sessions` + Session Event 推导，但只保留一个事实源。

#### 5.3 Session 删除

删除流程：

```text
Web DELETE
→ Gateway
→ 如 Runtime active：dispose / abort policy
→ 删除持久 Session
→ 清 Personal Metadata / Channel Binding
→ 返回结果
```

不得由 Web 直接删除 Session 文件而 Gateway 仍持有 Runtime。

#### 5.4 Session State / Context / Auto-name

原则：

- 纯只读且不会启动 AgentSession 的文件读取可以留在 Web；
- 一旦逻辑需要活 Runtime，就必须走 Gateway；
- Auto-name 不允许通过 Web `startRpcSession()` 临时拉起第二个 Runtime。

#### 5.5 Project Trust

涉及活跃 Session 是否 busy / dispose 的行为必须通过 Gateway 查询或控制。

纯文件系统 Trust 配置可以继续留在 Web。

### 6. Prompt 串行修复

Gateway Command 入口改为显式分流：

```ts
switch (command.type) {
  case "prompt":
    return runtimeManager.prompt(sessionId, command.message);
  default:
    return runtimeManager.sendCommand(sessionId, command);
}
```

RuntimeManager：

- 继续以 `sessionId` 维护 `promptTails`；
- Prompt 完成后清理已完成 tail，避免 Map 长期增长；
- `steer / follow_up / abort` 不进入普通 Prompt 队列。

测试必须覆盖：

```text
Web prompt A
+
WeChat prompt B
→ 同 Session 串行
```

### 7. Idle 回收修复

当前 `scanIdle()` 不再只看 Registry 静态状态。

建议：

```ts
for each runtime:
  if now - lastActiveAt < idleTimeout:
    continue

  const state = await runtime.getState()

  if state.isStreaming || !state.isIdle:
    touch(sessionId)
    continue

  dispose(sessionId)
```

同时 Runtime Event 到达时调用：

```text
RuntimeManager.touch(sessionId)
```

避免长 Tool / Thinking / Streaming 阶段因没有新 Command 被判定为空闲。

### 8. 无项目 Session 修复

#### Web Session DTO

当前 Gateway Session 转 Web Session 时：

```text
cwd = runtimeCwd
```

改为：

```text
cwd = projectDirectory ?? ""
```

需要运行目录的内部调用单独使用 `runtimeCwd`，不复用 Web 项目字段。

#### SessionSidebar

移除新建按钮：

```text
disabled={!selectedCwd}
```

新建逻辑：

```text
selectedCwd 有值 → projectDirectory
selectedCwd 无值 → null
```

UI 明确展示：

```text
无项目
```

### 9. SSE 与性能

当前 `agent-event-stream-gateway.ts` 保留兼容适配，但增加轻量性能埋点。

#### Gateway

首次收到 Prompt：

```text
gateway_received_at
```

首次收到 Pi 输出 Event：

```text
gateway_first_model_event_at
```

Gateway Envelope 可在 debug / perf 模式额外带：

```json
{
  "perf": {
    "gatewayEventAt": 0
  }
}
```

生产常规协议不要求永久暴露全部性能字段。

#### Web

记录：

- BFF 收到 Gateway Event 时间；
- Browser EventSource / fetch stream 收到第一条事件时间。

性能测试脚本汇总：

```text
command_proxy_ms
model_ttft_ms
stream_proxy_ms
```

目标 P95：

```text
command_proxy_ms <= 50
stream_proxy_ms  <= 50
```

### 10. 自有 Pi 运行依赖

当前保持官方 npm 0.84.2，不在本轮强制切换。

增加一个发布前检查：

```text
如果 Yuanyi-Pi/pi 相比当前运行 Pi 存在自有 Core 修改
→ 禁止继续使用官方 npm 作为最终生产依赖
→ 必须先完成自有 Pi Build / Package 绑定
```

避免未来“代码改了但产品没消费”。

## 接口设计

### `GET /health`

用于：

- launchd 状态检查；
- Web 启动检查；
- 统一 status 命令。

### Runtime 状态

建议：

```text
GET /v1/runtime/running
```

返回：

```json
{
  "sessionIds": ["..."]
}
```

如 Web 需要实时变化，再提供：

```text
GET /v1/runtime/running/events
```

SSE 只发 active set 变化，不复制 Agent Event。

### Session Delete

建议新增：

```text
DELETE /v1/sessions/{sessionId}
```

由 Personal Runtime 协调：

- Active Runtime；
- Pi Session file；
- Metadata；
- Binding。

### Performance Header / Trace

每次 Web Prompt 生成轻量 `requestId`：

```text
x-yuanyi-request-id
```

在 Web BFF 和 Gateway 日志中关联同一次请求。

## 数据设计

本轮不新增数据库。

沿用：

```text
~/.pi/agent
= Pi Session / Auth / Model

~/.yuanyi-pi
= Personal Metadata / Channel State
```

新增的仅是：

- Runtime log；
- 可选性能采样 log；
- launchd log。

不把性能埋点写进 Session 正文。

## 异常处理

### Gateway 已运行时再次启动

返回：

```text
Personal Runtime already running
Health: OK
```

不得再创建第二个进程。

### Gateway 未运行

Pi Web：

- 页面明确显示 Runtime unavailable；
- 不偷偷回退到 Web 自持 AgentSession 的生产路径；
- 提供可操作的状态提示。

### Gateway 崩溃

launchd 自动重启。

重启后：

- Metadata 重新加载；
- 微信恢复；
- Session 按需恢复；
- Web 重新连 Gateway。

### Web SSE 断开

- 不 abort Agent Run；
- Gateway Runtime 继续运行；
- Web 重连后通过 Session History + 新事件恢复显示。

### Prompt 并发

普通 Prompt 排队。

`steer / follow_up / abort` 走 Pi 原生行为。

### Idle 扫描失败

单个 Runtime `getState()` 失败：

- 不直接 dispose；
- 标记 warning；
- 下一扫描周期重试。

安全原则：

> 不确定是否真的 idle 时，宁可暂不回收。
