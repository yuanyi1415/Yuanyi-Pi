# LEARNINGS

> 记录项目执行中积累的经验与纠偏。格式：类别 + 事实 + 触发场景。

## knowledge_gap

### K-001：生产运行位置必须以实际监听进程为准（已闭环）
- 时间：2026-08-20（DEV111 核查）→ 已更新 2026-08-20
- 事实：首次核查时 Handoff 声称生产已切换到 `Yuanyi-Pi-prod/pi-web`，但实际 30141 运行的还是旧目录 `/Users/yuanyi/Desktop/AI/16_Pi Agent/pi-web`（官方 v0.8.9）。上报后项目负责人完成真实切换，现 PID 86537 运行于 `Yuanyi-Pi-prod/pi-web`（HTTP 200），与 Handoff 一致。
- 触发场景：判断生产运行位置时必须看**实际监听进程 cwd**，不能只信文档或目录结构；dev/prod 均配置 30141 端口，同机同时启动会冲突。
- 处理：已闭环，无需变更冻结文档。

## best_practice

### B-001：核验"哪个仓库在运行"应查进程 cwd + remote，而非目录是否存在
- 三库（pi-upstream / dev / prod）结构与"实际运行实例"是两回事。判断生产是否被 dev/prod 目录接管，必须看监听端口的进程 cwd 与 git remote。

### B-002：SSE 事件必须统一 envelope 格式（C-3 契约一致性）
- Gateway 的 state 初始快照若直接发裸对象（无 payload 字段），BFF 代理按 envelope 解包时 `payload` 为 undefined 会抛错。所有 SSE data 一律 `{sessionId,sequence,type,timestamp,payload}`。

### B-003：Streaming 验证必须"先连 SSE 再发 prompt"
- POST prompt 在 Gateway 侧会阻塞到 agent 完成（adapter.prompt 等 agent_end）；先 prompt 后连 SSE 会错过 streaming 事件，误判为故障。

### B-004：Pi 新 Session 无消息不落盘，恢复必须基于已落盘文件
- `SessionManager._persist` 仅在有 assistant 消息时写盘。因此"新建→dispose→恢复"链路对空 session 必然失败（无文件可读）；测试与产品都要先发消息落盘。

## knowledge_gap

### K-002：dev/pi-web dev 脚本端口与生产冲突（已修复）
- 事实：dev/pi-web 的 `scripts.dev/dev:lan/start/start:lan` 原写 `-p 30141`（与生产 Web 同端口），上级 README 却约定 dev Web=30142；直接 `npm run dev` 会 EADDRINUSE。
- 处理：2026-08-20 已由项目负责人确认后改为 30142，`npm run dev` 直接可用。
- 触发：在 dev 起 Web 时。

### K-003：微信 Transport 选型锚定 = 微信官方 ilinkai 接口，全面照抄 nanobot
- 决策：2026-08-20 项目负责人明确：微信 Transport 机制全面照抄 nanobot（`AI/13_nanobot-dev/nanobot/channels/weixin/`），不再自行研究 OCR/hook/wechaty 等方案。
- 关键事实：nanobot 用微信官方 ilinkai 接口（base_url=`https://ilinkai.weixin.qq.com`，MIT License）：扫码登录（get_qrcode/get_qrcode_status→bot_token）、长轮询接收（getupdates+get_updates_buf 游标）、发送（sendmessage+context_token，60s 主动刷新+每上下文配额）、在线通知（notifystart/notifystop）、重连退避（2s/30s，errcode -14 失效重扫码）。
- macOS 微信 4.1.8 屏蔽辅助功能内容树（实测），OCR/黑盒方案排除；官方接口无账号风险。
- 执行：以 nanobot weixin runtime.py（2590 行）为机制蓝本，移植为 TypeScript 版 WeChatTransport，对接 Channel Contract（C-4）。

### K-004：RuntimeManager 构造 agentDir 未传递 → 测试污染生产（已修复）
- 根因：`RuntimeManager.start()` 只读 `opts.agentDir`（getOrCreate 参数），构造时传入的 `this.opts.agentDir` 未透传。测试 `new RuntimeManager({agentDir: 临时})` 后 `getOrCreate({cwd})` 不带 agentDir → `PiRuntimeAdapter.create` 的 agentDir=undefined → 落到 SDK 默认 `getAgentDir()` = **生产 ~/.pi/agent**，session 全部写入生产。
- 影响：测试（gw-cwd/rm-cwd/sr-cwd/wx-cwd 等前缀）在生产 sessions 累积 45+ 目录；生产 Web 会话列表被污染。
- 修复：`start()` 改为 `opts.agentDir ?? this.opts.agentDir`；清理生产测试目录（mv 到 /tmp/pi-test-trash）；验证全量测试后生产目录数不变。
- 教训：SDK 的 `getAgentDir()` 默认是生产路径，任何未显式传 agentDir 的调用都会碰生产。新增代码路径必须显式传 agentDir（或依赖 PI_CODING_AGENT_DIR）。
