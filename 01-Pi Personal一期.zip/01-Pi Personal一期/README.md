---
type: README
status: 已完成
version: v1.4
owner: 缘一
created: 2026-08-20
updated: 2026-08-21（S6 封版）
---

# Pi Personal 一期

> 一句话描述：基于自主管理的 Yuanyi-Pi Agent Engine 构建面向个人长期使用的 Personal Agent，一期完成 Web + 微信私聊的统一 Session 闭环。

## 当前状态

**已完成（S6 封版，2026-08-21）**

- Constitution ✅ / Specify ✅ / Plan ✅ / Tasks ✅ / Environment ✅
- S1（工程基线与核心契约）✅ / S2（Personal Runtime 核心闭环）✅ / S3（Pi Web 接入与产品体验）✅ / S4（微信私聊接入）✅ / S5（跨 Channel 验收与发布）✅ / **S6（Runtime Ownership 与服务生命周期收口）✅**
- 提交基线：`d262a6732` + `9417ed3e8`（main），prod 已拉齐 `9417ed3e8` 并启动验证（personal-runtime 8770 + pi-web 30141）
- 封版后：**停止扩展 Personal Runtime**；新需求须作为新阶段单独立项

## 能力列表

已具备：

- Personal Runtime / Gateway；
- Web；
- 微信私聊（生产默认未启用，launchd 模板已含配置）；
- Web / 微信统一 Session；
- Session 级模型；
- 真实本地目录；
- 无项目 Runtime（独立 workspace）；
- Prepared Transaction（首次 Prompt preflight accepted 即正式化）；
- 生产 fail-closed（Gateway 不可用 → 503，无 Web 自持 Runtime）；
- Pi Package / Extension 基础兼容。

S6 收口完成：

- Runtime Ownership 唯一化；
- 双进程生命周期（Runtime 常驻，Web 按需）；
- Prompt 串行；
- Idle 回收；
- 无项目 Web 语义；
- SSE 懒恢复 / Streaming。

## 目录导航

见 [项目索引](项目索引.md)。

## 快速开始

一期已封版。生产使用见仓库根 README（`pi-web` / `pi-web.sh` 命令与数据目录铁律）。新能力建设须重新立项。

## 负责人

- 项目负责人：缘一
- Agent：负责调研、草拟、校核与实现，不得代替项目负责人冻结文档
