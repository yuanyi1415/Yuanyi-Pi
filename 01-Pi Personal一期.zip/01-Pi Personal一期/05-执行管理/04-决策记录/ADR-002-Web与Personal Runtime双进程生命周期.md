---
type: ADR
status: 草稿
version: v1.0
depends_on: 基准事实-v1.2; PRD-002-v1.0; 架构设计-002-v1.0
owner: 缘一
created: 2026-08-20
updated: 2026-08-20
---

# ADR-002：Web 与 Personal Runtime 双进程生命周期

## Context（背景与约束）

Pi Personal 已经实际形成两个进程：

- `pi-web`：Web UI / BFF；
- `personal-runtime`：Gateway、AgentSession、Session Router、微信 Channel。

真实使用确认了一个不可妥协的需求：

> 即使 Pi Web 数天没有启动，微信仍必须持续在线并可以接收、回复和主动发送消息。

因此 Personal Runtime 的生命周期天然长于 Web。

当前问题是生命周期管理仍处于过渡状态：Web 联动启动与手工脚本启动可以并存，已经实际发生重复启动 Gateway 导致端口冲突；用户也需要感知两个端口、两个进程和多个脚本。

同时，双进程比单进程多一层 localhost HTTP / SSE 和序列化处理，因此存在 Web Streaming 额外延迟担忧。

可选方案：

### 方案 A：重新合并成单进程

把 Web Server 与 Personal Runtime 放在同一个长期后台进程。

优点：

- 部署最简单；
- 无进程间 HTTP / SSE；
- 用户天然只看到一个服务。

代价：

- Web 重启会扩大到 Runtime、微信和长任务；
- UI 高频演进与 Agent Runtime 共享故障域；
- 后续 Desktop / Scheduler 仍要重新处理独立 Runtime 生命周期。

### 方案 B：保留双进程，但继续由 Web 按需拉起 Runtime

优点：

- 当前改动较小；
- 用户启动 Web 时自动可用。

代价：

- Web 不开时微信无法稳定满足长期在线目标；
- Web 与手工脚本都可能成为 Runtime Owner；
- 生命周期边界继续模糊。

### 方案 C：保留双进程，Runtime 独立系统托管

优点：

- Runtime 生命周期与 Web 真正解耦；
- 微信可 24h 在线；
- Web 可独立升级 / 重启；
- 未来后台任务和 Desktop 可复用 Runtime。

代价：

- 多一个本地 IPC；
- 需要系统级服务托管、Health 和日志；
- 内部调试仍有两个进程。

## Decision（决策）

我们将采用 **方案 C**：

> **Pi Web 与 Personal Runtime 保持两个独立 OS Process；Personal Runtime 成为长期系统服务，Pi Web 只作为按需客户端 / BFF。**

同时冻结以下规则：

1. Personal Runtime 只有系统级 Supervisor 一个生命周期 Owner；
2. Pi Web 不负责 Runtime 启动或停止；
3. Gateway 必须单实例；
4. Web 重启不得影响 AgentSession、微信和后台任务；
5. 用户体验上只暴露一个 Yuanyi-Pi 产品，不要求用户管理两个内部服务；
6. Web Streaming 性能通过 TTFT / Event 延迟指标验收；
7. 性能不达标时先优化 BFF / SSE，不直接取消 Runtime 独立进程。

当前 macOS 生产环境的具体 Supervisor 由技术设计选择。

## Consequences（后果）

### 正面

- 微信可以独立于 Web 长期在线；
- Web UI 更新和崩溃不会中断 Agent Runtime；
- Agent 长任务拥有稳定生命周期；
- 后续 Desktop、Scheduler、主动通知有自然接入点；
- Runtime Ownership 边界更清晰。

### 负面

- 引入 localhost IPC；
- 需要系统服务、Health、日志、单实例管理；
- 调试时需要区分 Web 和 Runtime 日志；
- BFF 仍有一定 Event 转换成本。

### 中性

- 用户仍只使用一个 Yuanyi-Pi；
- 两个进程是部署内部事实，不是两个独立产品；
- Browser 是否未来直连 Gateway 不在本 ADR 决定；
- 自有 `pi/` 的运行依赖切换属于另一项独立技术问题。
