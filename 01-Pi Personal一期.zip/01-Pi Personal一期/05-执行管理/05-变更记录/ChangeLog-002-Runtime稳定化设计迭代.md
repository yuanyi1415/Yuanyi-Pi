---
type: ChangeLog
status: 草稿
version: v1.0
depends_on: 基准事实-v1.2
owner: 缘一
created: 2026-08-20
updated: 2026-08-20
---

# ChangeLog-002

## 版本 v1.0（2026-08-20）

### Added

- 新增 PRD-002：Runtime 与服务架构稳定化。
- 新增架构设计-002：Runtime 与服务生命周期收口。
- 新增技术设计-002：Runtime 稳定化技术方案。
- 新增 ADR-002：Web 与 Personal Runtime 双进程生命周期。
- 新增 WBS-002：Runtime 稳定化收口。
- 新增 Stage-006。
- 新增 Runtime 稳定化 IssueLog 和源码核查 AnalysisReport。

### Changed

- 项目从“继续建设一期功能”转入“稳定化收口”。
- Personal Runtime 的定位从“独立 Gateway 进程”进一步明确为“长期系统后台核心服务”。
- Pi Web 明确为按需 UI / BFF，不拥有 Runtime 生命周期。
- Web 响应性能从主观体验升级为 T0–T3 可测量质量门槛。

### Deprecated

- Web 按需拉起并随自身退出关闭 Gateway 的生命周期模式。
- Gateway 模式下 Web 继续保留活 AgentSession Runtime 的过渡行为。

### Removed

- 无。

### Fixed

- 本文档只定义变更目标，具体修复将在 WBS-002 Implement 阶段执行。

### Security

- 保持 Personal Runtime 仅监听本机回环地址的原则。
