---
type: Handoff
status: 草稿
version: v1.0
depends_on: 基准事实-v1.1; PRD-001-v1.0; 架构设计-001-v1.0; 技术设计-001-v1.0; WBS-001-v1.0
owner: 缘一
created: 2026-08-20
updated: 2026-08-20
---

# Handoff-001：环境初始化转正式开发

## 1. 任务说明（交接目标）

本次交接用于将 **Yuanyi-Pi 本地工程环境初始化与切换** 正式移交到 **Pi Personal 一期 Implement 阶段**。

环境初始化任务已验收通过，下一步进入：

> **Stage-001：工程基线与核心契约**

本 Handoff 只记录当前真实状态、边界和接手要求，不替代 PRD、架构设计、技术设计或 WBS。

## 2. 上下文（当前已完成状态）

### 2.1 代码分区

本地已形成：

```text
16_Pi-Yuanyi/
├── Pi/
│   ├── pi-upstream/
│   ├── Yuanyi-Pi-dev/
│   │   ├── pi/
│   │   ├── pi-web/
│   │   └── pi-permission-system/
│   └── Yuanyi-Pi-prod/
│       ├── pi/
│       ├── pi-web/
│       └── pi-permission-system/
└── Yuanyi-docs/
```

职责：

- `pi-upstream`：只跟踪 Pi 官方仓库，用于 Diff / 评估 / 选择性吸收。
- `Yuanyi-Pi-dev`：唯一正式开发工作区。
- `Yuanyi-Pi-prod`：稳定生产工作区，禁止直接开发。
- `Yuanyi-docs`：所有项目文档统一管理区。

### 2.2 Git

自有唯一远程代码仓库：

```text
https://github.com/yuanyi1415/Yuanyi-Pi.git
```

当前治理关系：

```text
Pi 官方
  ↓
pi-upstream
  ↓ 选择性吸收
Yuanyi-Pi-dev
  ↓ push
Yuanyi-Pi Git
  ↓ 稳定版本
Yuanyi-Pi-prod
```

Pi + Pi-Web 已统一纳入同一个 Yuanyi-Pi 仓库管理。

Pi-Web 不建立独立 upstream 跟踪线。

### 2.3 Dev / Prod 隔离

生产数据：

```text
~/.pi/agent
```

开发数据：

```text
~/.pi-dev/agent
```

开发入口：

```bash
pi-dev
```

生产 Web 入口：

```bash
pi-web
```

Dev / Prod 数据已完成隔离。

### 2.4 Dev 验证

开发环境已由项目负责人确认验证可行。

因此：

> **Yuanyi-Pi 已具备正式代码开发条件。**

### 2.5 Prod 状态

生产 Pi Web 已切换到：

```text
Yuanyi-Pi-prod/pi-web
```

当前生产运行仍保持原稳定 Pi 0.84.2 引擎快照。

这是当前接受的过渡状态，不阻塞一期开发。

当后续首次修改 Pi Core 并准备发布时，再完成：

```text
Yuanyi-Pi-prod/pi-web
        ↓
Yuanyi-Pi-prod/pi
```

的正式生产绑定验证。

## 3. 当前冻结的产品与架构边界

### 3.1 一期入口

一期正式入口：

- Web
- 个人微信私聊

Desktop 只保留兼容边界，下一期再正式建设。

### 3.2 一级对象

Session 是一级运行对象。

禁止重新引入：

- Work / Personal Profile Runtime
- 虚拟 Project / Workspace

“项目”只指用户真实本地目录。

允许无项目 Session。

### 3.3 Runtime Ownership

目标架构：

```text
            Web
             │
微信 ────────┼──────── 未来 Desktop
             │
             ↓
      Personal Gateway
             ↓
       Session Router
             ↓
      Runtime Manager
             ↓
      PiRuntimeAdapter
             ↓
        AgentSession
```

Runtime Ownership 属于 Personal Runtime，不属于 Pi Web。

### 3.4 扩展策略

固定原则：

> **产品语义原生 + 实现边界可插拔 + Pi Package 原生兼容**

一期不建设通用 Plugin Manager / 插件市场。

## 4. 接手 Agent 必须遵守的代码边界

### 可以修改

正式开发只在：

```text
Pi/Yuanyi-Pi-dev/
```

进行。

一期新增 Personal Runtime 相关代码，应依据已冻结架构设计建立独立代码域。

### 禁止修改

禁止直接在：

```text
Pi/Yuanyi-Pi-prod/
Pi/pi-upstream/
```

进行正式开发。

### upstream

官方 Pi 更新不得自动 merge 进入我们的 main。

必须：

```text
pi-upstream
→ 评估
→ 选择性吸收
→ dev 验证
→ 自有 Git
→ prod
```

## 5. 参考材料（当前正式开发起点）

现在进入：

> **Stage-001：工程基线与核心契约**

接手 Agent 必须先读取：

1. `基准事实.md`
2. `项目工作纲领.md`
3. `PRD-001-Pi Personal一期.md`
4. `架构设计-001-Pi Personal一期.md`
5. `技术设计-001-Pi Personal一期.md`
6. `WBS-001-Pi Personal一期.md`
7. `Stage-001-工程基线与核心契约.md`
8. `任务清单-002-Pi Personal一期进度跟踪.md`

不得只根据本 Handoff 开发。

## 6. Stage-001 的目标

Stage-001 只完成：

- 开发工程基线确认；
- Personal Runtime 代码域初始化；
- Gateway / Session / Runtime / Pi Adapter 核心 Contract；
- 最小配置与数据目录约定；
- 测试基线；
- 与现有 Pi / Pi-Web 的边界确认。

Stage-001 不进入：

- 微信正式接入；
- Pi Web 全量迁移；
- Memory；
- Scheduler；
- Desktop；
- Subagent；
- Plugin Manager。

## 7. 当前非阻塞未决项

以下事项存在，但不阻塞 Stage-001：

1. 生产 Pi-Web 尚未正式绑定 `Yuanyi-Pi-prod/pi`。
2. 微信具体 Transport 尚未冻结。
3. Personal Gateway 具体进程框架仍应以技术设计和实现验证为准。
4. Memory / Scheduler / Subagent 均不属于一期当前实施范围。
5. 旧运行目录仍保留作为回滚备份，不急于清理。

## 8. 验收标准（执行要求）

接手 Agent 必须：

1. 只在 `Yuanyi-Pi-dev` 开发。
2. 每完成一个 WBS 任务，更新 `任务清单-002` 状态和验收证据。
3. 遇到架构或需求冲突，不得自行改变冻结文档。
4. 需要改变基准、PRD、架构或技术设计时，先停止实现并提出变更。
5. 代码完成不等于任务完成，必须有真实测试或运行证据。
6. Stage-001 出口未通过前，不进入 Stage-002。
7. 不影响当前 `Yuanyi-Pi-prod` 和生产 Pi Web。

## 9. 交接结论

环境初始化与代码治理切换已经完成并通过验收。

当前项目状态：

```text
Constitution   ✅
Specify        ✅
Plan           ✅
Tasks          ✅
Environment    ✅
Implement      ▶ Stage-001
```

下一执行动作：

> **从 Stage-001 的第一项未开始任务开始实施，并同步更新任务进度跟踪清单。**
