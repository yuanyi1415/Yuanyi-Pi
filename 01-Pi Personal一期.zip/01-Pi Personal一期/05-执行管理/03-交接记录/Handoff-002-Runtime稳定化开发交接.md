---
type: Handoff
status: 草稿
version: v1.0
depends_on: 基准事实-v1.2; PRD-002-v1.0; AnalysisReport-001-v1.0; 架构设计-002-v1.0; 技术设计-002-v1.0; ADR-002-v1.0; IssueLog-001-v1.0; WBS-002-v1.0; Stage-006-v1.0
owner: 缘一
created: 2026-08-20
updated: 2026-08-20
---

# Handoff-002：Runtime 稳定化开发交接

## 1. 交接目标

本次交接用于启动 **Pi Personal 一期的第二轮设计迭代：Runtime 与服务架构稳定化**。

这不是重新开发一期，也不是继续修改 001 文档。

项目关系必须先理解为：

```text
001
= 第一轮一期建设
= 已实现能力与历史设计依据
= 保留原样

基准事实 v1.2
+ 最新生产源码
+ 真实运行问题
+ 源码核查
        ↓
002
= 新一轮 Runtime 稳定化设计与开发
```

002 与 001 属于同一个 `Pi Personal 一期` 主题，但解决的是不同阶段的问题。

---

## 2. 开发前必须先掌握的事实

接手 Agent 在写任何代码前，必须确认以下事实已经理解。

### 2.1 代码与 Git

唯一产品代码仓库：

```text
https://github.com/yuanyi1415/Yuanyi-Pi.git
```

当前主要代码域：

```text
Yuanyi-Pi/
├── pi/
├── pi-web/
├── personal-runtime/
└── pi-permission-system/
```

本地治理：

```text
Pi/
├── pi-upstream/
├── Yuanyi-Pi-dev/
└── Yuanyi-Pi-prod/
```

规则：

- `pi-upstream` 只跟官方 Pi；
- `Yuanyi-Pi-dev` 是唯一正式开发区；
- `Yuanyi-Pi-prod` 只运行稳定版本；
- Pi + Pi-Web + Personal Runtime 统一版本治理；
- Pi-Web 不维护独立 upstream；
- 官方 Pi 只做选择性吸收，不自动合入生产。

### 2.2 当前真实运行链路

第一轮开发已经完成主要链路：

```text
Browser
   ↓
Pi Web
   ↓
Personal Gateway
   ↓
Session Router
   ↓
Runtime Manager
   ↓
PiRuntimeAdapter
   ↓
AgentSession
```

微信也已经进入 Personal Runtime：

```text
WeChat
   ↓
WeChat Transport / Channel
   ↓
Personal Runtime
   ↓
统一 Session
```

因此本轮不是“建设 Gateway”，而是**收口已经存在的 Gateway 与 Runtime**。

### 2.3 Runtime Ownership

最终原则已经确定：

> **一个 Session 只能有一个活跃 Runtime Owner，且只能是 Personal Runtime。**

Pi Web 是：

```text
UI + BFF + Compatibility Adapter
```

不是 Agent Runtime Owner。

Web 可以读取不会改变 Runtime 的持久数据，但不能为了 Auto-name、State、Running 等辅助功能再创建第二套 `AgentSession`。

### 2.4 双进程是已确认方向

最终不是把 Web 和 Gateway 合回一个进程。

部署关系：

```text
System Supervisor
        ↓
Personal Runtime
长期后台运行
        ↑
        │ HTTP / SSE
        │
     Pi Web
     按需运行
```

原因已经由真实需求确认：

> **即使 Web 几天都不开，微信仍必须在线收消息、回复和主动发送。**

所以：

- Personal Runtime 必须独立常驻；
- Web 可以随时启动、关闭、升级和重启；
- Web 生命周期不得传染到 Runtime；
- 用户体验上仍然只能感知一个 `Yuanyi-Pi` 产品。

### 2.5 当前运行依赖事实

虽然仓库已经包含自有：

```text
Yuanyi-Pi/pi/
```

但当前 `pi-web` 与 `personal-runtime` 仍主要消费官方 npm Pi `0.84.2`。

因此：

> 当前修改仓库内 `pi/` 并不会自动进入产品真实运行链。

本轮没有实际 Pi Core 修改时，不为了形式统一强制切换。

如果以后本轮或后续任务修改了 Pi Core，则正式发布前必须先解决自有 Pi Build / Package 绑定。

---

## 3. 本轮已经确认的真实问题

以下不是推测，而是最新源码核查后已经确认需要处理的问题。

### ISS-201：Web Runtime Ownership 未完全清场

Gateway 模式已经覆盖主链，但 Pi Web 仍残留部分 `rpc-manager` 活 Runtime 路径。

风险：

```text
Gateway AgentSession
        +
Web AgentSession
```

或：

```text
Web 修改 Session 文件
        +
Gateway 仍持有对应 Runtime
```

本轮必须完成全量收口。

### ISS-202：普通 Prompt 绕过串行队列

`RuntimeManager.prompt()` 已实现串行机制，但当前 Gateway 普通 Command 仍可能直接走 `sendCommand()`。

结果：

> Web 与微信同时向同一 Session 发送普通 Prompt 时，串行保障并未真正落到主链。

### ISS-203：Idle 回收可能误杀长任务

当前 Idle 扫描主要依赖：

- `lastActiveAt`
- Registry 静态状态
- 时间阈值

没有可靠使用 Agent 当前真实：

```text
isStreaming
isIdle
```

因此长任务存在被错误 dispose 的风险。

### ISS-204：无项目 Session Web 语义未闭环

Runtime 已实现：

```text
projectDirectory = null
runtimeCwd = neutralCwd
```

但 Web 仍存在把 `runtimeCwd` 当项目目录、没有选择目录时无法正常新建等问题。

### ISS-205：Gateway 生命周期没有唯一 Owner

当前已经真实发生过：

```text
Pi Web 拉起 Gateway
+
人工再次启动 Gateway
        ↓
EADDRINUSE
```

问题本质不是端口检查缺失，而是：

> Personal Runtime 尚未成为真正的独立系统服务。

### ISS-206：Web Streaming 性能没有事实基线

双进程本身不是已证明的性能问题。

当前必须建立可测量指标，而不是继续凭“感觉卡不卡”判断。

---

## 4. 性能事实与验收方法

当前链路：

```text
LLM
 ↓
AgentSession
 ↓
Personal Runtime
 ↓ SSE / localhost
Pi Web BFF
 ↓ SSE
Browser
```

需要记录：

```text
T0 = Browser 发出 Prompt
T1 = Gateway 收到 Prompt
T2 = Gateway 收到 Pi 第一条模型输出 Event
T3 = Browser 收到第一条输出 Event
```

分解：

```text
T1 - T0
= Web/BFF → Gateway 额外开销

T2 - T1
= 模型真实 TTFT

T3 - T2
= Gateway → Web → Browser 流式转发开销
```

本轮目标：

```text
Web/BFF → Gateway
P95 ≤ 50 ms

Gateway Event → Browser
P95 ≤ 50 ms
```

同时不得出现明显：

- 批量吐字；
- 周期性停顿；
- Event 积压。

如果性能不达标：

> 先定位和优化 BFF / SSE 转发，禁止因为“多一个进程”直接把 Runtime 塞回 Web。

---

## 5. 接手前必须读取的材料

### 第一优先级：当前方向与需求

必须依次读取：

1. `基准事实.md` — v1.2，当前唯一方向锚；
2. `AnalysisReport-001-最新源码与服务架构核查.md`；
3. `PRD-002-Runtime与服务架构稳定化.md`；
4. `架构设计-002-Runtime与服务生命周期收口.md`；
5. `ADR-002-Web与Personal Runtime双进程生命周期.md`；
6. `技术设计-002-Runtime稳定化技术方案.md`；
7. `IssueLog-001-Runtime稳定化问题台账.md`；
8. `WBS-002-Runtime稳定化收口.md`；
9. `Stage-006-Runtime Ownership与服务生命周期收口.md`。

### 第二优先级：事实源码

必须实际查看当前最新：

```text
Yuanyi-Pi-dev/
├── pi-web/
├── personal-runtime/
├── pi/
└── pi-permission-system/
```

不能仅凭设计文档修改代码。

重点代码至少包括：

```text
pi-web/lib/rpc-manager*
pi-web/lib/personal-gateway*
pi-web Agent / Session API routes
pi-web SessionSidebar / Session DTO
personal-runtime Gateway routes
personal-runtime RuntimeManager
personal-runtime PiRuntimeAdapter
personal-runtime Channel / WeChat
服务启动脚本
```

### 第三优先级：历史资料

001 文档用于回答：

> 第一轮为什么这样设计、原本承诺了哪些能力、哪些能力已经完成。

包括：

- `PRD-001`
- `架构设计-001`
- `技术设计-001`
- `WBS-001`
- `Stage-001 ～ Stage-005`

它们是**历史依据**，不是本轮执行清单。

不得修改 001 来表达 002 变化。

### 第四优先级：实际运行事实

接手前还必须了解：

- 最新生产源码；
- 环境初始化与交付报告；
- Web / Gateway 启动事故记录；
- Dev / Prod 数据隔离；
- 当前实际启动方式；
- 当前生产 Runtime 和 Web 状态。

文档与真实源码冲突时：

> 先记录冲突并停下变更，不允许默默选择其中一个继续开发。

---

## 6. 本轮要做什么

唯一正式实施阶段：

> **Stage-006：Runtime Ownership 与服务生命周期收口**

执行顺序：

```text
1. Runtime Ownership 清场
        ↓
2. Prompt 串行正确性
        ↓
3. Idle 回收正确性
        ↓
4. 无项目 Web 语义
        ↓
5. Personal Runtime 常驻生命周期
        ↓
6. TTFT / Streaming 性能基线
        ↓
7. 一期全量回归
        ↓
8. 稳定版本发布
```

不得把顺序改成：

```text
先做 launchd
→ 先优化性能
→ 最后再处理双 Runtime Owner
```

因为正确性优先于体验优化。

---

## 7. 本轮明确不做什么

禁止顺手扩大为：

- Memory；
- Scheduler 产品化；
- Desktop；
- Subagent；
- Capability Router；
- 新 IM Channel；
- 通用 Plugin Manager；
- 大规模 Pi Web 重写；
- Browser 直连 Gateway；
- 为了“架构更统一”强制重做 Pi Package 体系。

这些不是本轮问题。

---

## 8. 开发与生产边界

所有正式代码修改只能在：

```text
Pi/Yuanyi-Pi-dev/
```

进行。

禁止直接修改：

```text
Pi/Yuanyi-Pi-prod/
Pi/pi-upstream/
```

流程：

```text
dev
→ 单元 / 集成 / 真实运行验证
→ Git
→ 稳定版本
→ prod
```

在整个 S6 期间：

> 当前生产 Web、微信和生产数据不能因为稳定化开发被破坏。

---

## 9. 接手 Agent 的执行规则

### 开始编码前

必须先输出一份简短的“事实确认”，至少明确：

1. 当前真正的 Runtime Owner 是谁；
2. 哪些 Web 路径仍残留 rpc-manager；
3. Prompt 串行实际走哪条代码路径；
4. Idle 回收目前如何判断；
5. Web 无项目 Session 当前哪里不一致；
6. Personal Runtime 当前由谁启动 / 停止；
7. 当前 Web 与 Runtime 实际消费哪一套 Pi；
8. 当前 dev / prod 数据目录和端口是什么。

没有完成事实确认，不进入修改。

### 编码过程中

- 一个问题一个闭环；
- 每完成一个 WBS 任务更新进度和验收证据；
- 发现冻结设计不成立时先提出，不擅自改变架构；
- 不以“编译通过”作为完成；
- 必须包含真实运行或自动测试证据。

### Stage 结束前

必须同时提交：

- WBS-002 状态；
- IssueLog 关闭状态；
- 测试结果；
- TTFT / Streaming 性能数据；
- Web / 微信 / Session 回归结果；
- 生产发布验证；
- 新稳定基线结论。

---

## 10. 本轮完成定义

只有同时满足以下条件，才允许声明 002 完成：

```text
Web 无第二 Runtime Owner
+
同 Session Prompt 串行
+
长任务不会被 Idle 错误回收
+
无项目 Session Web 闭环
+
Personal Runtime 独立常驻
+
Web 不再控制 Runtime 生命周期
+
Gateway 单实例
+
微信不依赖 Web 运行
+
Web 重启不影响 Agent Run
+
两段本地转发 P95 ≤ 50 ms
+
001 已有能力回归通过
+
稳定版本进入 prod
```

---

## 11. 当前交接状态

```text
001 一期建设             ✅ 已完成 / 历史依据
基准事实 v1.2            ✅ 已确认
002 PRD / 架构 / 技术设计  ▶ 待项目负责人最终确认
ADR-002                  ▶ 待冻结
WBS-002                  ▶ 待冻结
Stage-006                ▶ 待进入
代码实现                  ⏸ 尚未开始本轮正式收口
```

下一步：

> **先完整读取本 Handoff 列出的事实材料，并对最新 dev 源码做一次只读事实确认；确认设计与源码一致后，从 WBS-002 的 Runtime Ownership 清场开始实施。**
