# 002-Pi Personal S6 稳定化问题台账

> **文档编号**：002
> **阶段**：04-交付 / S6 Runtime 稳定化收口
> **版本**：第三轮代码审查与会话体系重构版
> **事实基线**：2026-08-21 最新 Yuanyi-Pi-dev
> **用途**：作为 Codex 下一轮整改、测试与验收的唯一输入
> **目标**：完成会话体系最终交互收口及剩余 Runtime / prod / 性能问题，达到 S6 Exit Gate
> **范围约束**：只处理本文问题；不得扩展 Memory、Scheduler、Desktop、Subagent、新 Channel、Plugin Manager 等下一阶段能力

------

# 一、文档本体

## 1.1 当前阶段判断

经过 S6 多轮开发与复审，Runtime 主体架构已经基本稳定。

以下能力已经通过或基本冻结，不再重新设计：

| 能力                                     | 状态         |
| ---------------------------------------- | ------------ |
| Personal Runtime 唯一 AgentSession Owner | ✅ 主链已建立 |
| Prompt 同 Session 串行                   | ✅ 通过       |
| Runtime Idle 真实状态回收                | ✅ 通过       |
| Gateway / Legacy fail-closed             | ✅ 通过       |
| 删除 Session 清理微信 Binding            | ✅ 通过       |
| AI Session Auto-name                     | ✅ 通过       |
| Web Streaming reconnect 主链             | ✅ 通过       |
| reconnect Snapshot / Event 顺序          | ✅ 通过       |
| dev Runtime 真实 PID 管理                | ✅ 通过       |
| dev/prod 共享 `package.json` 环境中立化  | ✅ 通过       |
| `/context`、`/document` defer 参数接入   | ✅ 主链已接通 |
| Browser T3 埋点位置                      | ✅ 已修正     |

当前 S6 的核心剩余工作分为两类：

1. **会话体系 UI / 数据模型最终重构**
2. **prod 与性能发布前收口**

------

# 二、最终冻结的会话本体

Pi Personal 的会话体系不再采用：

```text
新建会话
→ 先选择已有项目
→ 创建 Session
```

也不采用：

```text
单独“打开文件夹”
→ 建项目
→ 再新建 Session
```

最终统一采用：

> **先进入临时 Draft，新建页面本身不产生任何后台对象；第一次发送消息时，根据是否选择文件夹决定创建“话题”还是“项目会话”。**

------

## 2.1 三个产品对象

产品侧正式存在三个概念：

```text
话题
项目
项目会话
```

### 话题

未绑定真实本地项目目录的正式 Session。

```ts
projectDirectory = null
runtimeCwd = 独立 Projectless Workspace
```

例如：

```text
~/.yuanyi-pi/workspaces/<session-id>/
```

------

### 项目

项目不是虚拟 Workspace。

项目本体始终是：

> 用户本地一个真实文件夹路径。

例如：

```text
/Users/yuanyi/Pi/Yuanyi-Pi-dev
```

项目身份：

```ts
canonicalProjectDirectory
```

项目展示名称：

```ts
projectDisplayName
```

两者必须分离。

例如：

```ts
{
  projectDirectory: "/Users/yuanyi/Pi/Yuanyi-Pi-dev",
  projectDisplayName: "Pi Personal"
}
```

用户修改：

```text
Pi Personal
→ Yuanyi Pi
```

只能改变：

```ts
projectDisplayName
```

禁止改变：

```ts
projectDirectory
```

------

### 项目会话

绑定一个真实项目目录的 Session。

```ts
projectDirectory = project.path
runtimeCwd = project.path
```

项目会话归属对应项目分组。

------

# 三、新建会话最终交互

## 3.1 点击“新建会话”

Sidebar 顶部只有一个：

```text
＋ 新建会话
```

点击后：

```text
只进入前端 Draft
```

不得创建：

- Session；
- Session Metadata；
- Session ID 持久化记录；
- Projectless Workspace；
- Known Project；
- project alias；
- Session 文件。

------

## 3.2 Draft 数据模型

建议前端使用明确的 Draft 类型：

```ts
interface NewSessionDraft {
  projectDirectory: string | null;
  projectDisplayName: string | null;
  selectedModelPresetId?: string | null;
}
```

Draft 只存在 React 前端状态。

例如：

```ts
const [draft, setDraft] = useState<NewSessionDraft>({
  projectDirectory: null,
  projectDisplayName: null,
  selectedModelPresetId: null,
});
```

禁止提前调用：

```ts
POST /sessions
```

------

## 3.3 新会话 UI

新会话主区保持现有聊天组件，不重新设计页面框架。

输入区附近增加：

```text
[ 📁 选择文件夹 ]      [模型选择]

┌──────────────────────────────────────┐
│ 输入消息……                           │
└──────────────────────────────────────┘
```

------

# 四、“选择文件夹”交互

## 4.1 第一步：打开轻量项目面板

点击：

```text
📁 选择文件夹
```

不要直接打开 Finder。

先在输入框附近打开一个轻量 Popover / Panel：

```text
┌──────────────────────────────┐
│ 项目名称                      │
│ ┌──────────────────────────┐ │
│ │ Pi Personal              │ │
│ └──────────────────────────┘ │
│                              │
│ 项目文件夹                    │
│ ┌──────────────────────────┐ │
│ │ 📁 选择文件夹             │ │
│ └──────────────────────────┘ │
│                              │
│ /Users/yuanyi/Pi/...         │
│                              │
│                取消    确定   │
└──────────────────────────────┘
```

------

## 4.2 项目名称

建议内部状态：

```ts
const [draftProjectName, setDraftProjectName] =
  useState("");
```

字段代表：

```ts
projectDisplayName
```

不是文件夹名称。

------

## 4.3 原生文件夹选择器

用户点击面板里的：

```text
📁 选择文件夹
```

再调用操作系统原生目录选择器。

macOS：

> 使用原生 Finder 文件夹选择体验。

不要自行实现文件系统浏览器。

返回：

```ts
{
  path: "/Users/yuanyi/Pi/Yuanyi-Pi-dev"
}
```

需要 canonicalize：

```ts
const canonicalPath =
  await canonicalizeDirectory(selectedPath);
```

------

## 4.4 自动名称规则

用户尚未输入名称时：

```ts
if (!draftProjectName.trim()) {
  setDraftProjectName(
    basename(canonicalPath)
  );
}
```

例如：

```text
选择：
/Users/yuanyi/Pi/Yuanyi-Pi-dev

自动填：
Yuanyi-Pi-dev
```

如果用户已经输入：

```text
Pi Personal
```

选择文件夹后不得覆盖。

------

## 4.5 点击“确定”

点击确定仅修改前端 Draft：

```ts
setDraft({
  ...draft,
  projectDirectory: canonicalPath,
  projectDisplayName: draftProjectName.trim(),
});
```

此时仍：

```text
0 个后台写操作
```

输入框附近显示：

```text
📁 Pi Personal   ✎
```

点击 `✎` 可以重新打开项目 Panel。

------

# 五、首次发送才 Commit

## 5.1 未选择文件夹

用户直接发送：

```text
帮我研究一下 Agent Runtime
```

执行：

```text
Draft
↓
第一次 Send
↓
创建 Session
↓
projectDirectory = null
↓
创建独立 Projectless Workspace
↓
runtimeCwd = workspace/<session-id>
↓
保存第一条 User Message
↓
Session 进入“话题”
```

------

## 5.2 已选择文件夹

例如 Draft：

```ts
{
  projectDirectory:
    "/Users/yuanyi/Pi/Yuanyi-Pi-dev",

  projectDisplayName:
    "Pi Personal"
}
```

第一次 Send：

```text
canonicalize path
↓
upsert Project
↓
创建 Session
↓
projectDirectory = project path
↓
runtimeCwd = project path
↓
保存第一条 User Message
↓
进入对应项目分组
```

------

## 5.3 推荐原子接口

不要前端：

```text
先创建 Session
再保存 Project
再发送 Prompt
```

容易产生半成品对象。

建议 Gateway 增加统一首发接口，例如：

```http
POST /sessions/start
```

Request：

```ts
interface StartSessionRequest {
  message: string;

  project?: {
    directory: string;
    displayName: string;
  } | null;

  modelPresetId?: string | null;
}
```

Response：

```ts
interface StartSessionResponse {
  sessionId: string;
}
```

内部：

```ts
async function startSession(request) {
  const sessionId = generateSessionId();

  let projectDirectory: string | null = null;
  let runtimeCwd: string;

  if (request.project) {
    projectDirectory =
      await canonicalizeDirectory(
        request.project.directory
      );

    await projectRegistry.upsert({
      path: projectDirectory,
      displayName:
        request.project.displayName
    });

    runtimeCwd = projectDirectory;
  } else {
    runtimeCwd =
      await createTopicWorkspace(sessionId);
  }

  await sessionRouter.create({
    id: sessionId,
    projectDirectory,
    runtimeCwd
  });

  await runtimeManager.prompt(
    sessionId,
    request.message
  );

  return { sessionId };
}
```

实际实现应保证失败时不留下错误的半成品 Project / Session。

------

# 六、Draft 生命周期

无论用户已经：

- 输入内容；
- 选择文件夹；
- 修改项目名称；
- 修改模型；

只要：

```text
第一条用户消息尚未成功提交
```

都属于 Draft。

用户此时：

```text
点击历史 Session
关闭页面
重新点击新建
切换项目
退出 Web
```

Draft 直接丢弃。

不弹保存确认。

后台不得留下：

```text
空 Session
空项目
空 Workspace
Session Metadata
```

------

# 七、已有项目快速新建

项目行必须支持：

```text
项目名        ＋
```

例如：

```text
Pi Personal       ＋
```

点击：

```text
＋
```

进入同一个 New Session Draft。

只是预填：

```ts
draft = {
  projectDirectory:
    project.path,

  projectDisplayName:
    project.displayName
}
```

仍然：

```text
未发送第一条消息
→ 不创建 Session
```

------

# 八、最终 Sidebar UI

建议最终结构：

```text
┌────────────────────────────────┐
│ ＋ 新建会话                     │
│                                │
│ 话题                           │
│   Agent 世界模型         ✎  🗑 │
│   帮我分析材料           ✎  🗑 │
│                                │
│ 项目                           │
│                                │
│ ▾ Pi Personal       ＋  ✎  🗑 │
│     S6 稳定化            ✎  🗑 │
│     微信优化             ✎  🗑 │
│                                │
│ ▾ 公司AI平台         ＋  ✎  🗑 │
│     Agent Runtime        ✎  🗑 │
│     智能问数             ✎  🗑 │
│                                │
│ ───────────────────────────── │
│ 设置                           │
└────────────────────────────────┘
```

------

# 九、Sidebar 显示规则

## 9.1 话题

```ts
projectDirectory === null
```

进入：

```text
话题
```

话题区域始终位于项目区域上方。

------

## 9.2 项目

项目来自 Project Registry。

不能仅通过当前 Session 动态反推。

否则删除最后一个 Session 后项目会异常消失。

推荐：

```ts
interface KnownProject {
  path: string;
  displayName: string;
  createdAt: number;
  updatedAt: number;
}
```

身份 Key：

```ts
canonical path
```

------

## 9.3 项目会话

```ts
session.projectDirectory === project.path
```

显示于项目下。

------

## 9.4 空 Draft 不显示

Sidebar 只能显示：

> 已经至少成功提交一条 User Message 的正式 Session。

禁止显示：

```text
新会话
Untitled
空 Session
```

------

# 十、Hover 操作

以下三类对象均要求 Hover 后展示操作。

------

## 10.1 话题

默认：

```text
Agent 世界模型
```

Hover：

```text
Agent 世界模型      ✎  🗑
```

操作：

- 重命名；
- 删除。

------

## 10.2 项目

默认：

```text
Pi Personal
```

Hover：

```text
Pi Personal       ＋  ✎  🗑
```

操作：

- `＋` 在此项目新建 Draft；
- 重命名；
- 移除。

------

## 10.3 项目会话

默认：

```text
S6 Runtime 稳定化
```

Hover：

```text
S6 Runtime 稳定化       ✎  🗑
```

操作：

- 重命名；
- 删除。

------

# 十一、重命名规则

## 11.1 话题

修改：

```ts
session.title
```

例如：

```text
Agent 世界模型
→ Agent 学习
```

------

## 11.2 项目会话

同样修改：

```ts
session.title
```

绝不修改项目。

------

## 11.3 项目

修改：

```ts
project.displayName
```

例如：

```text
Yuanyi-Pi-dev
→ Pi Personal
```

禁止：

```text
rename directory
move directory
修改 projectDirectory
```

------

## 11.4 推荐 UI

Hover 点击 `✎` 后可以直接 inline edit：

```tsx
{editing ? (
  <input
    autoFocus
    value={draftName}
    onChange={(e) =>
      setDraftName(e.target.value)
    }
    onBlur={commitRename}
    onKeyDown={(e) => {
      if (e.key === "Enter")
        commitRename();

      if (e.key === "Escape")
        cancelRename();
    }}
  />
) : (
  <span>{displayName}</span>
)}
```

------

# 十二、删除语义

删除必须严格区分对象。

------

## 12.1 删除话题

```text
删除 Session
```

确认框：

```text
删除这个话题？

该操作会删除对话记录。
```

Projectless Workspace：

> S6 暂不物理删除。

原因：

里面可能存在用户生成文件。

------

## 12.2 删除项目会话

```text
删除对应 Session
```

不得：

```text
删除项目
删除本地文件
```

------

## 12.3 删除项目

“删除项目”在产品上实际定义为：

> **从 Pi 中移除项目。**

确认：

```text
从 Pi 中移除“Pi Personal”？

本地文件夹不会被删除。
```

绝对禁止：

```bash
rm -rf <projectDirectory>
```

------

## 12.4 项目下历史 Session

本轮冻结：

> 移除项目不应隐式批量删除 Session。

建议行为：

```text
移除 Project Registry
↓
项目不再作为常用项目节点
↓
已有 Session 数据仍保留
```

如果这些 Session 仍引用：

```ts
projectDirectory
```

可保留一个历史项目分组，或者在重新打开同一路径时重新恢复该项目。

具体最小实现：

> 先保证不丢 Session、不删文件。

禁止为了移除项目连带批量删除历史。

------

# 十三、S6-R3-01 会话体系重构

**优先级：P0**

这是本轮最大改动。

需要废弃当前：

```text
selectedCwd
项目下拉决定新建目标
filteredSessions 根据 selectedProject 过滤
```

这套旧设计。

------

## 13.1 应删除或弱化的状态

不再让：

```ts
selectedCwd
```

承担：

```text
当前浏览项目
+
新建会话项目
+
Sidebar 过滤条件
```

三个职责。

建议改成：

```ts
newSessionDraft
```

项目只作为 Draft 属性。

------

## 13.2 Sidebar 不再按 selectedProject 过滤

禁止：

```ts
const filteredSessions =
  selectedProject
    ? sessionsForProject(...)
    : allSessions;
```

Sidebar 始终渲染完整：

```text
话题
+
所有项目分组
```

------

## 13.3 验收场景

必须真实完成：

### 场景 A

```text
新建会话
→ 不选目录
→ 不发消息
→ 点击历史 Session
```

结果：

```text
后台没有任何新 Session
```

------

### 场景 B

```text
新建会话
→ 不选目录
→ 发第一条消息
```

结果：

```text
创建话题
创建独立 Workspace
```

------

### 场景 C

```text
新建会话
→ 选择任意电脑本地新目录
→ 修改项目名
→ 不发送
→ 离开
```

结果：

```text
不创建 Project
不创建 Session
```

------

### 场景 D

```text
新建会话
→ 选择新目录
→ 修改名称
→ 发第一条消息
```

结果：

```text
创建 Project
创建项目 Session
进入对应项目分组
```

------

### 场景 E

```text
已有项目右侧 +
→ 输入消息
→ 发送
```

结果：

```text
创建该项目的新 Session
```

------

# 十四、S6-R3-02 prod Runtime launchd 启动命令

**优先级：P0**

当前已有：

```text
deploy/prod/launchd/
```

但 plist 直接：

```text
node src/index.ts
```

不能保证运行 TypeScript Runtime。

------

## 14.1 本轮推荐方案

为了避免 S6 扩展 build pipeline，统一：

```text
node --import tsx src/index.ts
```

------

## 14.2 package 修改

如果：

```json
tsx
```

当前仍在：

```json
devDependencies
```

应移动到：

```json
dependencies
```

因为 prod Runtime 需要它。

例如：

```json
{
  "dependencies": {
    "tsx": "^x.x.x"
  }
}
```

------

## 14.3 plist

修改为：

```xml
<key>ProgramArguments</key>
<array>
  <string>__PROD_NODE_BIN__</string>
  <string>--import</string>
  <string>tsx</string>
  <string>__PROD_RUNTIME_ROOT__/src/index.ts</string>
</array>
```

------

## 14.4 验收

必须在与 prod 等价的命令环境运行：

```bash
node --import tsx src/index.ts
```

验证：

- Runtime 正常启动；
- Health 正常；
- Gateway 正常；
- 微信正常。

------

# 十五、S6-R3-03 prod Pi Web 启动配置缺失

**优先级：P0**

当前：

```text
package.json
```

已恢复环境中立，这是正确的。

但 prod Web 缺少正式环境入口。

------

## 15.1 推荐目录

```text
deploy/
└── prod/
    ├── launchd/
    │   └── com.yuanyi.personal-runtime.plist.template
    │
    └── pi-web/
        └── start.sh
```

------

## 15.2 示例

```bash
#!/usr/bin/env bash

set -euo pipefail

export PERSONAL_GATEWAY_ENABLED=1
export PERSONAL_GATEWAY_URL="http://127.0.0.1:8770"
export PI_CODING_AGENT_DIR="$HOME/.pi/agent"
export YUANYI_RUNTIME_ENV="prod"

cd "__PROD_PI_WEB_ROOT__"

exec npm start
```

------

## 15.3 约束

共享：

```text
package.json
```

禁止重新出现：

```text
8770
8771
.pi
.pi-dev
Yuanyi-Pi-dev
```

环境信息只放：

```text
scripts/dev
deploy/prod
```

------

# 十六、S6-R3-04 `/document` 不应传完整 raw entries

**优先级：P1**

当前 `/document` 已支持 defer，但 Personal Gateway 仍可能返回：

```ts
entries
```

完整原始数据。

Web BFF 仅为了计算：

```ts
totalActiveMs
```

而接收完整 raw entries。

------

## 16.1 问题

长 Session 可能包含：

- thinking；
- tool result；
- base64 media；
- 大量历史 entries。

于是：

```text
Runtime
↓
完整 entries
↓
Web BFF
```

会造成不必要的双进程传输。

------

## 16.2 修改方案

把：

```ts
computeSessionTotalActiveMs(entries)
```

移到 Personal Runtime。

Gateway 返回：

```ts
interface SessionDocumentResponse {
  filePath: string;
  info: unknown;
  tree: unknown;
  context: unknown;
  totalActiveMs: number;
}
```

删除：

```ts
entries
```

------

## 16.3 示例

```ts
async getDocument(
  sessionId: string,
  options: SessionProjectionOptions
) {
  const session =
    await this.getReadableSession(sessionId);

  const entries =
    session.getEntries();

  return {
    filePath:
      session.getFilePath(),

    tree:
      session.getTree(),

    context:
      await readSessionProjection(
        sessionId,
        options
      ),

    totalActiveMs:
      computeSessionTotalActiveMs(
        entries
      )
  };
}
```

Web：

```ts
const {
  context,
  tree,
  totalActiveMs
} = document;
```

------

# 十七、S6-R3-05 Streaming 性能真实验收

**优先级：P0**

代码链路目前已经基本具备：

```text
T0 Browser Send
T1 Gateway Receive
T2 First Model Event
T3 Browser Receive
```

当前缺的是：

> **真实验收数据。**

------

## 17.1 必须执行

至少：

```text
30 次真实 Web Prompt
```

不得只跑单元测试。

------

## 17.2 指标

```text
Ingress Proxy
= T1 - T0
```

目标：

```text
P95 ≤ 50ms
```

------

```text
Model TTFT
= T2 - T1
```

只记录。

------

```text
Streaming Proxy
= T3 - T2
```

目标：

```text
P95 ≤ 50ms
```

------

## 17.3 最终报告

Codex 必须输出：

```text
Samples: >= 30

Ingress
P50:
P95:

Model TTFT
P50:
P95:

Streaming Proxy
P50:
P95:
```

同时人工确认：

- Streaming 连续；
- 不周期性批量吐字；
- 不明显停顿积压。

------

# 十八、本轮要求增加的测试

## 18.1 Draft

-  点击新建不创建 Session
-  选择文件夹不创建 Session
-  修改项目名称不创建 Project
-  Draft 离开后完全丢弃

------

## 18.2 话题

-  首次 Send 创建 Session
-  `projectDirectory=null`
-  独立 Workspace
-  Sidebar 显示在话题区域

------

## 18.3 项目

-  选择任意新本地目录
-  创建新 Project
-  用户名称与目录名解耦
-  项目重命名不修改真实目录

------

## 18.4 项目会话

-  项目 `+` 打开预填 Draft
-  未发送不创建 Session
-  首发后进入正确项目

------

## 18.5 Sidebar 操作

### 话题

-  Hover 重命名
-  Hover 删除

### 项目

-  Hover 新建
-  Hover 重命名
-  Hover 移除

### 项目会话

-  Hover 重命名
-  Hover 删除

------

## 18.6 删除安全

必须增加断言：

```text
任何 Project 删除操作
不得调用文件系统删除真实 projectDirectory
```

------

# 十九、本轮禁止事项

Codex 不得：

1. 重新引入“先选已有项目才能新建会话”。
2. 增加独立“打开文件夹”一级入口。
3. 点击“新建会话”立即创建 Session。
4. 选择文件夹立即创建 Project。
5. 用 runtimeCwd 判断项目。
6. 用 projectDisplayName 作为项目唯一 ID。
7. 项目重命名时重命名本地文件夹。
8. 删除 Project 时删除用户真实目录。
9. Sidebar 因某个项目被选中而隐藏其他分组。
10. 把 dev/prod 环境参数重新写入共享 package scripts。
11. 重构已经稳定的 RuntimeManager Prompt / Idle 逻辑。

------

# 二十、推荐实施顺序

## 第一阶段：会话体系

```text
S6-R3-01
```

先完成：

```text
Draft
Folder Picker
Project alias
首次 Send Commit
Sidebar
Hover 操作
Rename / Delete
```

这是本轮最大的产品改造。

------

## 第二阶段：prod

```text
S6-R3-02
S6-R3-03
```

完成：

```text
Runtime prod 启动
Web prod 启动
```

------

## 第三阶段：传输优化

```text
S6-R3-04
```

------

## 第四阶段：最终性能验收

```text
S6-R3-05
```

性能必须最后执行。

------

# 二十一、S6 最终 Exit Gate

## 会话

-  新建会话只产生 Draft
-  未发第一条消息后台零持久化
-  不选择目录首次 Send 创建话题
-  话题使用独立 Projectless Workspace
-  可选择电脑任意本地文件夹
-  可自定义项目展示名
-  项目展示名与路径完全解耦
-  首次 Send 才创建 Project / Session
-  已有项目 `+` 可新建项目会话
-  空 Draft 永不进入 Sidebar

## Sidebar

-  话题置顶
-  项目分组完整展示
-  项目会话位于项目下
-  话题 Hover 支持重命名/删除
-  项目 Hover 支持新建/重命名/移除
-  项目会话 Hover 支持重命名/删除
-  项目移除绝不删除本地文件夹

## Runtime

-  Prompt 串行保持通过
-  Idle 保持通过
-  Personal Runtime 唯一 Owner
-  Web 不成为 Runtime Owner

## dev

-  dev Runtime 手动启动
-  无 orphan process
-  无 EADDRINUSE 回归

## prod

-  launchd 可真实启动 Runtime
-  prod Pi Web 有正式启动配置
-  prod 不引用 dev 端口 / `.pi-dev`

## Session 数据

-  `/document` 不再传无必要 raw entries
-  deferThinking/deferMedia 生效
-  Auto-name 保持通过

## Channel

-  微信 Binding 清理保持通过
-  Web 关闭不影响微信
-  Web / 微信共享统一 Session

## 性能

-  ≥30 次真实 Web Prompt
-  `T1-T0 P95 ≤ 50ms`
-  `T3-T2 P95 ≤ 50ms`
-  Streaming 无明显积压

------

# 二十二、Codex 完成交付要求

Codex 完成本轮后必须提交：

1. 修改文件清单；
2. `S6-R3-01 ～ S6-R3-05` 逐项实现说明；
3. Draft 生命周期说明；
4. Project / Session 数据结构说明；
5. Folder Picker 实现说明；
6. Sidebar UI 改动说明；
7. Rename / Delete 行为说明；
8. 自动化测试结果；
9. dev Runtime 启停验证；
10. prod Runtime 启动验证；
11. prod Pi Web 启动验证；
12. ≥30 次性能测试结果；
13. P50 / P95 数据；
14. 未解决事项，如有必须明确列出。

以上全部完成后，才进入最后一次 S6 Release Review。

通过后执行：

```text
Yuanyi-Pi-dev
↓
最终复审
↓
Git Commit / Push
↓
形成稳定版本
↓
Yuanyi-Pi-prod 拉取
↓
配置 prod Supervisor
↓
prod 实机复验
↓
形成新的生产基线
```