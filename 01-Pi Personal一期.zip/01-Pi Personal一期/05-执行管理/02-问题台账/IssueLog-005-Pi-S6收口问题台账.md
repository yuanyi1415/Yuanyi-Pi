# Pi S6 收口问题台账

## 1. 文档目的

本台账用于记录 Pi S6 阶段在正式封版前仍需处理的问题。

范围原则：

- 只记录影响 S6 收口的真实问题。
- 不将未来能力、体验增强或架构扩展列为 S6 问题。
- 问题处理完成并通过最终验收后，S6 直接封版。
- 禁止在收口阶段继续新增 Desktop、Memory、Automation、复杂 Orchestration 等范围外能力。

---

## 2. 当前结论

S6 的核心架构已经成立，以下链路已基本闭合：

```text
Web / WeChat
      ↓
Personal Gateway
      ↓
Session Router
      ↓
Runtime Manager
      ↓
PiRuntimeAdapter
      ↓
AgentSession
```

当前不再需要扩展架构，只需完成剩余问题修复与最终验收。

S6 收口状态：

| 维度 | 状态 |
|---|---|
| Runtime Ownership | 已闭合 |
| Gateway | 已闭合 |
| Session Router | 已闭合 |
| Runtime Manager | 已闭合 |
| Pi Adapter | 已闭合 |
| Web 接管 | 已闭合 |
| WeChat | 已闭合 |
| SSE / Resume | 已闭合 |
| Project Identity | 已闭合 |
| 新 Session 生命周期 | 存在 1 个阻塞问题 |
| Project Remove | 存在 1 个阻塞语义问题 |
| 最终全量验收 | 待执行 |

---

# 3. 问题台账

## S6-01｜首次 Prompt 被拒绝时 Prepared Session 可能错误正式化

**优先级：P0**

**是否阻塞封版：是**

### 问题描述

当前新 Session 生命周期中，存在以下风险：

```text
prepare Session
→ first prompt
→ Adapter 返回 accepted: false
→ Gateway 未收到异常
→ Prepared Session 仍可能被 finalize
```

`PiRuntimeAdapter.prompt()` 可能将 Prompt 失败转换为：

```text
accepted: false
```

而不是抛出异常。

如果 Gateway 仅根据“是否 throw”判断事务成功，则可能出现：

```text
首次 Prompt 实际未被 Pi 接受
↓
Session / Metadata / Project 引用已经正式落盘
```

这与当前冻结的产品语义冲突：

> 新 Session 只有在第一次 Prompt 真正被 Runtime 接受后，才可以正式化。

### 根因

Pi `AgentSession.prompt()` 已提供 `preflightResult(success)` 契约，但当前事务边界未完全以该契约作为“首次 Prompt 已被接受”的唯一判断依据。

### 处理要求

必须基于 Pi 原生 `preflightResult(success)` 对齐事务边界。

目标流程：

```text
前端 Draft
↓
prepare Runtime
↓
Prompt Preflight
├─ false → rollbackPrepared
│
└─ true → commit / finalize
         ↓
      Agent 正式执行
```

不得使用“整轮执行是否抛异常”代替 Prompt Accepted 判断。

### 验收标准

至少覆盖以下场景：

- 无可用模型导致首次 Prompt preflight 失败。
- 认证失败导致首次 Prompt preflight 失败。
- 其他 preflight rejected 场景。

Rejected 后必须满足：

- 不产生正式 Session Metadata。
- 不产生新的 Project 引用。
- Session 不进入正式 Session List。
- Prepared Runtime 被正确清理。
- 不残留 Pending 状态。

首次 Prompt preflight 成功后必须满足：

- Session 正常正式化。
- Session ID 保持一致。
- Streaming 正常。
- 后续 Prompt 正常。

### 状态

**已修复（2026-08-21，随 S6 收口提交）**

修复内容：

- `PiRuntimeAdapter.prompt()` 基于 Pi 原生 `preflightResult(success)` 判定受理：
  - preflight rejected（无模型/无认证等）→ 返回 `{ accepted: false, reason: "preflight_rejected" }`，不抛错；
  - preflight accepted 但执行期抛错 → 重新抛出并标记 `promptAccepted`，避免上层把已接受 Session 误回滚。
- Gateway `POST /v1/sessions/{id}/commands` 事务边界以 `PromptAck.accepted` 为准，不再仅凭“是否 throw”：
  - `accepted: true` → `commitPrepared` + `finalizePrepared`；
  - `accepted: false` → `rollbackPrepared`（清理 runtime / sessionFile / metadata / 新建 Project 引用）；
  - 已标记 `promptAccepted` 的执行期错误不触发回滚。
- 回归测试：`pi-adapter.test.ts`（preflight 契约 3 例）+ `gateway.test.ts`（事务边界 accepted/rejected）。

真实 LLM 端到端 rejected 场景（无模型 / 认证失败 / 其他 preflight rejected）留待 S6-03 全量验收 H 项在真实环境验证。

---

## S6-02｜Project Remove 与 Project 自动发现逻辑语义冲突

**优先级：P1**

**是否阻塞封版：是**

### 问题描述

当前存在两套可能互相冲突的逻辑：

```text
removeProject()
→ 从 Project Registry 删除
```

同时：

```text
listProjects()
→ 扫描 Session Metadata
→ 发现 projectDirectory
→ Registry 不存在
→ 自动重新注册 Project
```

可能导致：

```text
用户删除项目
↓
删除成功
↓
刷新项目列表
↓
项目再次出现
```

这说明“删除项目”的产品语义尚未完全冻结。

### S6 冻结语义

S6 不引入：

- Project Archive
- Hidden Project
- Soft Delete
- Session Detach
- Project Lifecycle

统一采用最小且确定的规则：

> 只有没有任何 Session 引用的 Project 才允许从 Project Registry 删除。

### 目标行为

```text
DELETE Project
↓
检查 Session 引用

有引用
→ 409 project_in_use
→ Project 不删除

无引用
→ 删除 Project Registry
```

前端提示建议：

> 该项目仍有关联会话，暂不能移除。

### 验收标准

必须覆盖：

1. Project 无 Session 引用：
   - 删除成功。
   - 刷新后不重新出现。

2. Project 有 Session 引用：
   - 返回 `409 project_in_use`。
   - Project Registry 不变。
   - Session 不变。

3. 删除 Project 最后一个关联 Session 后：
   - Project 可以正常删除。

### 状态

**已修复（2026-08-21，随 S6 收口提交）**

修复内容：

- `SessionRouter.removeProject()` 按冻结语义检查 Session 引用：有任一 Session 引用 → throw `project in use`；无引用 → 删除。
- Gateway `DELETE /v1/projects` 映射：`project in use` → `409 project_in_use`；不存在 → `404 project_not_found`。
- 路径匹配同时尝试 canonical（realpath）与原值，兼容创建时 canonical 化后的存储。
- Pi Web `SessionSidebar` 收到 409 时提示“该项目仍有关联会话，暂不能移除”（en/zh-CN i18n），项目保持可见。
- 回归测试：`session-router.test.ts`（引用拒绝 / 删最后 Session 后可删 / 无引用删除）+ `gateway.test.ts`（409 映射 / 200 无引用）。

验收标准 1~3（无引用可删、有引用 409、删最后关联 Session 后可删）均已在单测覆盖；真实链路验证归 S6-03。

---

## S6-03｜本地最新代码尚未完成最终全量验收

**优先级：P1**

**是否阻塞封版：是**

### 问题描述

此前版本已经存在测试全绿记录，但当前本地最新 S6 代码又增加或调整了：

- 无项目 Session 独立 Workspace。
- Project Identity。
- Project Registry。
- Prepare / Commit / Rollback。
- 新 Session 延迟正式化。
- 生产环境禁止 Web 回退自持 Runtime。
- Session 删除闭环。
- SSE 懒恢复。
- Thinking Level 实际生效值返回。

因此不得沿用旧版本测试结果作为当前 S6 最终验收结论。

### 最终验收范围

#### A. Runtime

- 全量 Unit Test 通过。
- Typecheck 0 Error。

#### B. Session 生命周期

- 创建无项目 Session。
- 创建有项目 Session。
- 首次 Prompt 成功。
- 首次 Prompt rejected → rollback。
- Session Resume。
- Gateway 重启后 Resume。
- Session Delete。

#### C. 并发与生命周期

- 同 Session Prompt 串行。
- 不同 Session 可独立执行。
- 同 Session 并发创建不产生多个 Runtime。
- Idle Reclaim 正常。

#### D. SSE

- 新 Session Streaming。
- 历史 Session 懒恢复。
- SSE 先连接再发送 Prompt。
- SSE Disconnect 不销毁 Runtime。
- Reconnect 后能恢复 State Snapshot。

#### E. Project

- Canonical Path 正常。
- Windows 大小写 / 分隔符归一。
- Project Display Name 正常。
- Project Remove 按 S6-02 冻结规则执行。
- 无项目 Session 不进入 Project。

#### F. Web

- Draft 不提前创建正式 Session。
- 首次发送后才正式化。
- Session List 正确。
- 无项目区域正确。
- Project 分组正确。
- Streaming 正常。
- Gateway 不可用时明确返回错误。
- Production 环境不得 fallback 到 Web 自持 AgentSession。

#### G. WeChat

- 登录正常。
- 收消息正常。
- 发消息正常。
- Contact → Session Binding 正常。
- 可继续已有 Session。
- Session 删除后 Binding 正确清理或失效。

#### H. 真实 LLM 集成

至少覆盖：

```text
create → prompt → streaming

dispose → resume → continue

model switch → recover

no-project + project 并存
```

### 通过标准

只有全部关键项通过，才能标记：

```text
S6 = 完成
```

### 状态

待最终验收。

---

## S6-04｜生产管理脚本存在本机绝对路径绑定

**优先级：P2**

**是否阻塞封版：否**

### 问题描述

生产管理脚本中存在类似：

```text
/Users/.../Yuanyi-Pi-prod/personal-runtime
```

的本机绝对路径。

当前环境可正常工作，但脚本与固定机器目录绑定。

### 建议处理

如果收口时修改成本很低，可改为基于脚本自身目录定位：

```text
SCRIPT_DIR
→ APP_DIR
```

或允许环境变量覆盖。

### 约束

不得因为该问题开展脚本体系重构。

如果修改会扩大范围，则保持现状，记录为已知工程债务。

### 状态

可选处理。

---

## S6-05｜Legacy Web Runtime 回退代码仍存在

**优先级：P2**

**是否阻塞封版：否**

### 当前状态

生产环境已经要求：

```text
Production
→ Personal Gateway Only
```

旧 Pi Web Runtime 只允许在：

```text
非生产环境
+
显式启用 Legacy Runtime
```

时使用。

### 处理结论

S6 不删除 Legacy Runtime 代码。

原因：

- 删除会扩大改动范围。
- 容易引入额外回归。
- 当前生产 Runtime Ownership 已经通过运行约束封闭。

### 必须验证

生产环境：

```text
Personal Gateway unavailable
↓
返回 runtime_unavailable / 503
↓
不得创建 Web 自持 AgentSession
```

满足即可。

### 状态

S6 不处理，仅验证边界。

---

# 4. 问题优先级总表

| 编号 | 问题 | 优先级 | 阻塞封版 | 处理结论 |
|---|---|---:|---:|---|
| S6-01 | 首次 Prompt rejected 后 Prepared Session 可能错误正式化 | P0 | 是 | 必须修复 |
| S6-02 | Project Remove 与自动 Project Discovery 语义冲突 | P1 | 是 | 必须修复 |
| S6-03 | 最新本地代码尚未完成最终全量验收 | P1 | 是 | 必须完成 |
| S6-04 | 生产管理脚本存在绝对路径绑定 | P2 | 否 | 可顺手处理 |
| S6-05 | Legacy Web Runtime 代码仍存在 | P2 | 否 | S6 不处理 |

---

# 5. 明确不属于 S6 的事项

以下内容不得在 S6 收口阶段继续开发：

- Desktop。
- 更多 IM Channel。
- Memory。
- Automation。
- Background Task。
- 复杂 Orchestration。
- Skill 自动召回。
- Task Planner。
- Subagent 调度增强。
- Permission System 深化。
- 多设备同步。
- 云端 Runtime。
- Project Archive。
- Project Tag。
- 更多模型策略。

这些属于未来能力，不属于 S6 Bug。

---

# 6. 收口执行顺序

S6 最终只允许按照以下顺序推进：

```text
修复 S6-01
↓
修复 S6-02
↓
执行 S6-03 全量验收
↓
如修改成本极低，可处理 S6-04
↓
验证 S6-05 生产边界
↓
Commit
↓
Push
↓
标记 S6 完成
↓
停止 Personal Runtime 架构扩展
```

---

# 7. S6 封版条件

只有以下条件全部满足，S6 才可正式封版：

- [ ] S6-01 已修复并有回归测试。
- [ ] S6-02 已按冻结语义实现并有回归测试。
- [ ] 全量 Unit Test 通过。
- [ ] Typecheck 0 Error。
- [ ] Web 真实链路通过。
- [ ] WeChat 真实链路通过。
- [ ] Session Resume / Delete / SSE Reconnect 通过。
- [ ] Production 不存在第二 Runtime Owner。
- [ ] Personal Gateway 不可用时生产环境不得回退旧 Runtime。
- [ ] 最新代码已 Commit。
- [ ] 最新代码已 Push。
- [ ] S6 文档状态更新为“完成”。

最终状态：

```text
S1 ✅
S2 ✅
S3 ✅
S4 ✅
S5 ✅
S6 ✅ Personal Runtime 架构验证完成
```

S6 完成后，Personal Runtime 建设线停止扩展；后续新能力必须作为新的独立阶段重新立项。
