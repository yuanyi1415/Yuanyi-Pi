# 002-Pi Personal S6 稳定化问题台账

> **文档编号**：002
> **文档阶段**：04-交付 / S6 稳定化收口
> **版本**：第二轮代码审查版
> **事实基线**：2026-08-20 最新 Yuanyi-Pi-dev
> **用途**：作为 Codex 本轮唯一整改输入
> **目标**：关闭剩余 S6 问题，达到 S6 Exit Gate，进入真实运行验收
> **约束**：只修本文问题，不扩展 Memory、Scheduler、Desktop、Subagent、新 Channel 等后续能力

------

# 一、文档本体

## 1.1 当前阶段

S6 第一轮开发及第一轮整改已经解决大部分 Runtime 核心问题。

已经冻结为通过的能力：

| 项目                                | 状态       |
| ----------------------------------- | ---------- |
| Prompt 同 Session 串行              | ✅ 冻结     |
| Runtime Idle 真实状态回收           | ✅ 冻结     |
| Gateway / Legacy fail-closed 主逻辑 | ✅ 冻结     |
| 删除 Session 清理微信 Binding       | ✅ 冻结     |
| AI Session Auto-name                | ✅ 冻结     |
| Projectless Workspace 后端模型      | ✅ 冻结     |
| Gateway Streaming reconnect 主链    | ✅ 基本完成 |

以上功能**不得在本轮重新设计或大规模重构**。

当前只处理第二轮代码审查发现的剩余问题。

------

## 1.2 本轮目标

本轮完成后必须达到：

```text
Yuanyi-Pi-dev
    ↓
S6 自动化测试
    ↓
S6 真实运行验收
    ↓
代码复审
    ↓
Git 稳定版本
    ↓
Yuanyi-Pi-prod
```

在本文所有阻塞项关闭之前：

> **不得同步 prod，不得宣布 S6 完成。**

------

# 二、冻结架构规则

## 2.1 Session 产品模型

产品侧只有两类 Session：

```text
Session
├── 话题
└── 项目 Session
```

### 话题

```text
projectDirectory = null
runtimeCwd       = 独立 Projectless Workspace
```

例如：

```text
~/.yuanyi-pi/workspaces/<session-id>/
```

### 项目 Session

```text
projectDirectory = 用户选择的真实本地目录
runtimeCwd       = projectDirectory
```

判断 Session 是否属于项目只允许：

```ts
session.projectDirectory !== null
```

禁止通过：

```ts
runtimeCwd
cwd
workspace path
```

反推项目语义。

------

## 2.2 Web 产品语义

Web 左侧结构：

```text
话题
├── 会话 A
├── 会话 B
└── 会话 C

Yuanyi-Pi-dev
├── 会话 D
└── 会话 E

AI平台
├── 会话 F
└── 会话 G
```

系统内部的：

```text
~/.yuanyi-pi/workspaces/<session-id>
```

永远不得显示成项目。

------

## 2.3 dev / prod 生命周期

### dev

```text
开发者
↓
显式 start / stop / restart
↓
Personal Runtime
```

要求：

- 不默认后台启动；
- 不默认 launchd；
- 不跟随 Web 自动启动；
- 同时只能存在一个 dev Runtime；
- Gateway 未运行时 Web 明确显示 unavailable。

### prod

```text
launchd
↓
Personal Runtime / Gateway
```

要求：

- 默认后台常驻；
- 自动启动；
- KeepAlive；
- 崩溃恢复；
- 单实例；
- Health；
- Web 不参与生命周期。

------

# 三、本轮问题总表

| 编号     | 问题                                               | 优先级 | 阻塞发布 |
| -------- | -------------------------------------------------- | ------ | -------- |
| S6-R2-01 | “话题”Web 入口和状态模型未完全闭环                 | P0     | 是       |
| S6-R2-02 | dev Runtime PID / 进程管理存在实际缺陷             | P0     | 是       |
| S6-R2-03 | prod Supervisor 配置缺失                           | P0     | 是       |
| S6-R2-04 | dev 环境参数写死进入共享源码                       | P0     | 是       |
| S6-R2-05 | Streaming 性能 T3 埋点位置错误，无法完成 P95 验收  | P0     | 是       |
| S6-R2-06 | Session `/document` 路径仍未完整支持 defer         | P1     | 是       |
| S6-R2-07 | Gateway Initial Snapshot 与实时 Event 存在顺序竞态 | P1     | 是       |

------

# 四、S6-R2-01 “话题”Web 入口闭环

## 4.1 当前事实

后端已经完成：

```text
projectDirectory = null
runtimeCwd = 独立 Session Workspace
```

该部分保持不动。

当前剩余问题主要在：

```text
pi-web/components/SessionSidebar.tsx
```

及其上层 Session 状态管理。

当前存在类似：

```ts
if (session.cwd) {
  setSelectedCwd(session.cwd);
}
```

问题：

当从项目 Session：

```text
/Users/.../Yuanyi-Pi-dev
```

切换到话题时：

```text
session.cwd = ""
```

条件不会执行。

因此：

```text
selectedCwd
```

仍可能保留上一个项目目录。

随后点击：

```text
新建会话
```

可能错误创建成上一个项目的 Session。

------

## 4.2 目标状态

`selectedCwd` 必须只表达：

> 用户当前明确选择的新建 Session 项目。

建议类型：

```ts
type SelectedProjectDirectory = string | null;
```

语义：

```text
null
→ 话题

string
→ 项目 Session
```

不要再用：

```text
""
undefined
最近项目
```

混合表达“话题”。

------

## 4.3 必须修改：话题成为显式选择项

项目选择控件增加固定第一项：

```text
话题
────────────
Yuanyi-Pi-dev
AI平台
其他项目……
```

推荐数据结构：

```ts
type SessionTarget =
  | {
      type: "topic";
      projectDirectory: null;
    }
  | {
      type: "project";
      projectDirectory: string;
    };
```

如果不希望本轮引入新类型，最低要求：

```ts
selectedCwd: string | null;
```

------

## 4.4 推荐 UI 实现

例如：

```tsx
<button
  type="button"
  onClick={() => setSelectedCwd(null)}
  className={selectedCwd === null ? "selected" : ""}
>
  话题
</button>

{projectDirectories.map((projectDirectory) => (
  <button
    key={projectDirectory}
    type="button"
    onClick={() => setSelectedCwd(projectDirectory)}
    className={
      selectedCwd === projectDirectory ? "selected" : ""
    }
  >
    {getProjectDisplayName(projectDirectory)}
  </button>
))}
```

具体样式复用当前项目选择器，**不要为本需求重新设计整套 UI**。

------

## 4.5 新建会话

新建按钮必须永远可点击。

禁止继续：

```tsx
disabled={!selectedCwd}
```

应为：

```tsx
<Button onClick={handleNewSession}>
  新建会话
</Button>
```

创建：

```ts
const handleNewSession = () => {
  onNewSession?.({
    projectDirectory: selectedCwd
  });
};
```

其中：

```text
selectedCwd === null
→ 创建话题
```

------

## 4.6 切换现有 Session 时同步选择状态

禁止：

```ts
if (session.cwd) {
  setSelectedCwd(session.cwd);
}
```

修改为显式覆盖：

```ts
setSelectedCwd(
  session.projectDirectory ?? null
);
```

如果当前前端 DTO 还没有：

```ts
projectDirectory
```

必须补 DTO。

不要继续拿：

```ts
runtimeCwd
cwd
```

代替项目目录。

------

## 4.7 默认行为

Web 初次启动或没有显式选择项目时：

```text
selectedCwd = null
```

即：

> 默认创建“话题”。

禁止自动：

```text
没有 selectedCwd
↓
自动选择最近项目
```

如果当前存在类似：

```ts
if (!selectedCwd && projects.length > 0) {
  setSelectedCwd(projects[0].path);
}
```

必须删除。

------

## 4.8 左侧 Session 分组

不要因为当前：

```text
selectedCwd = 某项目
```

就从 Sidebar 隐藏“话题”。

Sidebar 一级组织应始终保留：

```text
话题
项目 A
项目 B
```

如果当前代码存在：

```ts
sessions.filter(
  session => session.cwd === selectedCwd
)
```

需要改为：

> 项目选择器决定“新建 Session 的目标”，而不是决定 Session Sidebar 只能显示哪个分组。

------

## 4.9 需要增加的测试

至少增加：

```text
1. 初次打开 Web，selectedCwd=null
2. 点击新建会话 → 创建话题
3. projectDirectory=null
4. runtimeCwd 存在且为独立 Workspace

5. 选择项目 A
6. 新建 → 项目 A Session

7. 点击已有话题
8. selectedCwd 被清成 null
9. 再点新建 → 创建新话题，而不是项目 A Session
```

------

## 4.10 验收

-  默认新建为话题
-  存在显式“话题”选择项
-  点击已有话题后项目选择被清空
-  不再自动选择最近项目
-  新建按钮永远可用
-  话题一直作为 Sidebar 一级分组存在
-  Web 不展示 Projectless Workspace 路径

------

# 五、S6-R2-02 dev Runtime PID 管理

## 5.1 当前问题

当前 dev 启动脚本仍存在类似：

```bash
nohup npm start > "$LOG_FILE" 2>&1 &
echo $! > "$PID_FILE"
```

但：

```bash
$!
```

是：

```text
npm start
```

父进程 PID。

真正的 Runtime 往往是：

```text
npm
└── node / tsx src/index.ts
```

子进程。

而当前新增的 PID 校验又可能要求命令包含：

```text
personal-runtime/src/index.ts
```

于是会发生：

```text
Runtime 已启动
↓
PID_FILE 保存 npm PID
↓
pid_matches() 认为它不是 Runtime
↓
脚本误报失败
```

stop 时只杀：

```text
npm PID
```

还可能留下 Node 子进程。

------

## 5.2 目标

dev 启动脚本必须：

> **直接持有真实 Personal Runtime 进程 PID。**

------

## 5.3 推荐修改方式

不要再通过：

```bash
npm start &
```

产生多层 wrapper。

直接执行实际 Runtime 启动入口。

例如，如果项目使用 tsx：

```bash
nohup ./node_modules/.bin/tsx src/index.ts \
  >> "$LOG_FILE" 2>&1 &

RUNTIME_PID=$!
echo "$RUNTIME_PID" > "$PID_FILE"
```

如果最终构建为 JS：

```bash
nohup node dist/index.js \
  >> "$LOG_FILE" 2>&1 &

RUNTIME_PID=$!
echo "$RUNTIME_PID" > "$PID_FILE"
```

以当前项目真实启动方式为准。

------

## 5.4 PID 校验

建议：

```bash
pid_is_runtime() {
  local pid="$1"

  kill -0 "$pid" 2>/dev/null || return 1

  local command
  command="$(ps -p "$pid" -o command=)"

  [[ "$command" == *"personal-runtime"* ]] ||
  [[ "$command" == *"src/index.ts"* ]] ||
  [[ "$command" == *"dist/index.js"* ]]
}
```

不要依赖 npm wrapper。

------

## 5.5 start

推荐流程：

```text
读取 PID_FILE
↓
PID 存在且为真实 Runtime？
├─ 是 → 返回 already running
└─ 否
    ↓
检查 Runtime 端口
├─ 已占用 → 报明确错误，不强杀未知进程
└─ 空闲
    ↓
启动真实 Runtime
    ↓
写真实 PID
    ↓
轮询 /health
    ↓
成功
```

------

## 5.6 stop

```bash
stop_runtime() {
  if [ ! -f "$PID_FILE" ]; then
    echo "Personal Runtime is not running."
    return 0
  fi

  local pid
  pid="$(cat "$PID_FILE")"

  if ! pid_is_runtime "$pid"; then
    rm -f "$PID_FILE"
    echo "Stale runtime PID file removed."
    return 0
  fi

  kill "$pid"

  for _ in {1..20}; do
    if ! kill -0 "$pid" 2>/dev/null; then
      rm -f "$PID_FILE"
      return 0
    fi

    sleep 0.25
  done

  kill -9 "$pid"
  rm -f "$PID_FILE"
}
```

具体循环写法根据 shell 兼容性调整。

------

## 5.7 dev 明确保持手动启动

本项修复**不得**顺带改成：

```text
launchd 自动启动 dev
```

dev 仍然：

```text
./personal-runtime.sh start
./personal-runtime.sh stop
./personal-runtime.sh restart
./personal-runtime.sh status
```

------

## 5.8 验收

至少真实执行：

```text
start
status
health
restart
status
stop
status
start
```

然后验证：

```bash
ps
lsof -i :<dev-gateway-port>
```

必须：

-  任何时候只有一个 Runtime
-  stop 后端口真正释放
-  无孤儿 Node 进程
-  restart 不出现 EADDRINUSE
-  PID_FILE 指向真正 Runtime

------

# 六、S6-R2-03 prod Supervisor 配置恢复

## 6.1 当前问题

为了避免 dev 自动 launchd，最新版删除了 launchd 配置。

方向只对了一半。

正确设计不是：

```text
项目中不存在 launchd
```

而是：

```text
dev 不使用 launchd
prod 使用 versioned launchd 配置
```

------

## 6.2 推荐目录

建议增加：

```text
deploy/
└── prod/
    └── launchd/
        └── com.yuanyi.personal-runtime.plist
```

或者：

```text
personal-runtime/
└── deploy/
    └── prod/
        └── com.yuanyi.personal-runtime.plist
```

二选一。

优先选择与现有工程目录规范一致的位置。

------

## 6.3 plist 原则

配置必须属于：

> **prod 部署模板**

不允许引用：

```text
Yuanyi-Pi-dev
.pi-dev
8771
30142
```

应使用 prod 的正式路径与参数。

示意：

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC
  "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">

<plist version="1.0">
<dict>

  <key>Label</key>
  <string>com.yuanyi.personal-runtime</string>

  <key>ProgramArguments</key>
  <array>
    <string>/usr/bin/env</string>
    <string>node</string>
    <string>PROD_RUNTIME_ENTRY</string>
  </array>

  <key>WorkingDirectory</key>
  <string>PROD_YUANYI_PI_ROOT</string>

  <key>RunAtLoad</key>
  <true/>

  <key>KeepAlive</key>
  <true/>

</dict>
</plist>
```

实际路径由 prod 部署脚本生成或安装时替换。

不要直接复制示意路径。

------

## 6.4 本轮要求

只要求：

- 配置随 Git 版本管理；
- dev 不自动安装；
- prod 有明确 Supervisor 模板；
- 下一步同步 prod 时可以据此安装。

本轮不要开发通用部署平台。

------

# 七、S6-R2-04 dev / prod 环境参数分离

## 7.1 当前问题

当前共享：

```text
pi-web/package.json
```

存在 dev 参数硬编码，例如：

```text
PERSONAL_GATEWAY_URL=http://127.0.0.1:8771
PI_CODING_AGENT_DIR=$HOME/.pi-dev/agent
```

并且：

```text
pi-web/scripts/pi-web.sh
```

也写死类似：

```text
Yuanyi-Pi-dev
30142
8771
```

这是当前同步 prod 最大风险之一。

------

## 7.2 冻结规则

共享源代码：

```text
不得知道自己是 dev 还是 prod
```

环境差异必须来自：

```text
环境配置 / launcher / deploy
```

------

## 7.3 package.json 修改

错误：

```json
{
  "scripts": {
    "dev": "PERSONAL_GATEWAY_URL=http://127.0.0.1:8771 next dev",
    "start": "PERSONAL_GATEWAY_URL=http://127.0.0.1:8771 next start"
  }
}
```

修改为环境中立：

```json
{
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start"
  }
}
```

如果需要指定 Web port，也不要把 dev/prod 两套值写进共同命令。

------

## 7.4 dev 配置

推荐通过开发 launcher：

```text
scripts/dev/
```

或：

```text
.env.development.local
```

但如果 `.env.*.local` 属于个人本地配置，不应提交 Git。

可以提交：

```text
.env.development.example
```

示意：

```env
PERSONAL_GATEWAY_URL=http://127.0.0.1:8771
PI_CODING_AGENT_DIR=~/.pi-dev/agent
YUANYI_RUNTIME_ENV=dev
```

真实 dev 启动脚本负责 export。

例如：

```bash
export PERSONAL_GATEWAY_URL="http://127.0.0.1:8771"
export PI_CODING_AGENT_DIR="$HOME/.pi-dev/agent"
export YUANYI_RUNTIME_ENV="dev"

npm run dev
```

------

## 7.5 prod 配置

prod 不进入 package.json。

由：

```text
deploy/prod/
```

提供。

例如：

```env
PERSONAL_GATEWAY_URL=http://127.0.0.1:8770
PI_CODING_AGENT_DIR=~/.pi/agent
YUANYI_RUNTIME_ENV=prod
```

实际端口以当前冻结生产配置为准。

------

## 7.6 pi-web.sh

如果：

```text
pi-web.sh
```

属于 dev launcher，应该移动 / 重命名为明确 dev 文件，例如：

```text
scripts/dev/pi-web.sh
```

禁止一个看起来通用的：

```text
pi-web.sh
```

内部偷偷写死：

```text
Yuanyi-Pi-dev
8771
30142
```

如果它需要同时支持两种环境，则必须显式：

```bash
./pi-web.sh dev
./pi-web.sh prod
```

但本轮更推荐：

> dev launcher 与 prod deploy 完全分开。

结构更清晰，也不容易误操作。

------

## 7.7 增加 fail-fast

Runtime 启动时输出：

```text
Environment: dev
Gateway URL: http://127.0.0.1:8771
Coding Agent Dir: /Users/.../.pi-dev/agent
```

prod：

```text
Environment: prod
Gateway URL: http://127.0.0.1:8770
Coding Agent Dir: /Users/.../.pi/agent
```

如果：

```text
YUANYI_RUNTIME_ENV=prod
```

却检测到：

```text
.pi-dev
8771
Yuanyi-Pi-dev
```

建议直接拒绝启动。

例如：

```ts
if (
  runtimeEnv === "prod" &&
  (
    gatewayUrl.includes(":8771") ||
    codingAgentDir.includes(".pi-dev")
  )
) {
  throw new Error(
    "Production runtime contains development configuration."
  );
}
```

不要过度写死所有环境，只保护已明确的高风险 dev 配置。

------

# 八、S6-R2-05 Streaming 性能验收重做

## 8.1 当前问题

当前已经有：

```text
requestId
T0
T1
T2
```

雏形。

但是现在记录的所谓：

```text
T3
```

位于：

```text
pi-web/lib/agent-event-stream-gateway.ts
```

这是 Next.js 服务端。

所以实际上测到的是：

```text
Gateway
→ Web BFF
```

而不是：

```text
Gateway
→ Web BFF
→ Browser
```

因此当前性能验收无效。

------

## 8.2 正确定义

```text
T0 = Browser 发出 Prompt
T1 = Personal Gateway 收到 Prompt
T2 = Gateway 收到该 Prompt 的第一条模型输出
T3 = Browser 收到对应第一条模型输出
```

------

## 8.3 requestId 必须贯穿事件链

Browser：

```ts
const requestId = crypto.randomUUID();
const browserSentAt = performance.now();
```

请求：

```http
x-yuanyi-request-id: <uuid>
```

Gateway 收到：

```ts
const requestId = request.headers.get(
  "x-yuanyi-request-id"
);
```

Runtime/Gateway 第一条输出必须携带：

```ts
{
  requestId,
  ...
}
```

不能只有 Prompt 请求有 requestId，而 Event 没有。

否则 Browser 无法知道某个输出属于哪个 T0。

------

## 8.4 推荐内部 Event Envelope

不要修改 Pi 原始 AgentEvent。

在 Personal Gateway 外层包装：

```ts
interface GatewayEventEnvelope {
  requestId?: string;
  gatewayEventAt: number;
  event: AgentEvent;
}
```

第一条模型 Event：

```ts
{
  requestId,
  gatewayEventAt: performance.now(),
  event
}
```

其中：

```text
gatewayEventAt ≈ T2
```

------

## 8.5 Browser T3

真正的 T3 必须在前端 Hook 中记录。

例如：

```ts
const firstEventSeen = useRef(
  new Set<string>()
);

function handleGatewayEvent(envelope) {
  const requestId = envelope.requestId;

  if (
    requestId &&
    !firstEventSeen.current.has(requestId) &&
    isModelOutputEvent(envelope.event)
  ) {
    firstEventSeen.current.add(requestId);

    const browserFirstEventAt =
      performance.now();

    recordPerformanceSample({
      requestId,
      browserFirstEventAt
    });
  }

  // 原有 UI 事件处理
}
```

不要在 BFF 中命名为：

```text
browser_first_event_at
```

------

## 8.6 Browser 与 Gateway 时钟问题

Browser：

```text
performance.now()
```

和 Node：

```text
performance.now()
```

不是同一时钟原点。

因此不要直接计算：

```text
Browser performance.now()
-
Gateway performance.now()
```

这是错误的。

### 推荐方案

同一链路使用 Unix epoch：

```ts
Date.now()
```

记录：

```text
T0
T1
T2
T3
```

这样可以跨进程计算。

Streaming UI 内部若需要更精细耗时，再辅助 `performance.now()`。

------

## 8.7 指标

```text
Ingress Proxy
= T1 - T0
```

目标：

```text
P95 ≤ 50ms
```

模型时间：

```text
Model TTFT
= T2 - T1
```

只记录。

Streaming Proxy：

```text
T3 - T2
```

目标：

```text
P95 ≤ 50ms
```

------

## 8.8 样本记录

建议增加轻量开发脚本：

```text
scripts/perf/
└── summarize-s6-streaming.ts
```

输入 JSONL：

```json
{"requestId":"a","t0":1,"t1":2,"t2":3,"t3":4}
{"requestId":"b","t0":1,"t1":2,"t2":4,"t3":5}
```

输出：

```text
Samples: 30

Ingress:
P50: xx ms
P95: xx ms

Model TTFT:
P50: xx ms
P95: xx ms

Stream Proxy:
P50: xx ms
P95: xx ms
```

------

## 8.9 P95

可直接：

```ts
function percentile(
  values: number[],
  percentile: number
) {
  const sorted = [...values].sort(
    (a, b) => a - b
  );

  const index = Math.ceil(
    percentile * sorted.length
  ) - 1;

  return sorted[
    Math.max(0, index)
  ];
}
```

------

## 8.10 验收

必须真实完成：

```text
≥30 次 Web Prompt
```

而不是只写测试代码。

最终留下验收记录：

| 指标  | P50  | P95  | 目标  |
| ----- | ---- | ---- | ----- |
| T1-T0 | 实测 | 实测 | ≤50ms |
| T2-T1 | 实测 | 实测 | 记录  |
| T3-T2 | 实测 | 实测 | ≤50ms |

并人工确认：

-  Streaming 不批量吐字
-  无周期性停顿
-  长回答连续输出

------

# 九、S6-R2-06 `/document` defer 语义

## 9.1 当前事实

当前：

```text
/context
```

已经开始支持：

```text
deferThinking
deferMedia
```

但 Web 打开历史 Session 的主路径仍可能是：

```text
GET /api/sessions/:id
↓
Gateway /sessions/:id/document
```

该路径没有完整继承 defer。

------

## 9.2 目标

下列两条路径的投影视图语义必须一致：

```text
/context
/document
```

至少共同支持：

```text
deferThinking
deferMedia
leafId
```

------

## 9.3 推荐做法

不要两套代码分别实现。

抽出纯读取函数：

```ts
interface SessionProjectionOptions {
  leafId?: string;
  deferThinking?: boolean;
  deferMedia?: boolean;
}
```

例如：

```ts
async function readSessionProjection(
  sessionId: string,
  options: SessionProjectionOptions
) {
  // 只读 session 文件
  // 不创建 AgentSession
  // 不修改 Runtime
}
```

然后：

```text
/context
↓
readSessionProjection()

/document
↓
readSessionProjection()
```

------

## 9.4 重要边界

该读取函数：

```text
不是 Runtime Owner
```

所以：

```text
读取 session 文件
解析历史消息
裁剪 thinking
裁剪 media
```

可以是纯持久化读取。

不要为了 Runtime Ownership 强制：

```text
读取历史
→ create AgentSession
```

------

## 9.5 测试

构造 Session：

```text
普通文本
thinking
大图片/base64
tool result image
```

分别请求：

```text
deferThinking=true
deferMedia=true
```

确认：

- thinking 被延迟；
- media 不进入首屏 payload；
- false 时完整返回；
- `/context` 与 `/document` 语义一致。

------

# 十、S6-R2-07 Initial Snapshot / Event 顺序

## 10.1 当前问题

Web reconnect 主功能已经实现：

```text
真实 isStreaming
+
streamingMessage
```

但是当前 Gateway SSE 初始化可能类似：

```text
异步 getState()
+
同时 subscribe Runtime Event
```

存在极短竞态：

```text
Event 先到
↓
Snapshot 后到
```

客户端可能先应用最新状态，再被旧 Snapshot 覆盖。

------

## 10.2 最简单修改方式

优先采用：

```text
先订阅
↓
暂存实时事件
↓
读取 Runtime State
↓
发送 Initial Snapshot
↓
flush buffered events
↓
进入正常实时转发
```

这样不会丢掉 snapshot 查询期间产生的事件。

------

## 10.3 推荐伪代码

```ts
const bufferedEvents: AgentEvent[] = [];
let initialized = false;

const unsubscribe = runtime.subscribe(
  (event) => {
    if (!initialized) {
      bufferedEvents.push(event);
      return;
    }

    sendRuntimeEvent(event);
  }
);

try {
  const state =
    await runtime.getState();

  send({
    type: "connected",
    sessionId,
    isStreaming: state.isStreaming
  });

  if (
    state.isStreaming &&
    state.streamingMessage
  ) {
    send({
      type: "message_start",
      message: state.streamingMessage
    });
  }

  initialized = true;

  for (const event of bufferedEvents) {
    sendRuntimeEvent(event);
  }

  bufferedEvents.length = 0;
} catch (error) {
  unsubscribe();
  throw error;
}
```

注意：

真实代码需避免：

```text
snapshot 中已经包含的 message update
+
buffer 又重复发送
```

如果 Pi Event 有 sequence / message id，应据此去重。

如果没有，最低保证：

> 不丢事件优先于极短时间内重复一次增量。

但应该尽量基于当前 Event 结构实现精确去重。

------

## 10.4 测试

增加高频事件模拟：

```text
subscribe
↓
getState 延迟 50ms
↓
延迟期间产生 message_update
↓
完成 snapshot
```

验证客户端最终消息：

- 不丢；
- 顺序正确；
- 不被 snapshot 回滚；
- Agent 最终状态正确。

------

# 十一、本轮禁止修改的内容

Codex 必须遵守。

## 11.1 禁止重新设计 Runtime

不得：

```text
Web 创建 AgentSession
Web 成为 Runtime Owner
合并 Web + Personal Runtime
```

------

## 11.2 禁止改变 dev/prod原则

不得：

```text
dev 默认 launchd
```

也不得：

```text
prod 手工 nohup 长期运行
```

------

## 11.3 禁止重新设计 Session 本体

保持：

```text
话题
projectDirectory=null
独立 Workspace
```

不要重新引入：

- Profile
- Work / Personal
- 虚拟 Project
- Workspace 作为项目

------

## 11.4 禁止扩展新能力

不要顺手建设：

- Memory
- Scheduler
- Desktop
- Subagent
- 新 Channel
- Plugin Manager

------

# 十二、Codex 推荐实施顺序

必须按依赖关系执行。

## 第一阶段：环境与生命周期

```text
S6-R2-02 dev PID
S6-R2-03 prod Supervisor
S6-R2-04 环境配置分离
```

完成后先验证：

```text
dev 启停
prod 配置
环境不串线
```

------

## 第二阶段：话题 Web 闭环

```text
S6-R2-01
```

完成：

```text
默认话题
显式话题
切换清状态
项目 Session
Sidebar 分组
```

------

## 第三阶段：Session / Streaming 正确性

```text
S6-R2-06 defer
S6-R2-07 reconnect ordering
```

------

## 第四阶段：性能

最后实施：

```text
S6-R2-05
```

因为前面的代码变化可能影响性能结果。

------

# 十三、要求 Codex 增加的最小测试集

## Runtime Lifecycle

```text
dev start
dev repeat start
dev status
dev restart
dev stop
port release
no orphan process
```

## 话题

```text
default → topic
topic → project
project → topic
topic → new topic
independent runtimeCwd
projectDirectory=null
```

## Environment

```text
dev launcher → dev Gateway
prod config → prod Gateway
prod cannot contain .pi-dev
prod cannot use dev port
```

## Reconnect

```text
Agent streaming
↓
disconnect Web
↓
reconnect
↓
recover snapshot
↓
continue stream
```

## Session projection

```text
deferThinking true/false
deferMedia true/false
/context
/document
```

## Performance

```text
requestId
T0
T1
T2
Browser T3
≥30 samples
P50
P95
```

------

# 十四、S6 最终 Exit Gate

以下全部通过后才进入发布。

## Runtime

-  Prompt 串行保持通过
-  Idle 回收保持通过
-  Web 不是 Runtime Owner
-  dev Runtime 手动可控
-  dev 无孤儿进程
-  prod launchd 配置存在
-  prod Supervisor 唯一

## Environment

-  package.json 无 dev 地址硬编码
-  dev / prod 参数完全分离
-  prod 不可能误连 dev Gateway
-  prod 不引用 `.pi-dev`
-  Gateway fail-closed

## Session

-  默认新建“话题”
-  话题是显式选择项
-  话题 `projectDirectory=null`
-  每个话题独立 Workspace
-  项目切换至话题正确清空项目状态
-  runtimeCwd 不作为项目展示

## Web

-  Web 重启不影响 Agent Run
-  reconnect Snapshot 正确
-  不丢 Streaming Event
-  `/context` defer 正确
-  `/document` defer 正确
-  Auto-name 保持通过

## Channel

-  微信 Binding 清理保持通过
-  Web 关闭期间微信继续运行
-  Web / 微信继续共享 Session

## Performance

-  完成真实 ≥30 次样本
-  `T1-T0 P95 ≤ 50ms`
-  `T3-T2 P95 ≤ 50ms`
-  无明显 Streaming 积压

------

# 十五、本轮完成定义

Codex 不得只依据：

```text
代码已修改
测试能启动
单元测试通过
```

宣布完成。

本轮完成必须同时满足：

```text
代码实现
+
自动化测试
+
dev 真实运行
+
性能数据
+
问题台账逐项核销
```

完成后提交：

1. 修改文件清单；
2. 每项 Issue 对应修改说明；
3. 新增/修改测试清单；
4. 自动化测试结果；
5. Runtime dev 启停验证结果；
6. 话题真实 Web 操作结果；
7. Web reconnect 验证结果；
8. 30 次性能测试 P50/P95；
9. 尚未解决的问题，如有必须明确列出。

只有这些证据齐全，才能进入下一次代码复审。