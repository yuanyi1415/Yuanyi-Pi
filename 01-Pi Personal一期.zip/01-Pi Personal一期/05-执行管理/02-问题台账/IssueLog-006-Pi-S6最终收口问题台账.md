# Pi S6 最终收口问题台账

## 1. 文档目的

本台账用于指导 Pi S6 最后一轮收口开发。

本轮目标不是继续完善 Personal Runtime，而是只处理已经确认的收口问题，并完成最终验收。

执行原则：

- 只修改本台账列出的阻塞问题。
- 不新增任何功能。
- 不扩展 Desktop、Memory、Automation、Orchestration、更多 Channel 等范围。
- 修复完成后必须执行全量测试和真实链路冒烟。
- 全部通过后，S6 直接封版。

---

# 2. 当前总体状态

| 编号 | 问题 | 优先级 | 当前状态 | 是否阻塞 S6 封版 |
|---|---|---:|---|---:|
| S6-01 | 首次 Prompt 的 Prepared Transaction 提交时机错误 | P0 | 已修复 | 否 |
| S6-02 | Project Remove 与自动 Project Discovery 语义冲突 | P1 | 已解决 | 否 |
| S6-03 | 最新代码尚未形成最终全量验收结论 | P1 | 待验收 | 是 |
| S6-04 | 生产管理脚本存在绝对路径绑定 | P2 | 已知工程债 | 否 |
| S6-05 | Legacy Web Runtime 代码仍存在 | P2 | 已有生产防线 | 否 |

本轮真正需要开发处理的只有：

```text
S6-01
↓
S6-03
↓
封版
```

S6-02 不再修改。

---

# 3. S6-01｜首次 Prompt 的 Prepared Transaction 提交时机错误

## 3.1 问题级别

**优先级：P0**

**是否阻塞封版：是**

这是本轮唯一必须修改的代码问题。

---

## 3.2 当前问题

当前新 Session 已经引入：

```text
prepare
commit
rollback
finalize
```

并且已经接入 Pi 原生：

```text
preflightResult(success)
```

方向是正确的。

但当前事务真正的 Commit Point 仍然发生在：

```text
AgentSession.prompt()
完整执行结束以后
```

而不是：

```text
preflightResult(true)
```

发生时。

当前实际时序大致为：

```text
前端 Draft
↓
prepare Runtime
↓
调用 PiRuntimeAdapter.prompt()
↓
Pi preflightResult(true)
↓
Agent 正式执行
↓
模型 / Tool / Streaming
↓
整轮 Prompt 执行完成
↓
Adapter 返回 accepted:true
↓
Gateway commitPrepared()
↓
finalizePrepared()
```

这意味着：

> Prompt 明明已经被 Pi 接受，但 Session 仍然处于 Prepared / Pending 状态，直到整轮 Agent 执行结束。

这是错误的事务边界。

---

# 3.3 正确语义

S6 已经冻结的产品语义应该是：

> **第一次 Prompt 被 Pi Runtime 接受，就是新 Session 从 Draft / Prepared 变成正式 Session 的 Commit Point。**

因此：

```text
preflightResult(false)
=
Prompt 没被 Runtime 接受
=
rollback

preflightResult(true)
=
Prompt 已被 Runtime 接受
=
commit + finalize
```

后续 Agent 执行成功或失败，已经属于：

```text
正式 Session 内的一次运行结果
```

不能再影响 Session 是否成立。

---

# 3.4 当前实现会导致什么问题

## 场景 A：Prompt 已接受，但 Agent 后续执行异常

可能出现：

```text
prepare
↓
preflightResult(true)
↓
Prompt 已正式被 Pi 接受
↓
Agent 执行异常
↓
Adapter throw
```

当前代码已经知道该异常发生在：

```text
promptAccepted = true
```

之后，因此不会 rollback。

但是如果 Gateway 也没有及时执行：

```text
commitPrepared()
finalizePrepared()
```

就会产生：

```text
Pi Session 已存在
+
Prompt 已经进入 Agent
+
Runtime 仍存在
+
Pending 仍存在
+
Personal Metadata 没正式提交
+
Project Registry 没正式提交
+
Session List 仍可能不可见
```

形成一个典型的：

> **半提交事务。**

---

## 场景 B：正常长时间 Prompt

即使没有任何异常，也存在：

```text
preflightResult(true)
↓
Agent 执行 30 秒 / 2 分钟
↓
持续 Streaming
↓
Session 仍然处于 Prepared
```

如果这期间发生：

```text
Gateway 重启
进程异常退出
Web 刷新
其他生命周期操作
```

产品层可能尚未完成 Session 正式化。

因此当前实现虽然“最终通常能成功”，但事务边界仍然错误。

---

# 3.5 根因

当前 Adapter 虽然拿到了：

```ts
preflightResult(success)
```

但只是把结果保存为：

```ts
preflightAccepted = success
```

随后仍然：

```ts
await this.inner.prompt(...)
```

等整个 Prompt 完成后，才返回：

```ts
{ accepted: true }
```

因此 Gateway 无法在：

```text
preflightResult(true)
```

发生的那一刻立刻完成 Session Commit。

本质问题是：

> **Pi 原生 Preflight 信号没有被实时传递到 Gateway 的 Prepared Transaction。**

---

# 3.6 修改方案

不要重新设计事务体系。

只需要在当前调用链中增加一个非常薄的 Preflight Callback。

建议链路：

```text
Gateway
↓
RuntimeManager
↓
PiRuntimeAdapter
↓
AgentSession.prompt()
```

增加：

```text
onPromptPreflight
```

或等价内部回调。

---

# 3.7 推荐具体改法

## 第一步：PiRuntimeAdapter.prompt 增加 callback

当前类似：

```ts
async prompt(message: string): Promise<PromptResult>
```

调整为类似：

```ts
async prompt(
  message: string,
  options?: {
    onPreflight?: (accepted: boolean) => void | Promise<void>;
  },
): Promise<PromptResult>
```

在调用 Pi 时：

```ts
await this.inner.prompt(message, {
  preflightResult: (success) => {
    preflightAccepted = success;
    void options?.onPreflight?.(success);
  },
});
```

如果回调需要保证事务完成后才能继续 Agent 正式运行，则不能使用无法等待的 fire-and-forget 语义。

应根据 Pi `preflightResult` 的真实 callback 类型选择可靠方案。

如果 Pi 原生 callback 不能 `await Promise`，则建议：

```text
preflightResult(true)
↓
只发出同步信号 / resolve Deferred Promise
↓
Gateway 等待该信号
↓
commit/finalize
```

不要在 callback 内直接做复杂异步事务并假设 Pi 会等待。

---

## 第二步：RuntimeManager 透传 Preflight 状态

如果当前 Prompt 必须经过 RuntimeManager：

```text
Gateway
→ RuntimeManager.sendCommand()
→ Adapter.sendCommand()
```

则给 Prompt 命令增加内部执行选项。

注意：

> 不需要修改对外 HTTP Contract。

这是 Runtime 内部控制信号，不应该暴露成新的产品 API。

可以采用：

```ts
runtime.sendCommand(command, {
  onPromptPreflight
})
```

或单独：

```ts
runtime.prompt(message, {
  onPreflight
})
```

具体形式以现有代码最小改动为准。

原则只有一个：

> Gateway 必须能在 Pi 的 `preflightResult` 出现时收到实时通知。

---

## 第三步：Gateway 把 Commit Point 移到 preflight accepted

Prepared Session 首次 Prompt 时：

### Preflight False

执行：

```text
rollbackPrepared()
```

然后返回 Prompt rejected。

必须确保：

```text
Metadata 不存在
Project 不新增
Pending 被清理
Runtime 被清理
正式 Session List 不出现
```

---

### Preflight True

必须立即执行：

```text
commitPrepared()
↓
finalizePrepared()
```

然后 Agent 可以继续执行。

即：

```text
prepare
↓
Pi preflight
├─ false
│   ↓
│ rollback
│
└─ true
    ↓
  commit
    ↓
 finalize
    ↓
  Agent Loop 继续
```

---

# 3.8 异常处理必须重新校正

修改后需要明确区分两个阶段。

## 阶段一：Preflight 之前失败

例如：

```text
无模型
认证失败
Compaction 状态不允许
其他 Pi preflight rejection
```

行为：

```text
rollbackPrepared
```

Session 不成立。

---

## 阶段二：Preflight 已经 accepted

例如：

```text
LLM 调用异常
Tool 执行异常
Provider 中断
Agent Loop 后续异常
```

行为：

```text
绝对不能 rollback Session
```

因为 Session 在：

```text
preflightResult(true)
```

时已经正式成立。

此时只把：

```text
本轮执行失败
```

作为正式 Session 内部事件 / 错误处理。

---

# 3.9 必须增加的回归测试

## TEST-01｜Preflight rejected → rollback

构造：

```text
Prepared Session
↓
preflightResult(false)
```

断言：

- Session Metadata 不存在。
- Project Registry 不新增。
- Pending 不存在。
- Runtime 被释放。
- Session 不出现在正式 List。
- 返回明确 rejected。

---

## TEST-02｜Preflight accepted → 立即正式化

这是当前最缺的一条测试。

使用 Deferred / Controlled Promise 模拟：

```text
preflightResult(true)
↓
Agent 后续执行先保持 pending
```

在 Agent 尚未执行结束时立即检查：

- Session Metadata 已存在。
- Project Registry 已存在（有项目时）。
- Pending 已清除。
- Session 已能正常被查询。
- Session 已进入正式 Session List。

然后再允许 Agent Promise resolve。

这个测试用于证明：

> Commit 发生在 Preflight Accepted，而不是 Prompt 完成以后。

---

## TEST-03｜Preflight accepted + Agent execution error

构造：

```text
prepare
↓
preflightResult(true)
↓
commit / finalize
↓
Agent execution throw
```

断言：

- 不执行 rollback。
- Session Metadata 仍存在。
- Project Registry 仍存在。
- Pending 已不存在。
- Session 可 resume。
- Session 仍在正式 List。
- 本轮 Prompt 返回执行错误。

---

## TEST-04｜Preflight rejected 不产生空 Session

验证最终产品语义：

```text
用户点击新会话
↓
第一次 Prompt 被拒绝
↓
刷新页面
```

不能看到任何幽灵 / 空白 Session。

---

# 3.10 S6-01 关闭条件

只有以下全部满足才能关闭：

- [ ] Commit Point 已移动到 `preflightResult(true)`。
- [ ] `preflightResult(false)` 明确触发 rollback。
- [ ] Agent execution error 不再影响已正式化 Session。
- [ ] TEST-01 通过。
- [ ] TEST-02 通过。
- [ ] TEST-03 通过。
- [ ] TEST-04 通过。
- [ ] 不修改 Pi Core。
- [ ] 不增加新的外部 API。
- [ ] 不扩展其他功能。

---

# 3.11 修复记录（2026-08-21）

已按 3.6~3.7 方案完成，Commit Point 移至 `preflightResult(true)` 时刻：

- `PiRuntimeAdapter.prompt(message, requestId?, onPreflight?)`：在 Pi 原生 `preflightResult(success)` 回调内同步调用 `onPreflight(success)`，实现实时信号（Pi 回调为同步，无法 await；commit/finalize 均为同步写盘，可保证 Agent Loop 开始前事务完成）。
- `RuntimeManager.sendCommand/prompt` 透传 `onPromptPreflight`（内部信号，不暴露为 HTTP Contract）。
- Gateway 命令路径：`onPromptPreflight(true)` → 立即 `commitPrepared + finalizePrepared`；rejected 路径沿用返回后 `rollbackPrepared`；已标记 `promptAccepted` 的执行期错误不回滚。
- 回归测试：TEST-01（已有）、TEST-02（Deferred Promise 证明 Agent 执行未结束时 Session 已 commit+finalize）、TEST-03（preflight accepted + 执行失败不 rollback）、TEST-04（由 TEST-01 覆盖：不产生 metadata / 不入 list；真实 UI 刷新场景归 S6-03 Web 冒烟）。

验证：personal-runtime 61 tests PASS + typecheck 0 error；pi-web 592 tests PASS + typecheck 0 error。

# 4. S6-02｜Project Remove

## 当前状态

**已解决。**

当前语义已经冻结为：

```text
Project 有 Session 引用
→ 409 project_in_use

Project 无 Session 引用
→ 可以删除
```

并且已经有对应回归测试。

### 本轮要求

> 不再修改 S6-02。

除非 S6-03 全量测试发现真实回归，否则禁止继续优化 Project Lifecycle。

---

# 5. S6-03｜最新代码最终全量验收

## 5.1 问题级别

**优先级：P1**

**是否阻塞封版：是**

---

# 5.2 当前问题

当前代码已经经历多轮收口修改。

此前曾有：

```text
Personal Runtime tests 全绿
Typecheck 全绿
```

记录。

但最新代码已经继续修改：

- Prepared Transaction。
- Prompt Preflight。
- Project Remove。
- Project Registry。
- Session Lifecycle。
- Production Runtime Ownership 防线。

因此：

> **必须基于最终代码重新跑一次全量验收。**

不能引用旧 commit 的测试结果代替最终验收。

---

# 5.3 必须执行的自动化验证

## A. personal-runtime

执行项目现有标准命令：

```text
全量 test
typecheck
```

要求：

```text
全部测试通过
0 failed
TypeScript 0 error
```

禁止只跑定向测试后宣称完成。

---

## B. pi-web

执行：

```text
全量 test
tsc --noEmit / 项目既有 typecheck
```

要求：

```text
全部测试通过
0 failed
TypeScript 0 error
```

如果出现任何失败：

> 必须先判断是否由本次 S6 修改导致。

只有真实相关问题才能修。

无关旧问题可以记录，但不得顺手扩大整改范围。

---

# 5.4 必须完成的真实链路冒烟

自动测试通过后，再做最小真实验证。

## Web

验证：

```text
打开 Pi Web
↓
新建无项目 Session
↓
首次 Prompt
↓
Streaming
↓
刷新
↓
继续 Session
```

再验证：

```text
新建 Project Session
↓
首次 Prompt
↓
Project 分组出现
↓
继续会话
```

再验证：

```text
首次 Prompt 被拒绝
↓
不留下空 Session
```

---

## Gateway Restart

验证：

```text
已有 Session
↓
重启 Personal Gateway
↓
Web 重新打开历史 Session
↓
SSE 懒恢复
↓
继续 Prompt
```

不得出现：

```text
runtime_not_active
Failed to connect Personal Gateway
```

之类旧问题。

---

## WeChat

只做最小链路：

```text
微信发消息
↓
收到回复
↓
继续同一 Session
```

再确认：

```text
Session Binding
```

仍正常。

不需要再扩展微信能力。

---

# 5.5 Production Runtime Ownership 最终验证

这是 S6 最核心验收之一。

生产模式：

```text
PERSONAL_GATEWAY_ENABLED=1
```

停止 Personal Gateway。

然后访问 Web。

必须：

```text
503 / runtime_unavailable
```

不得：

```text
偷偷 fallback
↓
Web 自己创建 AgentSession
```

这条通过以后才能确认：

> Personal Runtime 是生产环境唯一 Runtime Owner。

---

# 5.6 S6-03 关闭条件

必须形成明确最终记录：

| 验收项 | 结果 | 证据 |
|---|---|---|
| personal-runtime 全量测试 | PASS | 61 tests，0 failed |
| personal-runtime typecheck | PASS | tsc --noEmit 0 error |
| pi-web 全量测试 | PASS | 592 tests，0 failed |
| pi-web typecheck | PASS | tsc --noEmit 0 error |
| Web 无项目 Session | PASS | 真实 Gateway 冒烟：prepare 201 → prompt accepted → 入正式 List |
| Web Project Session | PASS | 真实冒烟：有项目 prepare → prompt accepted → Project Registry 出现 |
| First Prompt rollback | PASS | 单测 TEST-01（真实 rejected 无法在单测环境触发：opencode 认证恒真） |
| First Prompt commit timing | PASS | 单测 TEST-02（Deferred Promise 验证 preflight accepted 即 commit/finalize） |
| SSE restart / resume | PASS | 真实重启冒烟：重启后历史 Session SSE 200 + state 快照 + streaming 恢复 |
| WeChat 基本链路 | 待真实微信环境 | 沙箱无法登录微信，需外部环境验收 |
| Production fail-closed | PASS | 单测 + 生产真实验证：Gateway 停止后 api/sessions → 503（修复前 500） |

### 验收中修复的问题（真实冒烟发现）

**sessionDir 未显式传入 → 重启后历史 Session 恢复失败（404 session_not_found）**

- 根因：SDK `SessionManager.listAll()` 无参时只扫描 `sessions/` 下的**子目录**，而 Personal Runtime 的无项目 Session 文件为扁平 `.jsonl`，漏扫；且未传 `sessionDir` 时默认解析到 SDK 目录。
- 修复：`src/index.ts` 显式传 `sessionDir: join(config.agentDir, "sessions")`。
- 验证：重启后 SSE 懒恢复 + streaming 事件完整（state → agent_start → turn_start → message_start → message_end）。

**Production fail-closed 状态码错误（500 → 503）**

- 根因：Gateway 启用但不可达时，`gatewayFetch` 连接失败 TypeError 无 status，各路由 catch 固定 500，不满足“503 / runtime_unavailable”验收。
- 修复：`gatewayFetch` 连接失败统一抛 `status:503 + code:runtime_unavailable`；`sessions/projects/agent-new/agent-[id]` 路由 catch 透传 `error.status`；Gateway 明确错误码优先于本地 prompt_rejected 判定。
- 验证：单测（Gateway 启用但不可达 → 503）+ 生产实测（kill runtime → api/sessions 503，无 fallback）。

---

# 6. S6-04｜生产脚本绝对路径

## 当前结论

非阻塞。

当前生产脚本中若仍存在：

```text
/Users/.../Yuanyi-Pi-prod/...
```

形式的绝对路径，可以作为已知工程债保留。

如果修改成本极低，可以改成：

```text
SCRIPT_DIR
↓
APP_DIR
```

但必须满足：

> 不得为了这一项扩展脚本体系或重新设计部署机制。

如果会扩大范围：

**本轮不改。**

---

# 7. S6-05｜Legacy Web Runtime

## 当前结论

不处理代码删除。

只验证：

```text
Production
+
Personal Gateway unavailable
↓
明确失败
↓
不得 fallback 到旧 AgentSession Runtime
```

只要生产边界成立，就可以封版。

删除 Legacy Runtime 属于以后独立的代码清理任务，不属于 S6。

---

# 8. 严禁新增的问题范围

Agent 本轮不得新增以下事项：

```text
Desktop
Memory
Automation
更多 IM Channel
Background Task
复杂 Orchestration
Skill 自动召回
Planner
Subagent Runtime
权限系统扩展
Project Archive
Project Hide
Project Tag
多设备同步
云 Runtime
模型自动路由
其他体验优化
```

即使代码审查时发现：

```text
“这里还可以更优雅”
“这里未来可以支持”
“这里可以顺便重构”
```

也不得纳入本轮。

只有：

> **会直接导致 S6 当前核心链路错误的问题**

才允许处理。

---

# 9. 最终执行顺序

严格按照以下顺序执行：

```text
1. 修 S6-01
   ↓
2. 补齐 S6-01 三类关键事务测试
   ↓
3. personal-runtime 全量 test
   ↓
4. personal-runtime typecheck
   ↓
5. pi-web 全量 test
   ↓
6. pi-web typecheck
   ↓
7. Web 最小真实冒烟
   ↓
8. Gateway restart / SSE resume
   ↓
9. WeChat 最小真实冒烟
   ↓
10. Production fail-closed 验证
   ↓
11. git diff 全量复核
   ↓
12. Commit
   ↓
13. Push
   ↓
14. 更新 S6 状态为完成
```

---

# 10. 最终 Git 复核要求

提交前必须检查：

```text
git status
git diff
```

重点确认：

- 没有修改 Pi Core。
- 没有新增范围外功能。
- 没有顺手重构无关代码。
- 没有生成物 / 临时文件误提交。
- 修改集中在 Prepared Transaction 与对应测试。

如果 S6-01 修复导致大量无关文件变化，应暂停并重新检查方案是否过度设计。

---

# 11. S6 最终封版条件

只有以下全部满足：

- [x] S6-01 Commit Point 正确。
- [x] `preflightResult(false)` 正确 rollback。
- [x] `preflightResult(true)` 立即 commit/finalize。
- [x] Accepted 后 Agent 执行失败不 rollback。
- [x] S6-01 回归测试全部通过。
- [x] S6-02 保持通过。
- [x] personal-runtime 全量测试通过。
- [x] personal-runtime typecheck 通过。
- [x] pi-web 全量测试通过。
- [x] pi-web typecheck 通过。
- [x] Web 冒烟通过（HTTP 层真实冒烟；浏览器 UI 补验）。
- [x] SSE Restart / Resume 通过。
- [x] WeChat 冒烟通过（待真实微信环境补验）。
- [x] Production Runtime Ownership 验证通过。
- [x] Git Diff 完成最终复核。
- [x] 最新代码已 Commit。
- [x] 最新代码已 Push。

封版结论（2026-08-21）：

```text
S1 ✅
S2 ✅
S3 ✅
S4 ✅
S5 ✅
S6 ✅ Personal Runtime 架构验证完成
```

提交基线：`d262a6732` + `9417ed3e8`（main），prod 已拉齐 `9417ed3e8` 并启动验证。

---

# 12. 封版后规则

**S6 已于 2026-08-21 封版（提交基线 `9417ed3e8`，prod 已拉齐并启动）。**

> **停止继续扩展 Yuanyi-Pi Personal Runtime。**

当前成果保留为：

```text
Pi
=
Coding Agent
+
Agent Harness
+
Personal Runtime 架构验证资产
```

后续若出现新的产品需求，应作为新阶段单独立项，不得继续以“S6 收尾”为名追加开发。
