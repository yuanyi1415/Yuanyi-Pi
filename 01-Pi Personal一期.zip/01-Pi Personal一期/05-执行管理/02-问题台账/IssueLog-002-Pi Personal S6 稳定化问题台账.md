# 002-Pi Personal S6 稳定化问题台账

> **文档编号**：002
> **阶段**：Pi Personal 一期 / S6 Runtime 稳定化收口
> **基线**：2026-08-20 Yuanyi-Pi-dev S6 开发完成版代码审查
> **用途**：作为本轮 S6 二次修复、验收与发布的唯一问题台账
> **状态**：待实施
> **适用代码**：Yuanyi-Pi-dev
> **发布目标**：全部通过后推送自有 Git，再同步 Yuanyi-Pi-prod

------

# 一、文档本体

## 1.1 本轮目标

S6 当前不是继续扩展产品功能，而是将一期已经具备的能力从：

```text
功能可用
```

收口为：

```text
Runtime 唯一
生命周期稳定
Session 语义正确
Web / 微信连续
Streaming 无明显额外损耗
可长期运行
```

本轮只处理代码审查确认的问题。

以下内容不进入本轮：

- Memory
- Scheduler 产品化
- Desktop
- Subagent
- Capability Router
- 新 IM Channel
- 通用插件平台
- 其他非 S6 产品功能

------

## 1.2 已冻结的核心事实

### Runtime Ownership

```text
Web / WeChat
      ↓
Personal Gateway
      ↓
Session Router
      ↓
Runtime Manager
      ↓
PiRuntimeAdapter
      ↓
AgentSession
```

Personal Runtime 是活跃 AgentSession 的唯一 Runtime Owner。

Pi Web 不得创建第二套 AgentSession。

------

### Session 产品语义

Session 分为两种产品形态：

```text
Session
├── 话题
└── 项目 Session
```

#### 话题

用户新建会话时**未选择项目**：

```text
projectDirectory = null
runtimeCwd       = 独立 Session Workspace
```

Web 产品名称统一使用：

> **话题**

不得再显示：

> 无项目会话

------

#### 项目 Session

用户选择真实本地目录：

```text
projectDirectory = 真实项目目录
runtimeCwd       = 真实项目目录
```

Web 按真实项目目录进行分组。

------

### Workspace 原则

`runtimeCwd` 是 Agent 的运行工作目录。

`projectDirectory` 是用户项目语义。

两者不能混为一个概念。

判断是否属于项目只允许依据：

```ts
session.projectDirectory !== null
```

不得根据 `runtimeCwd` 判断。

------

## 1.3 dev / prod 生命周期边界

Personal Gateway / Personal Runtime 的进程治理必须区分环境。

### Yuanyi-Pi-dev

开发环境：

```text
不默认后台常驻
不默认 launchd 自动启动
由开发者按需启动 / 停止 / 重启
```

目的是：

- 方便开发调试；
- 避免后台残留进程；
- 避免端口被旧 Runtime 占用；
- 可以明确控制当前测试实例。

但必须保证：

> 同一 dev 环境不得同时存在两套 Runtime Owner。

Web 也不得自行启动第二套 Runtime。

------

### Yuanyi-Pi-prod

生产环境：

```text
launchd
↓
Personal Runtime / Gateway
```

由系统级 Supervisor 负责：

- 默认后台常驻；
- 自动启动；
- 崩溃恢复；
- 单实例；
- Health；
- 日志与生命周期管理。

Web 不是 Lifecycle Owner。

------

# 二、问题总台账

已确认以下两项达到代码层关闭条件：

| 原 Issue | 内容        | 状态     |
| -------- | ----------- | -------- |
| ISS-202  | Prompt 串行 | ✅ 已通过 |
| ISS-203  | Idle 回收   | ✅ 已通过 |

当前剩余问题：

| 编号  | 问题                                            | 优先级 | 阻塞 S6 |
| ----- | ----------------------------------------------- | ------ | ------- |
| S6-01 | “话题”及 Projectless Workspace 尚未完成产品闭环 | P0     | 是      |
| S6-02 | Runtime 生命周期没有正确区分 dev / prod         | P0     | 是      |
| S6-03 | Web 重连不能可靠恢复正在运行的 Agent 状态       | P0     | 是      |
| S6-04 | Gateway / Legacy Runtime 的运行模式约束不够明确 | P0     | 是      |
| S6-05 | Streaming 性能基线尚未完成                      | P0     | 是      |
| S6-06 | 删除 Session 后可能残留微信 Channel Binding     | P1     | 是      |
| S6-07 | Gateway 化造成 Session 读取与自动命名能力回归   | P1     | 是      |

------

# 三、S6-01 话题 / Projectless Workspace

## 3.1 当前问题

当前 Runtime 已能表达：

```text
projectDirectory = null
```

但 Web 主界面仍存在：

```tsx
disabled={!selectedCwd}
```

导致：

> 用户不选择项目就不能点击“新建会话”。

同时当前 `neutralCwd` 仍偏向技术兜底目录，没有形成正式的 Session Workspace。

------

## 3.2 最终产品设计

Web 点击：

```text
+ 新建会话
```

**永远允许创建。**

创建时：

### 未选择项目

创建：

> **话题**

内部数据：

```text
projectDirectory = null
runtimeCwd       = 自动生成的独立 Session Workspace
```

### 已选择项目

创建项目 Session：

```text
projectDirectory = selectedProjectDirectory
runtimeCwd       = selectedProjectDirectory
```

------

## 3.3 Projectless Workspace 设计

建议设置默认工作区根：

```text
~/.yuanyi-pi/workspaces/
```

每个话题独立一个目录：

```text
~/.yuanyi-pi/workspaces/
├── <session-id-A>/
├── <session-id-B>/
└── <session-id-C>/
```

禁止所有话题共用一个目录。

原因：

- 文件天然隔离；
- Agent 不会读到其他话题的临时产物；
- 后续产物管理更清晰；
- 更接近 Codex Projectless Workspace 行为。

------

## 3.4 后端修改建议

配置：

```ts
interface RuntimeConfig {
  defaultWorkspaceRoot: string;
}
```

创建 Workspace：

```ts
import path from "node:path";
import fs from "node:fs/promises";

async function createSessionWorkspace(sessionId: string) {
  const runtimeCwd = path.join(
    config.defaultWorkspaceRoot,
    sessionId
  );

  await fs.mkdir(runtimeCwd, {
    recursive: true
  });

  return runtimeCwd;
}
```

创建 Session：

```ts
const runtimeCwd = projectDirectory
  ? projectDirectory
  : await createSessionWorkspace(sessionId);

const session = {
  id: sessionId,
  projectDirectory: projectDirectory ?? null,
  runtimeCwd
};
```

------

## 3.5 Web 前端改造

### 新建按钮

当前逻辑：

```tsx
<Button
  disabled={!selectedCwd}
  onClick={handleNewSession}
>
  新建会话
</Button>
```

修改为：

```tsx
<Button onClick={handleNewSession}>
  新建会话
</Button>
```

创建请求：

```tsx
const handleNewSession = () => {
  onNewSession?.({
    projectDirectory: selectedCwd ?? null
  });
};
```

------

### 左侧导航展示

推荐：

```text
话题
├── 帮我整理今天的工作
├── 分析这个 Excel
└── 写一篇文章

Yuanyi-Pi-dev
├── 检查 RuntimeManager
└── 修复 Gateway

公司AI平台
├── Agent 架构设计
└── 数据建模 Skill
```

系统内部路径：

```text
~/.yuanyi-pi/workspaces/<session-id>
```

不得出现在项目分组中。

------

### UI 规则

```text
projectDirectory == null
→ 分入“话题”

projectDirectory != null
→ 按真实项目目录分组
```

禁止：

```text
runtimeCwd
→ 推断项目名称
```

------

## 3.6 Workspace 删除规则

S6 暂定：

```text
删除 Session
→ 删除 Session 元数据
→ 不自动删除 Workspace
```

原因：

Workspace 可能已经存在用户生成文件。

是否删除工作区以后作为独立产品能力设计，本轮不扩展。

------

## 3.7 验收标准

-  不选择项目也可以点击“新建会话”
-  Web 名称统一显示“话题”
-  不再出现“无项目会话”
-  话题 `projectDirectory === null`
-  自动生成独立 `runtimeCwd`
-  不同话题拥有不同 Workspace
-  Workspace 不显示成项目
-  Agent Shell / Tool 在该 Workspace 中正常运行
-  选择真实项目时行为保持不变

------

# 四、S6-02 Runtime 生命周期治理

## 4.1 当前问题

当前代码同时存在：

```text
launchd plist
```

以及：

```bash
nohup npm start &
PID_FILE
kill <pid>
```

如果不区分环境，很容易再次形成多个 Lifecycle Owner。

------

## 4.2 最终设计

生命周期治理必须明确区分：

```text
dev
≠
prod
```

------

## 4.3 dev 环境

Yuanyi-Pi-dev：

```text
开发者
↓
显式 start / stop / restart
↓
唯一 dev Personal Runtime
```

dev：

- 不设置 `RunAtLoad`；
- 不要求 `KeepAlive`；
- 不默认后台自动启动；
- 不由 Web 拉起 Runtime；
- 不允许存在旧进程和新进程同时运行。

可以保留开发脚本：

```bash
personal-runtime.sh start
personal-runtime.sh stop
personal-runtime.sh restart
personal-runtime.sh status
```

但它只服务于 dev 手工生命周期。

必须可靠避免：

```text
第一次启动未停止
+
第二次再启动
→ EADDRINUSE
```

------

## 4.4 prod 环境

Yuanyi-Pi-prod：

```text
launchd
↓
唯一 Runtime 实例
```

生产环境必须：

- launchd 托管；
- 自动启动；
- KeepAlive；
- 崩溃恢复；
- 单实例；
- Health；
- Web 不管理生命周期。

生产环境不再依赖：

```text
nohup
PID_FILE
人工 kill
```

作为正式进程治理方案。

------

## 4.5 Web 统一约束

无论 dev / prod：

```text
Pi Web
不得 start Runtime
不得 stop Runtime
不得 restart Runtime
```

只允许：

```text
Health Check
+
连接 Gateway
```

Runtime 不可用：

```text
Web
↓
明确提示 Runtime unavailable
```

禁止 Web 偷偷创建第二套 Runtime。

------

## 4.6 验收标准

### dev

-  Gateway 不默认后台启动
-  Runtime 可手动 start / stop / restart
-  同时只有一个实例
-  Web 不负责启动 Runtime
-  重复启动不会残留多个 Runtime

### prod

-  launchd 是唯一 Lifecycle Owner
-  默认后台常驻
-  自动启动
-  Runtime 崩溃自动恢复
-  单实例
-  Web 关闭不影响 Runtime
-  微信在 Web 关闭期间继续在线

------

# 五、S6-03 Web 重连恢复 Agent Run

## 5.1 当前问题

Personal Gateway 已能读取：

```ts
{
  isStreaming,
  isIdle
}
```

但 Web Gateway SSE 建连时仍可能硬编码：

```ts
{
  type: "connected",
  isStreaming: false
}
```

导致：

```text
Agent 正在运行
↓
关闭 Web
↓
重新打开 Web
↓
前端误认为 Agent 已停止
```

后续 Streaming Event 也可能被忽略。

------

## 5.2 修改方案

SSE 建连时必须返回真实 Runtime 状态：

```ts
{
  type: "connected",
  sessionId,
  isStreaming: state.isStreaming
}
```

如果当前正在 Streaming：

```ts
if (state.isStreaming && state.streamingMessage) {
  send({
    type: "message_start",
    message: state.streamingMessage
  });
}
```

之后继续：

```text
message_update
tool_event
agent_event
...
```

------

## 5.3 前端状态恢复

```ts
case "connected":
  agentRunningRef.current = event.isStreaming === true;
  setIsStreaming(event.isStreaming === true);
  break;
```

收到正在运行的消息：

```ts
case "message_start":
  agentRunningRef.current = true;
  setIsStreaming(true);
  break;
```

------

## 5.4 验收

真实测试：

```text
1. Web 发起 30 秒以上任务
2. Agent 开始运行
3. 关闭 Web
4. Agent 继续运行
5. 重新打开 Web
6. 回到原 Session
7. 正确显示运行中
8. 继续收到输出
9. 最终正常结束
```

------

# 六、S6-04 Gateway / Legacy Runtime 模式约束

## 6.1 当前问题

当前 Gateway 模式依赖环境变量。

如果配置缺失，Pi Web 可能重新进入：

```text
rpc-manager
→ AgentSession
```

形成第二 Runtime Owner。

------

## 6.2 核心原则

需要区分：

> **Gateway 是否后台常驻**

和：

> **Pi Web 是否允许创建 Legacy Runtime**

这不是一个问题。

dev 可以不默认启动 Gateway。

但是：

> Gateway 没启动 ≠ Web 可以自动启动 Legacy Runtime。

------

## 6.3 dev 规则

默认：

```text
Gateway 未启动
↓
Web 显示 Runtime unavailable
```

开发者需要测试 Legacy Runtime 时，必须显式打开开发开关，例如：

```text
ALLOW_LEGACY_RPC_RUNTIME=1
```

只有该显式模式才能进入旧 Runtime。

------

## 6.4 prod 规则

prod：

```text
Gateway / Runtime
默认由 launchd 常驻
```

禁止：

```text
Legacy Runtime
```

即使 Gateway 临时不可达，也只能：

```text
Runtime unavailable
```

不能 fallback 到 rpc-manager。

------

## 6.5 推荐实现

```ts
function legacyRuntimeEnabled() {
  return (
    process.env.NODE_ENV !== "production" &&
    process.env.ALLOW_LEGACY_RPC_RUNTIME === "1"
  );
}
```

正常路径：

```text
Gateway 可用
→ Gateway

Gateway 不可用
→ Runtime unavailable
```

只有显式 dev：

```text
ALLOW_LEGACY_RPC_RUNTIME=1
→ Legacy 调试路径
```

------

## 6.6 验收标准

-  dev Gateway 不要求默认启动
-  Gateway 未启动不会自动创建第二 Runtime
-  dev 可通过显式开关进入 Legacy 调试模式
-  prod 完全禁止 Legacy fallback
-  Web 不承担 Runtime Ownership

------

# 七、S6-05 Streaming 性能基线

## 7.1 当前问题

当前正式链路：

```text
Browser
→ Pi Web BFF
→ Personal Gateway
→ AgentSession
```

双进程继续保留。

但需要确认 BFF + Gateway 没有引入明显 Streaming 延迟。

------

## 7.2 时间点

```text
T0 = Browser 发出 Prompt
T1 = Gateway 收到 Prompt
T2 = Gateway 收到 Pi 第一条模型输出 Event
T3 = Browser 收到第一条输出 Event
```

------

## 7.3 Request ID

Browser 创建：

```ts
const requestId = crypto.randomUUID();
```

全链路传递：

```http
x-yuanyi-request-id: <uuid>
```

------

## 7.4 指标

入口代理开销：

```text
T1 - T0
```

目标：

```text
P95 ≤ 50ms
```

Streaming 转发开销：

```text
T3 - T2
```

目标：

```text
P95 ≤ 50ms
```

模型 TTFT：

```text
T2 - T1
```

只记录，不作为 Web/Gateway 性能问题。

------

## 7.5 验收

至少：

```text
30 次真实本地 Web 对话
```

输出：

| 指标                    | P50  | P95   |
| ----------------------- | ---- | ----- |
| Browser → Gateway       | 记录 | ≤50ms |
| Gateway Event → Browser | 记录 | ≤50ms |
| Model TTFT              | 记录 | 记录  |

同时确认：

-  不周期性批量吐字
-  无明显 Token 积压
-  长回答持续 Streaming

------

# 八、S6-06 删除 Session 后残留微信 Binding

## 8.1 当前问题

删除 Session 时已执行：

```text
dispose Runtime
删除 Session 文件
删除 Session Metadata
```

但可能没有同步删除：

```text
channelBindings
```

导致微信仍指向已经不存在的 Session。

------

## 8.2 修改方案

新增：

```ts
removeBindingsBySession(sessionId)
```

删除流程：

```text
dispose Runtime
↓
清理所有指向该 Session 的 Channel Binding
↓
删除 Session Metadata
↓
删除 Session 文件
```

------

## 8.3 后续微信行为

如果原 Session 已删除：

```text
用户下一次发送微信
↓
找不到 Binding
↓
按 Channel 默认规则重新创建 / 绑定 Session
```

禁止：

```text
session not found
```

直接导致渠道失败。

------

## 8.4 验收标准

-  Web 删除微信当前绑定 Session
-  Binding 同时清理
-  微信下一条消息仍正常
-  不影响其他联系人
-  不出现悬空 Session ID

------

# 九、S6-07 Gateway 化能力回归

本项包含两个子问题。

------

## 9.1 Session Context defer 能力

原 Web 支持：

```text
deferThinking
deferMedia
```

避免长 Session 首屏加载大量：

- thinking；
- base64 图片；
- tool result media。

Gateway 化后需要保证这些语义继续生效。

推荐：

```text
Session History / Context
→ 共享纯读取模块
```

该模块：

```text
不创建 AgentSession
不修改 Runtime
不取得 Runtime Ownership
```

恢复：

```text
deferThinking
deferMedia
leaf projection
```

------

## 9.2 Session 自动命名

原能力：

```text
generateSessionTitle()
```

属于 AI 自动命名。

不能因为 Web 不再创建 AgentSession 就退化为：

```ts
firstUserMessage.slice(0, 80)
```

------

### 推荐修改

由 Personal Runtime 或独立模型调用完成：

```http
POST /sessions/:id/title/generate
```

流程：

```text
用户首次提问
↓
临时标题
↓
生成 Session Title
↓
更新 Metadata
↓
Web 自动刷新左侧标题
```

该调用：

```text
不创建第二 AgentSession
不成为 Runtime Owner
```

------

# 十、已通过项冻结

## 10.1 Prompt 串行

保持：

```text
普通 Prompt
→ RuntimeManager.prompt()
→ 同 Session 串行队列
```

禁止增加旁路。

------

## 10.2 Idle 回收

保持：

```text
真实 isStreaming
+
真实 isIdle
+
Runtime Event touch
+
idleTimeout
```

禁止重新退化到只依赖：

```text
lastActiveAt
```

------

# 十一、实施顺序

建议 Codex 严格按照以下顺序修复。

## 第一组：Runtime 边界

```text
S6-02 Runtime 生命周期
S6-04 Gateway / Legacy 模式
```

目标：

> 先确保 Runtime Ownership 和生命周期不存在歧义。

------

## 第二组：Session 本体

```text
S6-01 话题 / Projectless Workspace
S6-06 Channel Binding
```

目标：

> 确保 Session 创建、目录、渠道绑定语义正确。

------

## 第三组：Web 连续性与能力回归

```text
S6-03 Web Streaming Reconnect
S6-07 Context / Auto-name
```

------

## 第四组：最终性能验证

```text
S6-05 Streaming Performance
```

性能必须最后测。

否则前面的 Runtime / Web 修改会导致性能结果失效。

------

# 十二、S6 Exit Gate

## 12.1 Runtime

-  Personal Runtime 是唯一 AgentSession Runtime Owner
-  Web 不控制 Runtime 生命周期
-  dev Gateway 按需手工启动
-  dev 不存在多个 Runtime 实例
-  prod 由 launchd 唯一托管
-  prod 默认后台常驻
-  prod 禁止 Legacy fallback
-  Prompt 串行通过
-  Idle 回收通过

------

## 12.2 Session

-  不选择项目可以直接创建 Session
-  产品统一称为“话题”
-  话题 `projectDirectory=null`
-  每个话题拥有独立 Session Workspace
-  runtimeCwd 不作为项目展示
-  项目 Session 仍使用真实项目目录
-  删除 Session 同步清理 Channel Binding

------

## 12.3 Web / 微信

-  Web 重启不终止 Agent Run
-  Web 重连可恢复 Streaming 状态
-  微信在 Web 关闭期间继续工作
-  Web ↔ 微信继续共享统一 Session
-  Session History 长会话无明显读取回归
-  AI Auto-name 能力无降级

------

## 12.4 性能

-  完成至少 30 次样本
-  Browser → Gateway P95 ≤ 50ms
-  Gateway Event → Browser P95 ≤ 50ms
-  Streaming 无明显积压

------

# 十三、发布流程

S6 Exit Gate 全部通过后：

```text
Yuanyi-Pi-dev
↓
自动化测试
↓
真实运行验收
↓
代码复审
↓
Git Commit / Push
↓
形成稳定版本
↓
Yuanyi-Pi-prod 拉取稳定版本
↓
配置 prod launchd
↓
prod 实机复验
↓
形成新的生产基线
```

在上述流程完成前：

> **不得宣称 S6 正式完成，也不得进入下一阶段能力建设。**

------

# 十四、本次版本变更

相较上一版问题台账，本版冻结以下调整：

1. 产品术语由“无项目会话”统一调整为 **“话题”**。
2. 话题正式采用 Codex 式 **Projectless Workspace**。
3. 每个话题拥有独立 `runtimeCwd`，但 `projectDirectory=null`。
4. Workspace 永远不能作为项目展示。
5. Runtime 生命周期正式区分 **dev / prod**。
6. dev 不默认由 launchd 后台常驻。
7. prod 才由 launchd 作为唯一 Lifecycle Owner。
8. Gateway 未启动不等于允许 Web 自动 fallback 到 Legacy Runtime。
9. S6-02、S6-04 与 Exit Gate 已按新的环境边界重新定义。