---
type: IssueLog
status: 草稿
version: v1.0
depends_on: 基准事实-v1.2; AnalysisReport-001-v1.0; PRD-002-v1.0
owner: 缘一
created: 2026-08-20
updated: 2026-08-20
---

# IssueLog-001：Runtime 稳定化问题台账

## 问题台账

| 问题 ID | 描述 | 根因 | 修复状态 | 验证状态 | 负责人 |
|---|---|---|---|---|---|
| ISS-201 | Gateway 模式下 Web 仍残留活 Runtime 路径 | 第一轮迁移保留 legacy / rpc-manager，未做最终 Ownership 清场 | 未开始 | 已通过源码确认 | Agent |
| ISS-202 | 普通 Prompt 绕过 RuntimeManager 串行队列 | Gateway Command 统一走 sendCommand | 未开始 | 已通过源码确认 | Agent |
| ISS-203 | Idle 回收可能误杀长任务 | scanIdle 未查询真实 isStreaming / isIdle | 未开始 | 已通过源码确认 | Agent |
| ISS-204 | 无项目 Session Web 语义不完整 | runtimeCwd 与 projectDirectory 在 Web DTO/UI 混用 | 未开始 | 已通过源码确认 | Agent |
| ISS-205 | Gateway 生命周期存在多个启动者 | Web 联动、手工脚本和后台进程职责重叠 | 未开始 | 已发生 EADDRINUSE | Agent |
| ISS-206 | Web Streaming 额外延迟无量化基线 | 当前无 T0–T3 链路性能指标 | 未开始 | 未验证 | Agent |
| ISS-207 | 自有 pi/ 尚未成为 Web / Runtime 实际运行依赖 | package.json 仍使用官方 npm 0.84.2 | 延后 | 已通过源码确认 | Agent |
| ISS-208 | 微信长期在线稳定性仍需持续观察 | Transport 已实现，但长期运行数据尚未成为正式质量基线 | 持续观察 | 未完成 | Agent |

## 当前优先级

### P0：本轮必须关闭

- ISS-201
- ISS-202
- ISS-203
- ISS-204
- ISS-205

### P1：本轮必须建立质量基线

- ISS-206

### 非本轮阻塞

- ISS-207：首次发布自有 Pi Core 修改前必须关闭。
- ISS-208：持续运行观察，不阻塞 Runtime 稳定化收口。
