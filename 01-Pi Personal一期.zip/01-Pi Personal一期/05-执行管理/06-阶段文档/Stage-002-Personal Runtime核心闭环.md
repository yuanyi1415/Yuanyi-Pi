---
type: Stage
status: 草稿
version: v1.0
depends_on: 基准事实-v1.1; PRD-001-v1.0; 架构设计-001-v1.0; 技术设计-001-v1.0
owner: 缘一
created: 2026-08-20
updated: 2026-08-20
---

# Stage-002：Personal Runtime 核心闭环

## 目标

在不依赖 Pi Web 的情况下，完成 Personal Gateway → Runtime Manager → PiRuntimeAdapter → AgentSession 的最小可运行闭环。

## 范围

- personal-runtime 骨架
- PiRuntimeAdapter
- RuntimeManager
- Session Router
- MetadataStore
- HTTP Session API
- SSE Event
- Session 创建 / 恢复 / Prompt / Abort / 模型切换

## 出口标准

- 测试客户端可完整使用 Gateway 创建和继续 Session
- Runtime 释放后可恢复
- 无项目与真实目录会话均正确运行
- Session 级模型切换正常
- WBS DEV200 / DEV220 / TST200 全部通过

## 总结

阶段完成后补充。
