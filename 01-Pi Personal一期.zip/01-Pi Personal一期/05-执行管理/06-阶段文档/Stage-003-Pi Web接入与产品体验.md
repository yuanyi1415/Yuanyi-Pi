---
type: Stage
status: 草稿
version: v1.0
depends_on: 基准事实-v1.1; PRD-001-v1.0; 架构设计-001-v1.0; 技术设计-001-v1.0
owner: 缘一
created: 2026-08-20
updated: 2026-08-20
---

# Stage-003：Pi Web 接入与产品体验

## 目标

让 Pi Web 通过 Personal Gateway 使用统一 Runtime，并完成一期必要会话列表与新建会话体验优化。

## 范围

- Pi Web BFF → Personal Gateway
- Runtime Ownership 下沉
- Session / Streaming / Model 兼容
- 无项目会话置顶
- 真实本地目录分组复用与必要 UI 优化

## 出口标准

- Web 不再是长期 AgentSession Owner
- Web 核心聊天体验无明显回归
- 无项目 / 项目目录 / Session 级模型均符合 PRD
- Pi Package / Extension 基础兼容
- WBS DEV300 / DEV320 / TST300 全部通过

## 总结

阶段完成后补充。

---

## 附录：rpc-manager Command / Event 行为基线（DEV311）

> Web 回归对照基线，改造前后必须保持的行为。基于 `pi-web/lib/rpc-manager.ts`（v0.8.9，基线 2a6e537）。

### 1. 命令面（sendCommand，26 个）

`prompt / abort / get_state / set_model / fork / navigate_tree / set_thinking_level / compact / set_session_name / get_session_stats / get_last_assistant_text / set_auto_compaction / clear_queue / steer / follow_up / get_tools / get_commands / set_tools / reload / abort_compaction / extension_ui_response / extension_ui_input / set_auto_retry / bash / abort_bash / abort_compaction`

### 2. Event 结构

- `AgentEvent = { type: string; [key: string]: unknown }`（宽松结构，SSE 透传）
- `AgentSessionWrapper.subscribe` → 转发 AgentSession 事件 + idle 计时器重置
- 关键事件：`agent_end / message_start / message / message_end / prompt_done / prompt_error / session_start / session_shutdown / tool_* / context_* / extension_*`

### 3. Runtime 生命周期

- `startRpcSession(sessionId, sessionFile, cwd, opts)`：sessionFile 存在 → `SessionManager.open` 恢复；否则 `SessionManager.create(cwd)`（**cwd 必传**）
- `createAgentSessionServices({cwd, agentDir, settingsManager, resourceLoaderOptions})` + `createAgentSessionFromServices`
- `globalThis.__piSessions` 全局 Registry（`rpc-manager.ts:1378`）
- 空闲回收：`AgentSessionWrapper` idleTimer，约 10 分钟（IDLE_RESET_EVENT_TYPES 重置）
- 启动锁：`locks` Map 合并并发同 key 调用

### 4. Web API 行为

| 路由 | 行为 | 返回值 |
|---|---|---|
| `POST /api/agent/new` | 创建（**cwd 必传且 must exist**）；一次创建可立即发首条命令；`ensure_session` 仅建 runtime | `{success, sessionId, data, model, thinkingLevel}` |
| `POST /api/agent/[id]` | 已运行→直接 send；否则 resolveSessionPath→startRpcSession→send | `{success, data}` / `{error, code:prompt_rejected, accepted:false}` |
| `GET /api/agent/[id]` | 运行中→get_state；否则 `{running:false}` | `{running, state}` |
| `GET /api/agent/[id]/events` | SSE；未运行→resolveSessionPath→startRpcSession | SSE 流 |
| `GET /api/sessions` | session-reader：Pi listAll + running 合并 + project info | 列表 |

### 5. 前端调用链

`hooks/useAgentSession.ts` → `lib/agent-client.ts` `sendAgentCommand(sessionId, cmd)` → `POST /api/agent/[id]`；SSE 走 `/api/agent/[id]/events`；列表走 `/api/sessions`。
