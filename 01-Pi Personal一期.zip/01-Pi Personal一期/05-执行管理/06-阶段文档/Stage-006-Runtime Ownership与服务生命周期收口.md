---
type: Stage
status: 草稿
version: v1.0
depends_on: 基准事实-v1.2; PRD-002-v1.0; WBS-002-v1.0
owner: 缘一
created: 2026-08-20
updated: 2026-08-20
---

# Stage-006：Runtime Ownership 与服务生命周期收口

## 目标

把已经完成的一期 Personal Agent 主链从“功能可用”收口到“长期稳定运行”。

本阶段不新增业务能力，重点解决：

- 唯一 Runtime Ownership；
- Gateway 常驻生命周期；
- Prompt / Idle 正确性；
- 无项目 Session Web 语义；
- Web Streaming 性能基线。

## 范围

包含：

- WBS-002 全部任务；
- IssueLog-001 中 ISS-201 ～ ISS-206；
- 双进程生命周期落地；
- Web / Gateway 性能测量；
- PRD-001 已完成能力回归。

不包含：

- Memory；
- Scheduler 产品化；
- Desktop；
- Subagent；
- 新 Channel；
- 自有 Pi Core 运行依赖切换（除非本阶段实际修改 Pi Core）。

## 出口标准

必须同时满足：

1. Web 不再持有 Gateway 模式 Agent Runtime；
2. Personal Runtime 由系统级服务独立常驻；
3. Web 关闭 / 重启不影响微信和 Agent Run；
4. 同 Session 普通 Prompt 串行；
5. 长任务不被 Idle 回收；
6. 无项目 Session Web 体验正确；
7. Web/BFF → Gateway P95 ≤ 50 ms；
8. Gateway Event → Browser P95 ≤ 50 ms；
9. 一期核心能力回归通过；
10. 形成可进入长期日常使用的新稳定基线。

## 总结

待阶段完成后填写。
