---
type: Stage
status: 草稿
version: v1.0
depends_on: 基准事实-v1.1; PRD-001-v1.0; 架构设计-001-v1.0; 技术设计-001-v1.0
owner: 缘一
created: 2026-08-20
updated: 2026-08-20
---

# Stage-004：微信私聊接入

## 目标

完成微信私聊文本的接收、回复、主动发送和统一 Session Binding，并以真实 PoC 结果冻结 Transport。

## 范围

- 微信 Transport PoC
- License / 账号风险核对
- WeChatChannelAdapter
- 联系人身份与授权
- activeSessionId Binding
- 新会话 / 查看 / 切换会话最小交互

不包含群聊、图片、文件、语音和富媒体。

## 出口标准

- 微信可创建和继续统一 Session
- 可主动发送文本
- 掉线不影响 Web，恢复后 Binding 可继续
- Transport 有真实验证结论
- WBS POC400 / DEV400 / TST400 全部通过

## 总结

阶段完成后补充。
