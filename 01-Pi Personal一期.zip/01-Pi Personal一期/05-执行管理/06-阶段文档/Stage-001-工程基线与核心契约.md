---
type: Stage
status: 草稿
version: v1.0
depends_on: 基准事实-v1.1; PRD-001-v1.0; 架构设计-001-v1.0; 技术设计-001-v1.0
owner: 缘一
created: 2026-08-20
updated: 2026-08-20
---

# Stage-001：工程基线与核心契约

## 目标

确认 Yuanyi-Pi 的代码、运行和回归基线，冻结一期 Session / Runtime / Gateway Event / Channel 四类核心契约。

## 范围

- 三库与自有 Git 关系核对
- 当前 Pi + Pi Web 生产运行零影响验证
- 开发 / 生产运行数据隔离确认
- Session / Runtime / Gateway Event / Channel Contract

不进入 Pi Web 正式 Runtime 改造。

## 出口标准

- 工程与运行基线有真实记录
- 未破坏当前 Pi Web 使用
- 四类 Contract 可直接指导实现
- WBS DEV100 / DEV120 全部通过

## 总结

阶段完成后补充。

---

## 附录：核心契约（S1 交付物，DEV122-125）

> 四类 Contract 为一期实现与跨 Channel 共用的最小约束面，版本随 Stage-001 走。实现时以本节为准，细化为代码后可对照。

### C-1 Session Contract（DEV122）

Session 是一级运行对象，以 **Pi Session ID 为统一主身份**（架构设计 AD-003），不引入 Personal Session ID 双主键。

```ts
interface SessionDescriptor {
  sessionId: string;                    // Pi Session ID，唯一主身份
  title?: string;                       // 标题由 Pi Session 提供
  projectDirectory: string | null;      // 用户语义：真实本地目录；null = 无项目
  runtimeCwd: string;                   // Pi 实际运行目录（见无项目规则）
  originChannel?: "web" | "wechat";    // 创建来源 Channel（Personal 元数据）
  model?: ModelSelection;               // 当前模型选择
  running: boolean;                     // Runtime Manager 瞬时状态
  createdAt?: number;
  updatedAt?: number;
}

interface ModelSelection {
  provider: string;     // Provider ID（由 Pi Provider/Auth 解析 Credential）
  modelId: string;
  presetId?: string;    // 可选产品引用，不承担运行事实
}
```

**无项目与 Runtime cwd 差异（架构设计 AD-005）**：

```text
projectDirectory = null  → runtimeCwd = neutralCwd（安全默认目录，不展示为项目）
projectDirectory = 目录   → runtimeCwd = 目录
```

- `neutralCwd` 独立于真实用户项目目录，不使用用户 Home 作为默认 cwd；
- 数据合并规则：Pi Session 是否存在是第一真实性判断；Personal Metadata 只补充 `projectDirectory / originChannel / modelPresetId`；Metadata 存在但 Pi Session 不存在时标记 orphan，不生成虚假 Session。

### C-2 Runtime Contract（DEV123）

```ts
interface PiRuntimeAdapter {
  readonly sessionId: string;
  getState(): Promise<SessionRuntimeState>;
  prompt(message: string, options?: PromptOptions): Promise<PromptAck>;
  sendCommand(command: SessionCommand): Promise<unknown>;
  subscribe(listener: (event: GatewayEvent) => void): () => void;
  abort(): Promise<void>;
  setModel(model: ModelSelection): Promise<void>;
  setThinkingLevel(level: ThinkingLevel): Promise<void>;
  dispose(): Promise<void>;
}
```

**生命周期**：`starting → ready → busy → (disposing | error)`。

- 同一 `sessionId` 并发启动只产生一个 Runtime（启动锁）；
- 同一 Session 普通 Prompt 默认串行，第二个普通 Prompt 排队或明确拒绝（以 Pi 原生行为验证为准）；
- 空闲回收只释放内存 Runtime，不删除持久 Session（参考 Pi Web 现有约 10 分钟 idle 逻辑）；
- Runtime 重建不改变 `sessionId`；进程重启后按需恢复。

**命令面**（保留 Pi Web 现有能力避免回归）：`prompt / abort / steer / follow_up / set_model / set_thinking_level / set_tools / compact / get_state`，扩展 `get_session_stats / get_last_assistant_text / fork / set_session_name / set_auto_compaction / clear_queue / reload / bash / abort_bash / abort_compaction / extension_ui_response / extension_ui_input`。

### C-3 Gateway Event Contract（DEV124）

SSE Envelope：

```ts
interface GatewayEvent {
  sessionId: string;
  sequence: number;      // 单调递增，Client 去重/排序依据
  type: string;
  timestamp: number;
  payload: unknown;
}
```

**与现有 Pi Web Event 兼容映射**：一期 `payload` 直接承载现有 `AgentEvent`（`{ type: string; [key: string]: unknown }`，见 `pi-web/lib/rpc-manager.ts` `AgentEvent`），先保证迁移完整性，后续逐步收敛稳定公共事件。

- SSE 断线不终止 Runtime；Client 可重新订阅；已落盘消息通过 Session History 补齐；服务端不无限缓存历史 Event。

### C-4 Channel Contract（DEV125）

```ts
interface ChannelAdapter {
  readonly channelType: string;
  start(): Promise<void>;
  stop(): Promise<void>;
  reply(target: ChannelAddress, message: OutboundMessage): Promise<void>;
  send(target: ChannelAddress, message: OutboundMessage): Promise<void>;
}

interface InboundChannelMessage {
  channelType: string;
  accountId: string;
  contactId: string;
  messageId: string;
  text: string;
  receivedAt: number;
}
```

**边界**：

- Channel 不直接 import Pi SDK，入站消息经 Session Router 路由到统一 Session；
- Session Binding：每个授权联系人维护 `activeSessionId`（无绑定+普通消息→自动创建无项目 Session 并绑定；已绑定→继续；新会话→创建并切换；主动发送默认不改变 `activeSessionId`）；
- 未授权联系人默认拒绝进入 Agent Runtime；
- 一期只实现 `wechat` Channel。
