---
type: Stage
status: 草稿
version: v1.0
depends_on: 基准事实-v1.1; PRD-001-v1.0; 架构设计-001-v1.0; 技术设计-001-v1.0
owner: 缘一
created: 2026-08-20
updated: 2026-08-20
---

# Stage-005：跨 Channel 验收与生产发布

## 目标

完成 Web + 微信统一 Session 的一期全量验收，将稳定版本发布到 Yuanyi-Pi-prod。

## 范围

- Web → 微信
- 微信 → Web
- 同 Session 并发保护
- 无项目 / 项目目录 / 模型组合场景
- Pi / Pi Web / Personal Runtime 全量回归
- 稳定分支 / Tag / 生产同步
- 一期交付与验收结论

## 出口标准

- PRD 核心验收场景全部通过
- Pi / Pi Web 无明显功能回归
- Personal Runtime 可稳定重启恢复
- 稳定版本进入 Yuanyi-Pi-prod
- 一期验收结果形成正式记录
- WBS TST500 / REL500 全部通过

## 总结

阶段完成后补充。
