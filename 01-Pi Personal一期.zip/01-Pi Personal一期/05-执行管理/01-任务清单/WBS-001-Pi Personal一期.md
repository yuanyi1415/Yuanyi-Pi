---
type: WBS
status: 草稿
version: v1.0
depends_on: 基准事实-v1.1; PRD-001-v1.0; 架构设计-001-v1.0; 技术设计-001-v1.0
owner: 缘一
created: 2026-08-20
updated: 2026-08-20
---

# WBS-001：Pi Personal 一期

## 任务分解

> 状态统一使用：未开始 / 进行中 / 已完成 / 阻塞。默认实现负责人为 Agent，阶段门控与冻结负责人为缘一。

### 阶段：S1 工程基线与核心契约

#### 包：DEV100（工程基线）

##### 工作包：DEV110 本地工程与运行基线确认

- 任务：DEV111 核对 `pi-upstream / Yuanyi-Pi-dev / Yuanyi-Pi-prod` 三库及自有 Git 关系（状态：未开始，负责人：Agent）
  - 子任务：确认 `Yuanyi-Pi-dev` 同仓包含 `pi/` 与 `pi-web/`（状态：未开始）
  - 子任务：确认当前 Pi Web 生产运行未受工程整理影响（状态：未开始）
  - 子任务：记录开发/生产运行数据目录和端口隔离事实（状态：未开始）
- 任务：DEV112 固定一期源码基线与回归启动方式（状态：未开始，负责人：Agent）
  - 子任务：记录 Yuanyi-Pi 基线 commit（状态：未开始）
  - 子任务：跑通未改造的 Pi + Pi Web 基础会话（状态：未开始）
  - 子任务：记录 Session、模型、Streaming、本地目录相关回归点（状态：未开始）

#### 包：DEV120（契约冻结）

##### 工作包：DEV121 Session / Runtime / Channel 契约

- 任务：DEV122 定义 Session Contract（状态：未开始，负责人：Agent）
  - 子任务：明确 `sessionId / projectDirectory / runtimeCwd / model / originChannel / runtimeState`（状态：未开始）
  - 子任务：明确“无项目”与 Runtime `cwd` 的差异（状态：未开始）
- 任务：DEV123 定义 Runtime Contract（状态：未开始，负责人：Agent）
  - 子任务：冻结 create / resume / prompt / stream / abort / setModel / dispose（状态：未开始）
  - 子任务：明确单 Session 并发与生命周期约束（状态：未开始）
- 任务：DEV124 定义 Gateway Event Contract（状态：未开始，负责人：Agent）
  - 子任务：确定 SSE Event Envelope（状态：未开始）
  - 子任务：完成与现有 Pi Web Event 的兼容映射（状态：未开始）
- 任务：DEV125 定义 Channel Contract（状态：未开始，负责人：Agent）
  - 子任务：冻结 receive / reply / send / session binding 边界（状态：未开始）
  - 子任务：明确 Channel 不直接依赖 Pi SDK（状态：未开始）

**S1 出口：** 三库与运行基线确认；四类核心 Contract 有明确版本；未开始改 Pi Web 正式 Runtime 路径。

---

### 阶段：S2 Personal Runtime 核心闭环

#### 包：DEV200（Personal Runtime）

##### 工作包：DEV210 Runtime 骨架

- 任务：DEV211 创建 `personal-runtime` 独立 Node/TypeScript Package（状态：未开始，负责人：Agent）
  - 子任务：建立 server / session / runtime / pi / channel / metadata 模块边界（状态：未开始）
  - 子任务：建立开发配置与独立数据目录（状态：未开始）
- 任务：DEV212 实现 `PiRuntimeAdapter`（状态：未开始，负责人：Agent）
  - 子任务：封装 AgentSession 创建 / 恢复（状态：未开始）
  - 子任务：封装 Prompt / Event / Abort（状态：未开始）
  - 子任务：封装 Model / Thinking Level（状态：未开始）
  - 子任务：建立 Adapter 单元测试（状态：未开始）
- 任务：DEV213 实现 `RuntimeManager`（状态：未开始，负责人：Agent）
  - 子任务：实现 sessionId → active runtime Registry（状态：未开始）
  - 子任务：实现同 Session 启动锁与 Prompt 串行保护（状态：未开始）
  - 子任务：实现空闲 Runtime 回收 / dispose（状态：未开始）
  - 子任务：实现进程重启后的按需恢复（状态：未开始）
- 任务：DEV214 实现 Session Router 与 MetadataStore（状态：未开始，负责人：Agent）
  - 子任务：实现新建 / 已有 Session 解析（状态：未开始）
  - 子任务：实现无项目 `projectDirectory=null` + `neutralCwd`（状态：未开始）
  - 子任务：实现 Personal Metadata 原子写入（状态：未开始）

#### 包：DEV220（Gateway）

##### 工作包：DEV221 Gateway API / SSE

- 任务：DEV222 实现 Session Query API（状态：未开始，负责人：Agent）
  - 子任务：list sessions（状态：未开始）
  - 子任务：get session（状态：未开始）
  - 子任务：create session（状态：未开始）
- 任务：DEV223 实现 Session Command API（状态：未开始，负责人：Agent）
  - 子任务：prompt / abort（状态：未开始）
  - 子任务：set_model / set_thinking_level（状态：未开始）
  - 子任务：按 Web 回归需要补齐 steer / follow_up / tool / compact（状态：未开始）
- 任务：DEV224 实现 SSE Event 流（状态：未开始，负责人：Agent）
  - 子任务：Runtime Event → Gateway Event 映射（状态：未开始）
  - 子任务：断线后可通过 Session History 补齐结果（状态：未开始）

#### 包：TST200（核心闭环验证）

##### 工作包：TST210 Runtime 集成测试

- 任务：TST211 创建 Session → Prompt → Streaming（状态：未开始，负责人：Agent）
- 任务：TST212 Runtime dispose → 同 Session 恢复 → 继续 Prompt（状态：未开始，负责人：Agent）
- 任务：TST213 Session 级模型切换并恢复状态（状态：未开始，负责人：Agent）
- 任务：TST214 无项目 / 真实目录两种 Session 均正确运行（状态：未开始，负责人：Agent）

**S2 出口：** 不依赖 Pi Web 的测试客户端已可通过 Personal Gateway 完成 Session 创建、恢复、Prompt、Streaming、模型切换。

---

### 阶段：S3 Pi Web 接入与产品体验

#### 包：DEV300（Web Runtime 解耦）

##### 工作包：DEV310 BFF → Personal Gateway

- 任务：DEV311 梳理并锁定 Pi Web 当前 `rpc-manager` Command / Event 行为基线（状态：未开始，负责人：Agent）
- 任务：DEV312 在 Pi Web BFF 接入 Personal Gateway（状态：未开始，负责人：Agent）
  - 子任务：Session 创建 / 恢复走 Gateway（状态：未开始）
  - 子任务：Prompt / Abort / Model 走 Gateway（状态：未开始）
  - 子任务：SSE Event 转发保持前端兼容（状态：未开始）
- 任务：DEV313 将长期 Runtime Ownership 从 Pi Web 移出（状态：未开始，负责人：Agent）
  - 子任务：迁出 / 替换 `globalThis` Session Runtime Registry（状态：未开始）
  - 子任务：保留开发阶段旧路径回退开关（状态：未开始）
  - 子任务：Gateway 回归完成后删除或禁用旧 Runtime 路径（状态：未开始）

#### 包：DEV320（Web Session 体验）

##### 工作包：DEV321 会话列表与新建会话

- 任务：DEV322 优化会话列表分区（状态：未开始，负责人：Agent）
  - 子任务：无项目会话置于项目目录之前（状态：未开始）
  - 子任务：按真实本地目录继续复用现有分组（状态：未开始）
- 任务：DEV323 优化新建 Session（状态：未开始，负责人：Agent）
  - 子任务：允许不选择项目目录（状态：未开始）
  - 子任务：允许选择已有真实本地目录（状态：未开始）
  - 子任务：仅在现有能力适合时优化新建本地目录交互（状态：未开始）
- 任务：DEV324 保持 Session 级模型选择 / 切换体验（状态：未开始，负责人：Agent）

#### 包：TST300（Web 回归）

##### 工作包：TST310 Pi Web 核心回归

- 任务：TST311 Web 新建 / 继续 / 恢复 Session（状态：未开始，负责人：Agent）
- 任务：TST312 Streaming / Abort / 模型切换（状态：未开始，负责人：Agent）
- 任务：TST313 本地项目目录上下文与 AGENTS / ResourceLoader 行为（状态：未开始，负责人：Agent）
- 任务：TST314 Pi Package / Extension 基础兼容（状态：未开始，负责人：Agent）

**S3 出口：** Web 已通过 Personal Gateway 使用统一 Runtime；核心体验无明显回归；当前 Web 不再是长期 AgentSession Owner。

---

### 阶段：S4 微信私聊接入

#### 包：POC400（微信 Transport）

##### 工作包：POC410 Transport 技术验证

- 任务：POC411 对候选微信 Transport 做最小 PoC（状态：未开始，负责人：Agent）
  - 子任务：验证登录与长期在线（状态：未开始）
  - 子任务：验证接收私聊文本（状态：未开始）
  - 子任务：验证回复私聊文本（状态：未开始）
  - 子任务：验证主动发送文本（状态：未开始）
  - 子任务：验证掉线 / 重连（状态：未开始）
  - 子任务：核对 License 与账号风险（状态：未开始）
- 任务：POC412 输出 Transport 选型结论；如构成关键决策则生成 ADR（状态：未开始，负责人：Agent）

#### 包：DEV400（WeChat Channel）

##### 工作包：DEV410 Channel Adapter

- 任务：DEV411 实现 `WeChatTransport` 选定实现适配（状态：未开始，负责人：Agent）
- 任务：DEV412 实现 `WeChatChannelAdapter`（状态：未开始，负责人：Agent）
  - 子任务：联系人身份标准化（状态：未开始）
  - 子任务：接收 / 回复文本（状态：未开始）
  - 子任务：主动发送文本（状态：未开始）
  - 子任务：未授权联系人拒绝策略（状态：未开始）
- 任务：DEV413 实现微信联系人 Session Binding（状态：未开始，负责人：Agent）
  - 子任务：无绑定时自动创建无项目 Session（状态：未开始）
  - 子任务：已有绑定时继续当前 Session（状态：未开始）
  - 子任务：支持新会话 / 会话列表 / 切换会话的最小确定性交互（状态：未开始）
  - 子任务：主动发送默认不改变 activeSessionId（状态：未开始）

#### 包：TST400（微信验收）

##### 工作包：TST410 Channel 集成测试

- 任务：TST411 微信首次消息创建 Session 并回复（状态：未开始，负责人：Agent）
- 任务：TST412 微信继续已有 Session（状态：未开始，负责人：Agent）
- 任务：TST413 主动向指定联系人发送文本（状态：未开始，负责人：Agent）
- 任务：TST414 微信掉线不影响 Web；恢复后原 Binding 继续有效（状态：未开始，负责人：Agent）

**S4 出口：** 微信私聊文本完成接收、回复、主动发送及统一 Session Binding，Transport 风险有真实验证结论。

---

### 阶段：S5 跨 Channel 验收与生产发布

#### 包：TST500（跨 Channel）

##### 工作包：TST510 一期核心场景

- 任务：TST511 Web 创建 Session → 微信继续同一 Session（状态：未开始，负责人：Agent）
- 任务：TST512 微信创建 Session → Web 查看并继续（状态：未开始，负责人：Agent）
- 任务：TST513 Web 与微信同时访问同一 Session 时无并发写冲突（状态：未开始，负责人：Agent）
- 任务：TST514 无项目 / 项目目录 / 模型切换组合场景（状态：未开始，负责人：Agent）

#### 包：TST520（全量回归）

##### 工作包：TST521 Pi / Pi Web 回归

- 任务：TST522 Pi 核心 AgentSession / Tool / Package 基础能力回归（状态：未开始，负责人：Agent）
- 任务：TST523 Pi Web Session / Streaming / Model / Local Directory 回归（状态：未开始，负责人：Agent）
- 任务：TST524 Personal Runtime 重启恢复与异常场景回归（状态：未开始，负责人：Agent）

#### 包：REL500（发布）

##### 工作包：REL510 稳定版本发布

- 任务：REL511 完成开发库最终检查和 Git 状态核对（状态：未开始，负责人：Agent）
- 任务：REL512 合并稳定分支并创建一期 Release / Tag（状态：未开始，负责人：缘一）
- 任务：REL513 `Yuanyi-Pi-prod` 只从自有 Git 同步稳定版本（状态：未开始，负责人：Agent）
- 任务：REL514 验证生产 Pi + Pi Web + Personal Runtime 运行（状态：未开始，负责人：Agent）
- 任务：REL515 输出一期交付与验收结果（状态：未开始，负责人：Agent）

**S5 出口：** PRD 六个核心验收场景全部通过；Pi / Pi Web 无明显回归；稳定版本进入 Yuanyi-Pi-prod；形成一期正式验收结论。

## 执行规则

1. 阶段按 S1 → S5 顺序推进，前一阶段出口未通过不得进入下一阶段正式改造。
2. 每个阶段开始前读取对应 Stage 文档；结束后补充 Stage 总结并由项目负责人确认阶段出口。
3. WBS 只管理任务，不在任务描述中临时修改已冻结需求或架构。
4. 发现需求 / 架构需要变化时，先进入 ChangeLog / ADR / 上游文档变更链，不允许直接通过代码实现绕过门控。
5. Issue 进入 IssueLog，不把 WBS 变成问题台账。
6. 一期明确不把 Memory、Scheduler、Desktop、完整 Capability Router、Subagent 产品化和更多 IM 偷带入任务范围。
