---
type: WBS
status: 草稿
version: v1.0
depends_on: 基准事实-v1.2; PRD-002-v1.0; 架构设计-002-v1.0; 技术设计-002-v1.0; ADR-002-v1.0; IssueLog-001-v1.0
owner: 缘一
created: 2026-08-20
updated: 2026-08-20
---

# WBS-002：Runtime 稳定化收口

## 任务分解

### 阶段：S6 Runtime Ownership 与服务生命周期收口

#### 包：DEV600（Runtime Ownership 清场）

##### 工作包：DEV610 Web 活 Runtime 路径清理

- 任务：DEV611 全量扫描 Gateway 模式下 `rpc-manager` 活状态调用（状态：未开始，负责人：Agent）
  - 子任务：整理 `startRpcSession / getRpcSession / running / project-trust` 调用矩阵（状态：未开始）
  - 子任务：区分纯只读路径与活 Runtime 路径（状态：未开始）
- 任务：DEV612 Running Session 状态改由 Personal Runtime 提供（状态：未开始，负责人：Agent）
- 任务：DEV613 Session 删除改为 Gateway 协调（状态：未开始，负责人：Agent）
- 任务：DEV614 State / Context / Auto-name 中会触发 Runtime 的路径迁移 Gateway（状态：未开始，负责人：Agent）
- 任务：DEV615 Project Trust 与活 Runtime 相关操作迁移 Gateway（状态：未开始，负责人：Agent）
- 任务：DEV616 Gateway 模式生产路径禁止 Web 创建第二套 AgentSession（状态：未开始，负责人：Agent）

##### 工作包：TST610 Ownership 验证

- 任务：TST611 静态扫描确认 Gateway 模式不存在未授权 `startRpcSession()` 路径（状态：未开始，负责人：Agent）
- 任务：TST612 运行期确认同 Session 只有 Personal Runtime 一个 AgentSession Owner（状态：未开始，负责人：Agent）

#### 包：DEV620（Runtime 正确性）

##### 工作包：DEV621 Prompt 串行

- 任务：DEV622 Gateway 普通 `prompt` 改走 `RuntimeManager.prompt()`（状态：未开始，负责人：Agent）
- 任务：DEV623 清理完成的 `promptTails`，避免长期增长（状态：未开始，负责人：Agent）
- 任务：TST624 Web + 微信同 Session 并发 Prompt 串行测试（状态：未开始，负责人：Agent）

##### 工作包：DEV625 Idle 回收

- 任务：DEV626 Idle 扫描改用真实 `isStreaming / isIdle`（状态：未开始，负责人：Agent）
- 任务：DEV627 Runtime Event 更新 `lastActiveAt`（状态：未开始，负责人：Agent）
- 任务：TST628 长任务超过 Idle 阈值不被回收（状态：未开始，负责人：Agent）
- 任务：TST629 真正空闲后可 dispose 并按同 Session ID 恢复（状态：未开始，负责人：Agent）

#### 包：DEV630（无项目 Web 语义）

##### 工作包：DEV631 Session DTO / UI

- 任务：DEV632 Web Session DTO 使用 `projectDirectory` 作为项目字段（状态：未开始，负责人：Agent）
- 任务：DEV633 移除新建 Session 对 `selectedCwd` 的强制依赖（状态：未开始，负责人：Agent）
- 任务：DEV634 无项目 Session 展示与目录分组修复（状态：未开始，负责人：Agent）
- 任务：TST635 无项目 / 真实目录 Session 回归（状态：未开始，负责人：Agent）

#### 包：OPS640（Personal Runtime 常驻）

##### 工作包：OPS641 launchd 托管

- 任务：OPS642 增加 Personal Runtime `/health`（状态：未开始，负责人：Agent）
- 任务：OPS643 建立生产 launchd 服务定义（状态：未开始，负责人：Agent）
- 任务：OPS644 改造 `personal-runtime.sh` 为系统服务控制器（状态：未开始，负责人：Agent）
- 任务：OPS645 移除所有 Pi Web 对 Runtime 生命周期的启停行为（状态：未开始，负责人：Agent）
- 任务：OPS646 增加 Runtime 单实例保护和状态输出（状态：未开始，负责人：Agent）
- 任务：TST647 Web 关闭状态下微信长期在线验证（状态：未开始，负责人：Agent）
- 任务：TST648 Web 重启不影响 Runtime / Agent Run / 微信（状态：未开始，负责人：Agent）
- 任务：TST649 重复启动不再产生 EADDRINUSE（状态：未开始，负责人：Agent）

#### 包：PERF650（Web 响应性能）

##### 工作包：PERF651 TTFT / Streaming 基线

- 任务：PERF652 建立 T0–T3 时间戳和 requestId（状态：未开始，负责人：Agent）
- 任务：PERF653 输出 command proxy / model TTFT / stream proxy 指标（状态：未开始，负责人：Agent）
- 任务：PERF654 连续不少于 30 次本地 Web 对话采样（状态：未开始，负责人：Agent）
- 任务：PERF655 验证 Web/BFF → Gateway P95 ≤ 50 ms（状态：未开始，负责人：Agent）
- 任务：PERF656 验证 Gateway Event → Browser P95 ≤ 50 ms（状态：未开始，负责人：Agent）
- 任务：PERF657 检查高频 Streaming 是否存在批量吐字 / 事件积压（状态：未开始，负责人：Agent）

#### 包：TST660（稳定化全量回归）

##### 工作包：TST661 一期能力回归

- 任务：TST662 Web 基础聊天 / Streaming / Abort / Model 回归（状态：未开始，负责人：Agent）
- 任务：TST663 本地目录 / 无项目 Session 回归（状态：未开始，负责人：Agent）
- 任务：TST664 微信接收 / 回复 / 主动发送回归（状态：未开始，负责人：Agent）
- 任务：TST665 Web ↔ 微信统一 Session 回归（状态：未开始，负责人：Agent）
- 任务：TST666 Pi Package / Extension / Permission 基础回归（状态：未开始，负责人：Agent）
- 任务：TST667 Runtime 重启后的 Session 恢复验证（状态：未开始，负责人：Agent）

#### 包：REL670（稳定基线发布）

##### 工作包：REL671 S6 发布

- 任务：REL672 关闭 P0 Issue 并补齐验收证据（状态：未开始，负责人：Agent）
- 任务：REL673 输出 S6 测试与性能结果（状态：未开始，负责人：Agent）
- 任务：REL674 合并稳定版本并推送 Yuanyi-Pi Git（状态：未开始，负责人：缘一）
- 任务：REL675 Yuanyi-Pi-prod 同步稳定版本并实测（状态：未开始，负责人：Agent）
- 任务：REL676 形成新的稳定运行基线结论（状态：未开始，负责人：缘一）

**S6 出口：**

1. ISS-201 ～ ISS-206 全部关闭；
2. Runtime 独立常驻，Web 不控制其生命周期；
3. Gateway 模式一个 Session 只有一个 Runtime Owner；
4. Prompt 串行和 Idle 回收通过真实测试；
5. 无项目 Web 体验闭环；
6. 两段本地转发延迟 P95 均满足 ≤ 50 ms；
7. PRD-001 已完成的一期能力无阻断性回归；
8. 稳定版本进入 `Yuanyi-Pi-prod`。

## 执行规则

1. 本 WBS 只执行 002 稳定化范围，不重新执行 WBS-001。
2. 001 文档是历史建设依据，不在本轮修改。
3. 发现需要改变基准事实、PRD-002 或架构设计-002 时，先走 ChangeLog / ADR，不得直接在代码里改变方向。
4. 当前先关闭 P0 正确性与生命周期问题，再做性能优化。
5. 性能未达标必须先定位真实耗时段，不允许仅凭“两个进程多一跳”直接合并进程。
6. 自有 `pi/` 运行依赖问题只记录，不在没有自有 Pi Core 修改时扩大本轮范围。
