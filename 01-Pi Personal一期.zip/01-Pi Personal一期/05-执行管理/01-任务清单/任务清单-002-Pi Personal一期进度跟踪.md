---
type: WBS
status: 草稿
version: v1.0
depends_on: WBS-001-v1.0
owner: 缘一
created: 2026-08-20
updated: 2026-08-20
---

# 任务清单-002：Pi Personal 一期进度跟踪

> 本文档只用于日常进度跟踪。任务范围和拆解以 `WBS-001-Pi Personal一期.md` 为准；新增、删除或改变任务范围时先修改 WBS，再同步本清单。

> **阶段状态：S1-S4 ✅ 已完成并确认；S5 进行中（跨 Channel 验证已完成，发布流程待执行）；增补需求（PRD-002）已实现待走查**

## 进度总览

- 总任务：48（WBS 口径）+ 3（增补需求 PRD-002）
- 已完成：44（WBS）+ 3（增补）
- 进行中：0
- 阻塞：0
- 未开始：4（REL512/513/514/515）

状态只使用：`未开始 / 进行中 / 已完成 / 阻塞`。

## S1 工程基线与核心契约

| ID | 任务 | 状态 | 负责人 | 阻塞/备注 | 验收证据 |
|---|---|---|---|---|---|
| DEV111 | 核对 `pi-upstream / Yuanyi-Pi-dev / Yuanyi-Pi-prod` 三库及自有 Git 关系 | 已完成 | Agent | 见验收证据：⚠️ 生产运行路径与 Handoff 不符，已上报（.learnings K-001） | ①dev 单仓含 pi/pi-web/pi-permission-system，remote=Yuanyi-Pi.git；②生产 Web 可访问(HTTP 200)未受影响；③数据目录隔离：生产~/.pi/agent(有sessions)、开发~/.pi-dev/agent(无sessions)；端口均为30141；**生产实际运行于 /Users/yuanyi/Desktop/AI/16_Pi Agent/pi-web（官方v0.8.9），非 Yuanyi-Pi-prod/pi-web** |
| DEV112 | 固定一期源码基线与回归启动方式 | 已完成 | Agent | 生产已确认运行于 Yuanyi-Pi-prod/pi-web；dev 3处未提交环境隔离改动按"基线+本地改动"记录，不擅自 commit | ①基线：dev HEAD=f921bb980ca4d49e00ce51075d276780b999e488，pi子树=ab06647cd(对应官方209bc7b)，pi-web子树=a35a9d6aa(v0.8.9)，依赖@earendil-works/pi-* 0.84.2；②生产Web(prod/pi-web)HTTP 200可访问，开发环境handoff已验收；③回归点：agent/new→startRpcSession、globalThis.__piSessions(rpc-manager.ts:1378)、AgentSessionWrapper idle10min回收(181/356)、setModel(542)、abort(501)、cwd必传 |
| DEV122 | 定义 Session Contract | 已完成 | Agent | 契约落盘 Stage-001 附录 C-1 | SessionDescriptor + ModelSelection；projectDirectory=null→neutralCwd 与真实目录解耦（AD-005）；Pi Session ID 统一主身份（AD-003）；数据合并规则 |
| DEV123 | 定义 Runtime Contract | 已完成 | Agent | 契约落盘 Stage-001 附录 C-2 | PiRuntimeAdapter 接口；生命周期 starting→ready→busy→(disposing\|error)；启动锁/串行/空闲回收/重启恢复；命令面保留 Pi Web 现有全部命令 |
| DEV124 | 定义 Gateway Event Contract | 已完成 | Agent | 契约落盘 Stage-001 附录 C-3 | SSE Envelope{sessionId,sequence,type,timestamp,payload}；payload 兼容现有 AgentEvent{type,...}（rpc-manager.ts）；断线不终止 Runtime |
| DEV125 | 定义 Channel Contract | 已完成 | Agent | 契约落盘 Stage-001 附录 C-4 | ChannelAdapter + InboundChannelMessage；不直接依赖 Pi SDK；activeSessionId Binding 规则；未授权拒绝；一期仅 wechat |

## S2 Personal Runtime 核心闭环

| ID | 任务 | 状态 | 负责人 | 阻塞/备注 | 验收证据 |
|---|---|---|---|---|---|
| DEV211 | 创建 `personal-runtime` 独立 Node/TypeScript Package | 已完成 | Agent | 骨架已创建并验证 | `Yuanyi-Pi-dev/personal-runtime/`：package.json(tsx+typescript+@earendil-works/pi-coding-agent 0.84.2)；tsconfig严格模式；src 模块边界 server/session/runtime/pi/channel+wechat/model/metadata/config；config 支持 YUANYI_PI_DATA_DIR（开发注入 ~/.pi-dev/.yuanyi-pi，默认 ~/.yuanyi-pi）、端口8770、neutralCwd；npm install 146包0漏洞；typecheck通过；骨架可运行 |
| DEV212 | 实现 `PiRuntimeAdapter` | 已完成 | Agent | 单测5/5通过 | src/pi/adapter.ts：create/resume（SDK高层createAgentSession自动恢复模型/thinking）、prompt、命令面(steer/follow_up/set_model/set_thinking_level/set_tools/compact/get_state)、subscribe→GatewayEvent envelope、abort/dispose；test/pi-adapter.test.ts 5测试全过（临时cwd+agentDir隔离，不碰真实数据） |
| DEV213 | 实现 `RuntimeManager` | 已完成 | Agent | 单测5/5通过 | src/runtime/manager.ts：Registry(sessionId→entry)、resume启动锁(并发只建一个)、create新建、prompt串行队列、空闲回收(默认10min，只释放内存不删持久session)、touch防回收、getActiveSessionIds；sessionId一律以Pi生成为准(AD-003)；test/runtime-manager.test.ts 5测试全过 |
| DEV214 | 实现 Session Router 与 MetadataStore | 已完成 | Agent | 单测7/7通过 | src/session/router.ts：resolveNew(无项目→neutralCwd/有项目→projectDirectory)、resolveExisting(sessionId→listAll定位file→resume)、list合并Pi Session+metadata+running+orphan标记；src/metadata/store.ts：原子写入(临时文件+rename)、sessionMeta/channelBinding、损坏容错；test/session-router.test.ts 7测试全过 |
| DEV222 | 实现 Session Query API | 已完成 | Agent | HTTP测试通过 | GET /v1/sessions(list)、GET /v1/sessions/{id}(get)、POST /v1/sessions(create 无项目/有项目/model/originChannel) |
| DEV223 | 实现 Session Command API | 已完成 | Agent | HTTP测试通过 | POST /v1/sessions/{id}/commands：prompt/abort/steer/follow_up/set_model/set_thinking_level/set_tools/compact/get_state；Runtime未激活时自动恢复 |
| DEV224 | 实现 SSE Event 流 | 已完成 | Agent | HTTP测试通过 | GET /v1/sessions/{id}/events：SSE Envelope(sessionId/sequence/type/timestamp/payload)；初始state快照；断线只退订不终止Runtime；未激活409 |
| TST211 | 创建 Session → Prompt → Streaming | 已完成 | Agent | 集成验证通过 | test/integration/http-integration.mts TST211：真实LLM(~/.pi-dev/agent, gpt-5.6-luna)创建无项目Session→prompt→SSE收agent_end(events=42) |
| TST212 | Runtime dispose → 同 Session 恢复 → 继续 Prompt | 已完成 | Agent | 集成验证通过 | TST212：dispose→GET恢复(sessionId不变)→继续prompt上下文保持 |
| TST213 | Session 级模型切换并恢复状态 | 已完成 | Agent | 集成验证通过 | TST213：set_model→kimi-k2.6→prompt落盘→dispose→恢复后模型保持 |
| TST214 | 无项目 / 真实目录两种 Session 均正确运行 | 已完成 | Agent | 集成验证通过 | TST214：无项目runtimeCwd=neutralCwd；有项目runtimeCwd=projectDirectory；两者均正常prompt |

## S3 Pi Web 接入与产品体验

| ID | 任务 | 状态 | 负责人 | 阻塞/备注 | 验收证据 |
|---|---|---|---|---|---|
| DEV311 | 梳理并锁定 Pi Web 当前 `rpc-manager` Command / Event 行为基线 | 已完成 | Agent | 基线落盘 Stage-003 附录 | 26命令面/AgentEvent结构/startRpcSession/globalThis.__piSessions/idle 10min回收/Web API行为表/前端调用链 |
| DEV312 | 在 Pi Web BFF 接入 Personal Gateway | 已完成 | Agent | typecheck通过；TST311-314验证 | dev/pi-web：lib/personal-gateway.ts(HTTP client)；api/agent/new/[id]/[id]/events/sessions 四个route改走Gateway(env PERSONAL_GATEWAY_ENABLED=1启用)；new支持无cwd(projectDirectory null→neutralCwd)；SSE代理lib/agent-event-stream-gateway.ts(connected协议兼容+envelope解包) |
| DEV313 | 将长期 Runtime Ownership 从 Pi Web 移出 | 已完成 | Agent | TST311-314验证通过；旧路径回退开关保留(发布期删除) | Gateway启用时Web不再创建/持有AgentSession，rpc-manager/globalThis.__piSessions不再被调用；PERSONAL_GATEWAY_ENABLED=1启用Gateway路径，未启用回退旧路径；生产发布时设置env并验证后删除旧路径(见REL) |
| DEV322 | 优化会话列表分区 | 已完成 | Agent | 前端改动+typecheck通过 | SessionSidebar：无项目会话分区置顶(无项目会话标题+独立渲染)；无项目session cwd=""不进项目分组(workspaceKeyOf天然排除) |
| DEV323 | 优化新建 Session | 已完成 | Agent | 前端改动+typecheck通过 | SessionSidebar.handleNewSession允许无cwd新建(cwd="")；api/agent/new cwd可选(空→projectDirectory null→neutralCwd) |
| DEV324 | 保持 Session 级模型选择 / 切换体验 | 已完成 | Agent | 不破坏现有体验(TST312验证) | 模型选择/切换前端交互未改动；Gateway set_model 命令保留 |
| TST311 | Web 新建 / 继续 / 恢复 Session | 已完成 | Agent | dev端到端验证通过 | dev Web(Gateway模式)30142：无项目新建 ensure_session→列表含cwd=""→GET running:true(修复：runtime激活优先于磁盘) |
| TST312 | Streaming / Abort / 模型切换 | 已完成 | Agent | dev端到端验证通过 | 先SSE后prompt：收到39事件(connected,agent_start,message_start,message_end,message_update,agent_end,agent_settled)；连续prompt 2次agent_end；set_model kimi-k2.6生效 |
| TST313 | 本地项目目录上下文与 AGENTS / ResourceLoader 行为 | 已完成 | Agent | dev端到端验证通过 | 项目目录session创建成功(ensure_session)；runtimeCwd=projectDirectory；上下文行为由Pi原生承载 |
| TST314 | Pi Package / Extension 基础兼容 | 已完成 | Agent | dev端到端验证通过 | dev settings packages(pi-permission-system/ponytail)加载无阻断；agent完整对话运行(extension无报错) |

## S4 微信私聊接入

| ID | 任务 | 状态 | 负责人 | 阻塞/备注 | 验收证据 |
|---|---|---|---|---|---|
| POC411 | 对候选微信 Transport 做最小 PoC | 已完成 | Agent | 真实微信验证全部通过 | ①扫码登录+token持久化(account.json)；②接收私聊文本("PoC测试123"经getupdates收到, from=o9cq80...@im.wechat)；③回复(echo自动回复)；④主动发送(wechat-send.ts无入站触发)；⑤token复用恢复连接；⑥官方ilinkai接口无封号风险 |
| POC412 | 输出 Transport 选型结论；如构成关键决策则生成 ADR | 已完成 | Agent | ADR-001 已生成待确认 | 选型：微信官方ilinkai接口(照抄nanobot)；排除AX自动化(实测屏蔽)/OCR/hook/wechaty/企业微信；ADR-001落盘 03-设计/03-决策记录/ |
| DEV411 | 实现 `WeChatTransport` 选定实现适配 | 已完成 | Agent | 照抄nanobot机制+37测试通过 | src/channel/wechat/：types/ilink/format/login/state/transport 全部照抄；主入口集成(YUANYI_PI_WECHAT_ENABLED=1)；CLI登录命令 scripts/wechat-login.ts |
| DEV412 | 实现 `WeChatChannelAdapter` | 已完成 | Agent | 单测通过+真实微信验证 | adapter.ts：入站映射/自动创建Session/回复收集(message_end)/主动send；不直接import Pi SDK；可注入transport测试 |
| DEV413 | 实现微信联系人 Session Binding | 已完成 | Agent | 真实微信验证 | 无绑定自动创建无项目Session并绑定；已绑定继续同一Session；/新会话 /列表 /继续n 最小交互；主动发送不改binding |
| TST411 | 微信首次消息创建 Session 并回复 | 已完成 | Agent | 真实微信验证通过 | 首条消息→创建无项目Session(01a01dea...,originChannel=wechat)+binding写入+Agent回复收到 |
| TST412 | 微信继续已有 Session | 已完成 | Agent | 真实微信验证通过 | 第二条消息→同一Session(wechat sessions数=1,binding不变)+上下文回复+对话落盘 |
| TST413 | 主动向指定联系人发送文本 | 已完成 | Agent | 真实微信验证通过 | adapter.send主动发送成功且不改变activeSessionId |
| TST414 | 微信掉线不影响 Web；恢复后原 Binding 继续有效 | 已完成 | Agent | 真实微信验证通过 | 重启后token复用免扫码；binding保持；wechat sessions数不变；Gateway恢复 |

## S5 跨 Channel 验收与生产发布

| ID | 任务 | 状态 | 负责人 | 阻塞/备注 | 验收证据 |
|---|---|---|---|---|---|
| TST511 | Web 创建 Session → 微信继续同一 Session | 已完成 | Agent | 真实跨Channel验证通过 | Web创建(01a01dec)+写入上下文→微信/list /继续2切换→问密码答ABC123（同一Session上下文）；binding切换验证 |
| TST512 | 微信创建 Session → Web 查看并继续 | 已完成 | Agent | 真实跨Channel验证通过 | Web GET微信Session(01a01dea) 200→继续prompt→Agent引用微信阶段内容（统一Session无channel概念为预期） |
| TST513 | Web 与微信同时访问同一 Session 时无并发写冲突 | 已完成 | Agent | 真实并发验证通过 | Web长任务+微信消息→串行队列：Web任务先完成，微信消息后处理，无串线 |
| TST514 | 无项目 / 项目目录 / 模型切换组合场景 | 已完成 | Agent | 组合验证通过 | 项目目录Session+指定模型(kimi-k2.6)→切换(gpt-5.6-luna)生效→prompt成功 |
| TST522 | Pi 核心 AgentSession / Tool / Package 基础能力回归 | 已完成 | Agent | 真实回归通过 | bash工具(pwd)执行成功输出neutralCwd；修复了neutralCwd目录不存在缺陷(启动时mkdir)；Package加载无阻断(前期TST314) |
| TST523 | Pi Web Session / Streaming / Model / Local Directory 回归 | 已完成 | Agent | dev Web回归通过 | 页面200；/api/sessions 28条；无项目新建成功(model=gpt-5.6-luna)；SSE/模型/目录前期TST311-314验证 |
| TST524 | Personal Runtime 重启恢复与异常场景回归 | 已完成 | Agent | 修复2处并验证 | 修复：项目目录不存在→400(invalid_project_directory)；无效命令→400(invalid_command)；未知session→404；重启后token复用/binding保持(前期TST414) |
| REL511 | 完成开发库最终检查和 Git 状态核对 | 已完成 | Agent | `personal-runtime` 与 `pi-web` 最终验证通过；工作区仍保留待提交实现改动 | `personal-runtime`: typecheck通过、37/37测试通过；`pi-web`: diff --check通过、587/587测试通过、lint 0 errors（5 warnings）、生产构建通过（存在既有动态依赖 warning） |
| REL512 | 合并稳定分支并创建一期 Release / Tag | 未开始 | 缘一 |  |  |
| REL513 | `Yuanyi-Pi-prod` 只从自有 Git 同步稳定版本 | 未开始 | Agent |  |  |
| REL514 | 验证生产 Pi + Pi Web + Personal Runtime 运行 | 未开始 | Agent |  |  |
| REL515 | 输出一期交付与验收结果 | 未开始 | Agent |  |  |

## 增补需求（PRD-002，2026-08-20 新增）

> 对应 PRD-002 三项增补需求，技术方案见技术设计-002。已实现并真实微信验证，待项目负责人界面走查确认。

| ID | 任务 | 状态 | 负责人 | 阻塞/备注 | 验收证据 |
|---|---|---|---|---|---|
| ADD101 | FR-101 微信"正在输入"（typing，照抄 nanobot 机制） | 已完成 | Agent | 真实微信验证通过 | transport startTyping/stopTyping（getconfig 拿 ticket + sendtyping + 5s keepalive + 24h 缓存退避）；adapter 收到消息→typing→回复后取消；用户验证微信显示"正在输入" |
| ADD102 | FR-102 渠道管理界面（微信面板 + 设置真实生效） | 已完成 | Agent | 真实微信验证通过；默认值对齐 nanobot | 后端 WechatChannelController（状态/扫码连接/配置）+ Gateway 端点；BFF 4 route；ChannelsConfig.tsx（状态徽章/二维码/验证码/8项配置）；配置存 channels.json 即时生效（allowFrom 过滤、工具提示/进度/分块开关）；默认与 nanobot 一致（工具提示/进度/分块=off，typing=on） |
| ADD103 | FR-103 左下角设置入口整合 | 已完成 | Agent | UI 渲染验证通过 | AppShell：设置按钮 + 向上弹出四入口（模型/技能/插件/渠道），保留原 disabled 逻辑；i18n 注册 |

## 跟踪规则

1. Agent 每完成一个可验证任务，更新对应状态并补充“验收证据”。
2. 任务进入阻塞时，必须在“阻塞/备注”中写明原因；复杂问题另建 IssueLog。
3. 只有通过对应验证后才能标记“已完成”，不能以“代码已写”代替验收。
4. Stage 出口是否通过仍以对应 Stage 文档和项目负责人确认结果为准。
5. 本清单不承载需求、架构或技术方案变更。
