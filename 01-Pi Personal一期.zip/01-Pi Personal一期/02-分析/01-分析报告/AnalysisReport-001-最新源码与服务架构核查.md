---
type: AnalysisReport
status: 草稿
version: v1.0
depends_on: 基准事实-v1.2
owner: 缘一
created: 2026-08-20
updated: 2026-08-20
---

# AnalysisReport-001：最新源码与服务架构核查

## 调研问题

基于最新 `pi-prod` 源码和真实启动事故，回答三个问题：

1. 第一轮 Pi Personal 一期建设是否已经实现核心目标；
2. 当前 `pi-web` 与 `personal-runtime` 的实现偏差在哪里；
3. Web 与 Personal Runtime 是否应继续保持双进程，以及双进程是否会造成可感知的 LLM 响应性能下降。

## 方法范围

核查范围：

- `pi-web/`
- `personal-runtime/`
- `pi/`
- 当前生产启动脚本
- 环境交付报告
- Web / Gateway 启动事故记录

重点核对：

- Runtime Ownership
- Session 创建 / 恢复 / 删除 /状态
- Prompt 并发
- Idle 回收
- 无项目 Session
- SSE Streaming
- 服务生命周期
- 运行依赖

## 发现数据

### 1. 第一轮主架构已经实现

最新代码已经包含：

- Personal Gateway
- Session Router
- Runtime Manager
- PiRuntimeAdapter
- Personal Metadata
- WeChat Channel / Transport
- Pi Web → Gateway 接入
- Web / 微信统一 Session 主链

因此当前不再是“继续建设一期基础能力”，而是对已实现系统做稳定化收口。

### 2. Web Runtime Ownership 尚未彻底退出

Gateway 模式已经覆盖主要新建 Session、Command 和 Event 链路，但 Web 仍有多个路径直接依赖 `rpc-manager`，包括运行中 Session、Project Trust、部分 Session State / Context / Auto-name 等路径。

这意味着 Gateway 模式下仍存在两类风险：

- Web 再次启动或持有同一 Session 的 AgentSession；
- Web 对 Session 文件或状态的操作与 Gateway 中真实 Runtime 不一致。

### 3. Prompt 串行代码存在，但主链没有使用

`RuntimeManager` 已实现 `promptTails` 和 `RuntimeManager.prompt()`，但 Gateway 的普通 Session Command 当前统一调用 `RuntimeManager.sendCommand()`。

因此普通 `prompt` 会进入 `PiRuntimeAdapter.sendCommand()`，绕过 RuntimeManager 的专用串行队列。

### 4. Idle 回收没有使用真实 Streaming 状态

RuntimeManager 当前按：

- `lastActiveAt`
- Registry 静态 `entry.state`
- 约 10 分钟空闲阈值

决定回收。

但 PiRuntimeAdapter 已能通过 `getState()` 返回 `isStreaming / isIdle`，RuntimeManager 扫描时却没有使用这些真实状态。

因此长任务理论上可能在仍运行时被误判为空闲并 dispose。

### 5. 无项目 Session 的 Runtime 与 Web 语义仍不一致

Runtime 已正确实现：

```text
projectDirectory = null
runtimeCwd = neutralCwd
```

但 Web Session API 当前把 `runtimeCwd` 直接映射为 `cwd`，同时 SessionSidebar 的“新会话”按钮仍在 `selectedCwd` 为空时禁用。

所以“无项目 Session”在 Runtime 层存在，在 Web 产品体验上尚未闭环。

### 6. 双进程方向正确，生命周期关系错误

真实需求已经确认：

> 即使 Web 数天不打开，微信仍必须在线收消息和主动发送。

因此 Personal Runtime 必须独立于 Web 生命周期长期存在。

当前问题不是“两个进程”，而是：

- Web 和手工脚本都可能成为 Gateway 启动者；
- Gateway 没有唯一系统级 Owner；
- 用户需要感知 8770 / 30141、PID、脚本等内部细节；
- 已实际发生重复启动导致 `EADDRINUSE`。

### 7. 双进程不应天然造成明显 Web 卡顿

当前链路：

```text
AgentSession
→ Gateway SSE
→ localhost
→ Pi Web BFF 解析 / 转换 / 再 SSE
→ Browser
```

Gateway 使用即时 `res.write()`；Web SSE 路径关闭代理缓存并逐事件转发。

双进程会增加 localhost IPC 与 JSON parse / stringify，但源码没有主动攒完整回答再批量输出的设计。

真正需要确认的是：

- Browser → Gateway 的额外命令延迟；
- Gateway 第一条模型事件 → Browser 的额外 Streaming 延迟；
- 高频事件是否出现积压或批量吐字。

### 8. 自有 `pi/` 当前还不是产品实际运行依赖

`pi-web` 与 `personal-runtime` 的 `package.json` 当前仍依赖官方 npm `@earendil-works/pi-coding-agent@0.84.2`。

因此仓库内 `pi/` 是自主管理源码基线，但当前修改它并不会自动进入 Web / Runtime 的实际运行链路。

## 结论

1. 第一轮一期建设的核心方向已完成，不应重新从零建设。
2. 当前应开启新的“Runtime 与服务架构稳定化”设计迭代。
3. Web 与 Personal Runtime 应继续保持双进程。
4. Personal Runtime 应成为唯一 Runtime Owner 和长期后台服务。
5. 需要先收口 Ownership、并发、Idle、无项目语义、服务生命周期和性能，再继续叠加新能力。
6. 双进程性能问题必须用 TTFT / Streaming 指标验证，而不是凭体感或直接合并进程。

## 建议

以 `基准事实 v1.2` 为方向锚，新建独立的：

- PRD-002
- 架构设计-002
- 技术设计-002
- ADR-002
- WBS-002

001 文档全部保留为上一轮历史设计，不再修改。
